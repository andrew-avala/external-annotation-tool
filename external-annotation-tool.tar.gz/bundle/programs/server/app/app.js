var require = meteorInstall({"lib":{"collections.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
SseSamples = new Mongo.Collection("SseSamples");
SseProps = new Mongo.Collection("SseProps");
if (Meteor.isServer) {
  Meteor.publish("sse-data-descriptor", function (imageUrl) {
    return SseSamples.find({
      url: imageUrl
    });
  });
  Meteor.publish("sse-labeled-images", function () {
    return SseSamples.find({
      $where: 'this.objects && this.objects.length>0'
    }, {
      fields: {
        file: 1,
        url: 1
      }
    });
  });
  Meteor.publish('sse-props', function () {
    return SseProps.find({});
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"editor":{"3d":{"SsePCDLoader.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/editor/3d/SsePCDLoader.js                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => SsePCDLoader
});
class SsePCDLoader {
  constructor(THREE) {
    THREE.PCDLoader = function (serverMode) {
      this.serverMode = serverMode;
    };
    THREE.PCDLoader.prototype = {
      constructor: THREE.PCDLoader,
      load: function (url, onLoad, onProgress, onError) {
        var scope = this;
        var loader = new THREE.FileLoader(scope.manager);
        loader.setResponseType('arraybuffer');
        loader.load(url, function (data) {
          onLoad(scope.parse(data, url));
        }, onProgress, onError);
      },
      parse: function (data, url) {
        function decompressLZF(inData, outLength) {
          // from https://gitlab.com/taketwo/three-pcd-loader/blob/master/decompress-lzf.js
          var inLength = inData.length;
          var outData = new Uint8Array(outLength);
          var inPtr = 0;
          var outPtr = 0;
          var ctrl;
          var len;
          var ref;
          do {
            ctrl = inData[inPtr++];
            if (ctrl < 1 << 5) {
              ctrl++;
              if (outPtr + ctrl > outLength) throw new Error('Output buffer is not large enough');
              if (inPtr + ctrl > inLength) throw new Error('Invalid compressed data');
              do {
                outData[outPtr++] = inData[inPtr++];
              } while (--ctrl);
            } else {
              len = ctrl >> 5;
              ref = outPtr - ((ctrl & 0x1f) << 8) - 1;
              if (inPtr >= inLength) throw new Error('Invalid compressed data');
              if (len === 7) {
                len += inData[inPtr++];
                if (inPtr >= inLength) throw new Error('Invalid compressed data');
              }
              ref -= inData[inPtr++];
              if (outPtr + len + 2 > outLength) throw new Error('Output buffer is not large enough');
              if (ref < 0) throw new Error('Invalid compressed data');
              if (ref >= outPtr) throw new Error('Invalid compressed data');
              do {
                outData[outPtr++] = outData[ref++];
              } while (--len + 2);
            }
          } while (inPtr < inLength);
          return outData;
        }
        function parseHeader(data) {
          var PCDheader = {};
          var result1 = data.search(/[\r\n]DATA\s(\S*)\s/i);
          var result2 = /[\r\n]DATA\s(\S*)\s/i.exec(data.substr(result1 - 1));
          PCDheader.data = result2[1];
          PCDheader.headerLen = result2[0].length + result1;
          PCDheader.str = data.substr(0, PCDheader.headerLen);

          // remove comments
          PCDheader.str = PCDheader.str.replace(/\#.*/gi, '');

          // parse
          PCDheader.version = /VERSION (.*)/i.exec(PCDheader.str);
          PCDheader.fields = /FIELDS (.*)/i.exec(PCDheader.str);
          PCDheader.size = /SIZE (.*)/i.exec(PCDheader.str);
          PCDheader.type = /TYPE (.*)/i.exec(PCDheader.str);
          PCDheader.count = /COUNT (.*)/i.exec(PCDheader.str);
          PCDheader.width = /WIDTH (.*)/i.exec(PCDheader.str);
          PCDheader.height = /HEIGHT (.*)/i.exec(PCDheader.str);
          PCDheader.viewpoint = /VIEWPOINT (.*)/i.exec(PCDheader.str);
          PCDheader.points = /POINTS (.*)/i.exec(PCDheader.str);
          // evaluate
          if (PCDheader.version !== null) PCDheader.version = parseFloat(PCDheader.version[1]);
          if (PCDheader.fields !== null) PCDheader.fields = PCDheader.fields[1].split(' ');
          if (PCDheader.type !== null) PCDheader.type = PCDheader.type[1].split(' ');
          if (PCDheader.width !== null) PCDheader.width = parseInt(PCDheader.width[1]);
          if (PCDheader.height !== null) PCDheader.height = parseInt(PCDheader.height[1]);
          if (PCDheader.viewpoint !== null) PCDheader.viewpoint = PCDheader.viewpoint[1];
          if (PCDheader.points !== null) PCDheader.points = parseInt(PCDheader.points[1], 10);
          if (PCDheader.points === null) PCDheader.points = PCDheader.width * PCDheader.height;
          if (PCDheader.size !== null) {
            PCDheader.size = PCDheader.size[1].split(' ').map(function (x) {
              return parseInt(x, 10);
            });
          }
          const split = PCDheader.viewpoint.split(" ");
          PCDheader.viewpoint = {
            tx: split[0],
            ty: split[1],
            tz: split[2],
            qw: split[3],
            qx: split[4],
            qy: split[5],
            qz: split[6]
          };
          if (PCDheader.count !== null) {
            PCDheader.count = PCDheader.count[1].split(' ').map(function (x) {
              return parseInt(x, 10);
            });
          } else {
            PCDheader.count = [];
            for (let i = 0, l = PCDheader.fields.length; i < l; i++) {
              PCDheader.count.push(1);
            }
          }
          PCDheader.offset = {};
          var sizeSum = 0;
          for (let i = 0, l = PCDheader.fields.length; i < l; i++) {
            if (PCDheader.data === 'ascii') {
              PCDheader.offset[PCDheader.fields[i]] = i;
            } else {
              PCDheader.offset[PCDheader.fields[i]] = sizeSum;
              sizeSum += PCDheader.size[i];
            }
          }
          PCDheader.rowSize = sizeSum;
          return PCDheader;
        }
        var textData = this.serverMode ? Buffer.from(data).toString() : THREE.LoaderUtils.decodeText(data);

        // parse header (always ascii format)
        var PCDheader = parseHeader(textData);

        // parse data

        var position = [];
        var color = [];
        var label = [];
        var payload = [];
        var rgb = [];
        if (PCDheader.data === 'ascii') {
          const meta = PCDheader;
          let camPosition = new THREE.Vector3(parseFloat(meta.viewpoint.tx), parseFloat(meta.viewpoint.ty), parseFloat(meta.viewpoint.tz));
          let camQuaternion = new THREE.Quaternion(meta.viewpoint.qx, meta.viewpoint.qy, meta.viewpoint.qz, meta.viewpoint.qw);
          var offset = PCDheader.offset;
          var pcdData = textData.substr(PCDheader.headerLen);
          var lines = pcdData.split('\n');
          let pt, item;
          for (var i = 0, l = lines.length - 1; i < l; i++) {
            if (lines[i] == "") {
              continue;
            } // Sometimes empty lines are inserted...

            var line = lines[i].split(' ');
            item = {};
            payload.push(item);
            pt = new THREE.Vector3(parseFloat(line[offset.x]), parseFloat(line[offset.y]), parseFloat(line[offset.z]));
            if (!this.serverMode) {
              pt = pt.sub(camPosition);
              pt.applyQuaternion(camQuaternion);
            }
            item.x = pt.x;
            position.push(pt.x);
            item.y = pt.y;
            position.push(pt.y);
            item.z = pt.z;
            position.push(pt.z);
            if (offset.label !== undefined) {
              const classIndex = parseInt(line[offset.label]) || 0;
              item.classIndex = classIndex;
              label.push(classIndex);
            } else {
              item.classIndex = 0;
              label.push(0);
            }

            // Initialize colors
            if (offset.rgb != undefined) {
              var colorRGB = parseInt(line[offset.rgb]);
              var r = colorRGB >> 16 & 0x0000ff;
              var g = colorRGB >> 8 & 0x0000ff;
              var b = colorRGB & 0x0000ff;
              rgb.push([r, g, b]);
            }
            color.push(0);
            color.push(0);
            color.push(0);
          }
        }

        // binary-compressed
        // normally data in PCD files are organized as array of structures: XYZRGBXYZRGB
        // binary compressed PCD files organize their data as structure of arrays: XXYYZZRGBRGB
        // that requires a totally different parsing approach compared to non-compressed data
        if (PCDheader.data === 'binary_compressed') {
          var dataview = new DataView(data.slice(PCDheader.headerLen, PCDheader.headerLen + 8));
          var compressedSize = dataview.getUint32(0, true);
          var decompressedSize = dataview.getUint32(4, true);
          var decompressed = decompressLZF(new Uint8Array(data, PCDheader.headerLen + 8, compressedSize), decompressedSize);
          dataview = new DataView(decompressed.buffer);
          var offset = PCDheader.offset;
          let pt, item;
          let camPosition = new THREE.Vector3(parseFloat(PCDheader.viewpoint.tx), parseFloat(PCDheader.viewpoint.ty), parseFloat(PCDheader.viewpoint.tz));
          let camQuaternion = new THREE.Quaternion(PCDheader.viewpoint.qx, PCDheader.viewpoint.qy, PCDheader.viewpoint.qz, PCDheader.viewpoint.qw);
          for (var i = 0; i < PCDheader.points; i++) {
            item = {};
            payload.push(item);
            const x = dataview.getFloat32(PCDheader.points * offset.x + PCDheader.size[0] * i, true);
            const y = dataview.getFloat32(PCDheader.points * offset.y + PCDheader.size[1] * i, true);
            const z = dataview.getFloat32(PCDheader.points * offset.z + PCDheader.size[2] * i, true);
            pt = new THREE.Vector3(x, y, z);
            if (!this.serverMode) {
              pt = pt.sub(camPosition);
              pt.applyQuaternion(camQuaternion);
            }
            item.x = pt.x;
            position.push(pt.x);
            item.y = pt.y;
            position.push(pt.y);
            item.z = pt.z;
            position.push(pt.z);
            if (offset.label !== undefined) {
              const classIndex = dataview.getUint8(PCDheader.points * offset.label + PCDheader.size[3] * i);
              item.classIndex = classIndex;
              label.push(classIndex);
            } else {
              item.classIndex = 0;
              label.push(0);
            }

            // Initialize colors
            if (offset.rgb != undefined) {
              var colorRGB = dataview.getUint32(row + offset.rgb, true);
              var r = colorRGB >> 16 & 0x0000ff;
              var g = colorRGB >> 8 & 0x0000ff;
              var b = colorRGB & 0x0000ff;
              rgb.push([r, g, b]);
            }
            color.push(0);
            color.push(0);
            color.push(0);
          }
        }

        // binary

        if (PCDheader.data === 'binary') {
          var dataview = new DataView(data, PCDheader.headerLen);
          var offset = PCDheader.offset;
          let pt, item;
          // test.push(offset);
          let camPosition = new THREE.Vector3(parseFloat(PCDheader.viewpoint.tx), parseFloat(PCDheader.viewpoint.ty), parseFloat(PCDheader.viewpoint.tz));
          let camQuaternion = new THREE.Quaternion(PCDheader.viewpoint.qx, PCDheader.viewpoint.qy, PCDheader.viewpoint.qz, PCDheader.viewpoint.qw);
          for (var i = 0, row = 0; i < PCDheader.points; i++, row += PCDheader.rowSize) {
            item = {};
            payload.push(item);
            const x = dataview.getFloat32(row + offset.x, true);
            const y = dataview.getFloat32(row + offset.y, true);
            const z = dataview.getFloat32(row + offset.z, true);
            pt = new THREE.Vector3(x, y, z);
            if (!this.serverMode) {
              pt = pt.sub(camPosition);
              pt.applyQuaternion(camQuaternion);
            }
            item.x = pt.x;
            position.push(pt.x);
            item.y = pt.y;
            position.push(pt.y);
            item.z = pt.z;
            position.push(pt.z);
            if (offset.label !== undefined) {
              const classIndex = dataview.getUint8(row + offset.label);
              item.classIndex = classIndex;
              label.push(classIndex);
            } else {
              item.classIndex = 0;
              label.push(0);
            }

            // Initialize colors
            if (offset.rgb != undefined) {
              var colorRGB = dataview.getUint32(row + offset.rgb, true);
              var r = colorRGB >> 16 & 0x0000ff;
              var g = colorRGB >> 8 & 0x0000ff;
              var b = colorRGB & 0x0000ff;
              rgb.push([r, g, b]);
            }
            color.push(0);
            color.push(0);
            color.push(0);
          }
        }

        // build geometry

        var geometry = new THREE.BufferGeometry();
        if (position.length > 0) geometry.setAttribute('position', new THREE.Float32BufferAttribute(position, 3));
        if (label.length > 0) geometry.setAttribute('label', new THREE.Uint8BufferAttribute(label, 3));
        if (color.length > 0) {
          const colorAtt = new THREE.Float32BufferAttribute(color, 3);
          geometry.setAttribute('color', colorAtt);
        }
        geometry.computeBoundingSphere();
        var material = new THREE.PointsMaterial({
          size: 2,
          color: 0xE9A96F
        });
        material.sizeAttenuation = false;

        // build mesh
        var mesh = new THREE.Points(geometry, material);
        var name = url.split('').reverse().join('');
        name = /([^\/]*)/.exec(name);
        name = name[1].split('').reverse().join('');
        mesh.name = url;
        return {
          position,
          label,
          header: PCDheader,
          rgb
        };
      }
    };
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"SseDataWorkerServer.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/SseDataWorkerServer.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
function FastIntegerCompression() {}
function bytelog(val) {
  if (val < 1 << 7) {
    return 1;
  } else if (val < 1 << 14) {
    return 2;
  } else if (val < 1 << 21) {
    return 3;
  } else if (val < 1 << 28) {
    return 4;
  }
  return 5;
}

// compute how many bytes an array of integers would use once compressed
FastIntegerCompression.computeCompressedSizeInBytes = function (input) {
  var c = input.length;
  var answer = 0;
  for (var i = 0; i < c; i++) {
    answer += bytelog(input[i]);
  }
  return answer;
};

// compress an array of integers, return a compressed buffer (as an ArrayBuffer)
FastIntegerCompression.compress = function (input) {
  var c = input.length;
  var buf = new ArrayBuffer(FastIntegerCompression.computeCompressedSizeInBytes(input));
  var view = new Int8Array(buf);
  var pos = 0;
  for (var i = 0; i < c; i++) {
    var val = input[i];
    if (val < 1 << 7) {
      view[pos++] = val;
    } else if (val < 1 << 14) {
      view[pos++] = val & 0x7F | 0x80;
      view[pos++] = val >>> 7;
    } else if (val < 1 << 21) {
      view[pos++] = val & 0x7F | 0x80;
      view[pos++] = val >>> 7 & 0x7F | 0x80;
      view[pos++] = val >>> 14;
    } else if (val < 1 << 28) {
      view[pos++] = val & 0x7F | 0x80;
      view[pos++] = val >>> 7 & 0x7F | 0x80;
      view[pos++] = val >>> 14 & 0x7F | 0x80;
      view[pos++] = val >>> 21;
    } else {
      view[pos++] = val & 0x7F | 0x80;
      view[pos++] = val >>> 7 & 0x7F | 0x80;
      view[pos++] = val >>> 14 & 0x7F | 0x80;
      view[pos++] = val >>> 21 & 0x7F | 0x80;
      view[pos++] = val >>> 28;
    }
  }
  return buf;
};

// from a compressed array of integers stored ArrayBuffer, compute the number of compressed integers by scanning the input
FastIntegerCompression.computeHowManyIntegers = function (input) {
  var view = new Int8Array(input);
  var c = view.length;
  var count = 0;
  for (var i = 0; i < c; i++) {
    count += input[i] >>> 7;
  }
  return c - count;
};
// uncompress an array of integer from an ArrayBuffer, return the array
FastIntegerCompression.uncompress = function (input) {
  var array = [];
  var inbyte = new Int8Array(input);
  var end = inbyte.length;
  var pos = 0;
  while (end > pos) {
    var c = inbyte[pos++];
    var v = c & 0x7F;
    if (c >= 0) {
      array.push(v);
      continue;
    }
    c = inbyte[pos++];
    v |= (c & 0x7F) << 7;
    if (c >= 0) {
      array.push(v);
      continue;
    }
    c = inbyte[pos++];
    v |= (c & 0x7F) << 14;
    if (c >= 0) {
      array.push(v);
      continue;
    }
    c = inbyte[pos++];
    v |= (c & 0x7F) << 21;
    if (c >= 0) {
      array.push(v);
      continue;
    }
    c = inbyte[pos++];
    v |= c << 28;
    array.push(v);
  }
  return array;
};
LZW = {
  compress: function (uncompressed) {
    "use strict";

    // Build the dictionary.
    var i,
      dictionary = {},
      c,
      wc,
      w = "",
      result = [],
      dictSize = 256;
    for (i = 0; i < 256; i += 1) {
      dictionary[String.fromCharCode(i)] = i;
    }
    for (i = 0; i < uncompressed.length; i += 1) {
      c = uncompressed.charAt(i);
      wc = w + c;
      //Do not use dictionary[wc] because javascript arrays
      //will return values for array['pop'], array['push'] etc
      // if (dictionary[wc]) {
      if (dictionary.hasOwnProperty(wc)) {
        w = wc;
      } else {
        result.push(dictionary[w]);
        // Add wc to the dictionary.
        dictionary[wc] = dictSize++;
        w = String(c);
      }
    }

    // Output the code for w.
    if (w !== "") {
      result.push(dictionary[w]);
    }
    return result;
  },
  decompress: function (compressed) {
    "use strict";

    // Build the dictionary.
    var i,
      dictionary = [],
      w,
      result,
      k,
      entry = "",
      dictSize = 256;
    for (i = 0; i < 256; i += 1) {
      dictionary[i] = String.fromCharCode(i);
    }
    w = String.fromCharCode(compressed[0]);
    result = w;
    for (i = 1; i < compressed.length; i += 1) {
      k = compressed[i];
      if (dictionary[k]) {
        entry = dictionary[k];
      } else {
        if (k === dictSize) {
          entry = w + w.charAt(0);
        } else {
          return null;
        }
      }
      result += entry;
      dictionary[dictSize++] = w + entry.charAt(0);
      w = entry;
    }
    return result;
  }
};
function objectToBytes(obj) {
  let payload = JSON.stringify(obj);
  payload = LZW.compress(payload);
  payload = FastIntegerCompression.compress(payload);
  return payload;
}
function bytesToObject(bytes) {
  if (bytes.byteLength > 0) {
    const data = FastIntegerCompression.uncompress(bytes);
    const str = LZW.decompress(data);
    return JSON.parse(str);
  } else return null;
}
module.exportDefault({
  compress: data => objectToBytes(data),
  uncompress: data => bytesToObject(data)
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"api.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/api.js                                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let SseDataWorkerServer;
module.link("./SseDataWorkerServer", {
  default(v) {
    SseDataWorkerServer = v;
  }
}, 0);
let configurationFile;
module.link("./config", {
  default(v) {
    configurationFile = v;
  }
}, 1);
let basename;
module.link("path", {
  basename(v) {
    basename = v;
  }
}, 2);
let readFile;
module.link("fs", {
  readFile(v) {
    readFile = v;
  }
}, 3);
let THREE;
module.link("three", {
  "*"(v) {
    THREE = v;
  }
}, 4);
let SsePCDLoader;
module.link("../imports/editor/3d/SsePCDLoader", {
  default(v) {
    SsePCDLoader = v;
  }
}, 5);
WebApp.connectHandlers.use("/api/json", generateJson);
WebApp.connectHandlers.use("/api/pcdtext", generatePCDOutput.bind({
  fileMode: false
}));
WebApp.connectHandlers.use("/api/pcdfile", generatePCDOutput.bind({
  fileMode: true
}));
WebApp.connectHandlers.use("/api/listing", imagesListing);
const {
  imagesFolder,
  pointcloudsFolder,
  setsOfClassesMap
} = configurationFile;
new SsePCDLoader(THREE);
function imagesListing(req, res, next) {
  const all = SseSamples.find({}, {
    fields: {
      url: 1,
      folder: 1,
      file: 1,
      tags: 1,
      firstEditDate: 1,
      lastEditDate: 1
    }
  }).fetch();
  res.end(JSON.stringify(all, null, 1));
}
function generateJson(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  const item = SseSamples.findOne({
    url: req.url
  });
  if (item) {
    const soc = setsOfClassesMap.get(item.socName);
    item.objects.forEach(obj => {
      obj.label = soc.objects[obj.classIndex].label;
    });
    res.end(JSON.stringify(item, null, 1));
  } else {
    res.end("{}");
  }
}
function generatePCDOutput(req, res, next) {
  const pcdFile = imagesFolder + decodeURIComponent(req.url);
  const fileName = basename(pcdFile);
  const labelFile = pointcloudsFolder + decodeURIComponent(req.url) + ".labels";
  const objectFile = pointcloudsFolder + decodeURIComponent(req.url) + ".objects";
  if (this.fileMode) {
    res.setHeader('Content-disposition', 'attachment; filename=DOC'.replace("DOC", fileName));
    res.setHeader('Content-type', 'text/plain');
    res.charset = 'UTF-8';
  }
  readFile(pcdFile, (err, content) => {
    if (err) {
      res.end("Error while parsing PCD file.");
    }
    const loader = new THREE.PCDLoader(true);
    const pcdContent = loader.parse(content.buffer, "");
    const hasRgb = pcdContent.rgb.length > 0;
    const head = pcdContent.header;
    const rgb2int = rgb => rgb[2] + 256 * rgb[1] + 256 * 256 * rgb[0];
    let out = "VERSION .7\n";
    out += hasRgb ? "FIELDS x y z rgb label object\n" : "FIELDS x y z label object\n";
    out += hasRgb ? "SIZE 4 4 4 4 4 4\n" : "SIZE 4 4 4 4 4\n";
    out += hasRgb ? "TYPE F F F I I I\n" : "TYPE F F F I I\n";
    out += hasRgb ? "COUNT 1 1 1 1 1 1\n" : "COUNT 1 1 1 1 1\n";
    out += "WIDTH " + pcdContent.header.width + "\n";
    out += "HEIGHT " + pcdContent.header.height + "\n";
    out += "POINTS " + pcdContent.header.width * pcdContent.header.height + "\n";
    out += "VIEWPOINT " + head.viewpoint.tx;
    out += " " + head.viewpoint.ty;
    out += " " + head.viewpoint.tz;
    out += " " + head.viewpoint.qw;
    out += " " + head.viewpoint.qx;
    out += " " + head.viewpoint.qy;
    out += " " + head.viewpoint.qz + "\n";
    out += "DATA ascii\n";
    res.write(out);
    out = "";
    readFile(labelFile, (labelErr, labelContent) => {
      if (labelErr) {
        res.end("Error while parsing labels file.");
      }
      const labels = SseDataWorkerServer.uncompress(labelContent);
      readFile(objectFile, (objectErr, objectContent) => {
        let objectsAvailable = true;
        if (objectErr) {
          objectsAvailable = false;
        }
        const objectByPointIndex = new Map();
        if (objectsAvailable) {
          const objects = SseDataWorkerServer.uncompress(objectContent);
          objects.forEach((obj, objIndex) => {
            obj.points.forEach(ptIdx => {
              objectByPointIndex.set(ptIdx, objIndex);
            });
          });
        }
        let obj;
        pcdContent.position.forEach((v, i) => {
          const position = Math.floor(i / 3);
          switch (i % 3) {
            case 0:
              if (hasRgb) {
                obj = {
                  rgb: pcdContent.rgb[position],
                  x: v
                };
              } else {
                obj = {
                  x: v
                };
              }
              break;
            case 1:
              obj.y = v;
              break;
            case 2:
              obj.z = v;
              out += obj.x + " " + obj.y + " " + obj.z + " ";
              if (hasRgb) {
                out += rgb2int(obj.rgb) + " ";
              }
              out += labels[position] + " ";
              const assignedObject = objectByPointIndex.get(position);
              if (assignedObject != undefined) out += assignedObject;else out += "-1";
              out += "\n";
              res.write(out);
              out = "";
              break;
          }
        });
        res.end();
      });
    });
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"config.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/config.js                                                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let join;
module.link("path", {
  join(v) {
    join = v;
  }
}, 1);
let mkdirSync, existsSync;
module.link("fs", {
  mkdirSync(v) {
    mkdirSync = v;
  },
  existsSync(v) {
    existsSync = v;
  }
}, 2);
let os;
module.link("os", {
  default(v) {
    os = v;
  }
}, 3);
let download;
module.link("download", {
  default(v) {
    download = v;
  }
}, 4);
const configurationFile = {};
const defaultClasses = [{
  "name": "33 Classes",
  "objects": [{
    "label": "VOID",
    "color": "#CFCFCF"
  }, {
    "label": "Class 1"
  }, {
    "label": "Class 2"
  }, {
    "label": "Class 3"
  }, {
    "label": "Class 4"
  }, {
    "label": "Class 5"
  }, {
    "label": "Class 6"
  }, {
    "label": "Class 7"
  }, {
    "label": "Class 8"
  }, {
    "label": "Class 9"
  }, {
    "label": "Class 10"
  }, {
    "label": "Class 11"
  }, {
    "label": "Class 12"
  }, {
    "label": "Class 13"
  }, {
    "label": "Class 14"
  }, {
    "label": "Class 15"
  }, {
    "label": "Class 16"
  }, {
    "label": "Class 17"
  }, {
    "label": "Class 18"
  }, {
    "label": "Class 19"
  }, {
    "label": "Class 20"
  }, {
    "label": "Class 21"
  }, {
    "label": "Class 22"
  }, {
    "label": "Class 23"
  }, {
    "label": "Class 24"
  }, {
    "label": "Class 25"
  }, {
    "label": "Class 26"
  }, {
    "label": "Class 27"
  }, {
    "label": "Class 28"
  }, {
    "label": "Class 29"
  }, {
    "label": "Class 30"
  }, {
    "label": "Class 31"
  }, {
    "label": "Class 32"
  }]
}];
const init = () => {
  try {
    const config = Meteor.settings;
    if (config.configuration && config.configuration["images-folder"] != "") {
      configurationFile.imagesFolder = config.configuration["images-folder"].replace(/\/$/, "");
    } else {
      configurationFile.imagesFolder = join(os.homedir(), "sse-images");
    }
    if (!existsSync(configurationFile.imagesFolder)) {
      mkdirSync(configurationFile.imagesFolder);
      download("https://raw.githubusercontent.com/Hitachi-Automotive-And-Industry-Lab/semantic-segmentation-editor/master/private/samples/bitmap_labeling.png", configurationFile.imagesFolder);
      download("https://raw.githubusercontent.com/Hitachi-Automotive-And-Industry-Lab/semantic-segmentation-editor/master/private/samples/pointcloud_labeling.pcd", configurationFile.imagesFolder);
    }
    if (config.configuration && config.configuration["internal-folder"] != "") {
      configurationFile.pointcloudsFolder = config.configuration["internal-folder"].replace(/\/$/, "");
    } else {
      configurationFile.pointcloudsFolder = join(os.homedir(), "sse-internal");
    }
    configurationFile.setsOfClassesMap = new Map();
    configurationFile.setsOfClasses = config["sets-of-classes"];
    if (!configurationFile.setsOfClasses) {
      configurationFile.setsOfClasses = defaultClasses;
    }
    configurationFile.setsOfClasses.forEach(o => configurationFile.setsOfClassesMap.set(o.name, o));
    console.log("Semantic Segmentation Editor");
    console.log("Images (JPG, PNG, PCD) served from", configurationFile.imagesFolder);
    console.log("PCD binary segmentation data stored in", configurationFile.pointcloudsFolder);
    console.log("Number of available sets of object classes:", configurationFile.setsOfClasses.length);
    return configurationFile;
  } catch (e) {
    console.error("Error while parsing settings.json:", e);
  }
};
module.exportDefault(init());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"files.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/files.js                                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let shell;
module.link("shelljs", {
  default(v) {
    shell = v;
  }
}, 1);
let serveStatic;
module.link("serve-static", {
  default(v) {
    serveStatic = v;
  }
}, 2);
let bodyParser;
module.link("body-parser", {
  default(v) {
    bodyParser = v;
  }
}, 3);
let createWriteStream, lstatSync, readdirSync, readFile, readFileSync;
module.link("fs", {
  createWriteStream(v) {
    createWriteStream = v;
  },
  lstatSync(v) {
    lstatSync = v;
  },
  readdirSync(v) {
    readdirSync = v;
  },
  readFile(v) {
    readFile = v;
  },
  readFileSync(v) {
    readFileSync = v;
  }
}, 4);
let basename, extname, join;
module.link("path", {
  basename(v) {
    basename = v;
  },
  extname(v) {
    extname = v;
  },
  join(v) {
    join = v;
  }
}, 5);
let configurationFile;
module.link("./config", {
  default(v) {
    configurationFile = v;
  }
}, 6);
const demoMode = Meteor.settings.configuration["demo-mode"];
Meteor.startup(() => {
  const {
    imagesFolder,
    pointcloudsFolder
  } = configurationFile;
  WebApp.connectHandlers.use("/file", serveStatic(imagesFolder, {
    fallthrough: false
  }));
  WebApp.connectHandlers.use("/datafile", serveStatic(pointcloudsFolder, {
    fallthrough: true
  }));
  WebApp.connectHandlers.use("/datafile", (req, res) => {
    res.end("");
  });
  WebApp.connectHandlers.use(bodyParser.raw({
    limit: "200mb",
    type: 'application/octet-stream'
  }));
  WebApp.connectHandlers.use('/save', function (req, res) {
    if (demoMode) return;
    const fileToSave = pointcloudsFolder + decodeURIComponent(req.url).replace("/save", "");
    const dir = fileToSave.match("(.*\/).*")[1];
    shell.mkdir('-p', dir);
    var wstream = createWriteStream(fileToSave);
    wstream.write(req.body);
    wstream.end();
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.end("Sent: " + fileToSave);
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let createWriteStream, lstatSync, readdirSync, readFile, readFileSync, existsSync;
module.link("fs", {
  createWriteStream(v) {
    createWriteStream = v;
  },
  lstatSync(v) {
    lstatSync = v;
  },
  readdirSync(v) {
    readdirSync = v;
  },
  readFile(v) {
    readFile = v;
  },
  readFileSync(v) {
    readFileSync = v;
  },
  existsSync(v) {
    existsSync = v;
  }
}, 1);
let basename, extname, join;
module.link("path", {
  basename(v) {
    basename = v;
  },
  extname(v) {
    extname = v;
  },
  join(v) {
    join = v;
  }
}, 2);
let url;
module.link("url", {
  default(v) {
    url = v;
  }
}, 3);
let ColorScheme;
module.link("color-scheme", {
  default(v) {
    ColorScheme = v;
  }
}, 4);
let config;
module.link("./config", {
  default(v) {
    config = v;
  }
}, 5);
const demoMode = Meteor.settings.configuration["demo-mode"];
let {
  classes
} = config;
Meteor.methods({
  'getClassesSets'() {
    const data = config.setsOfClasses;
    const scheme = new ColorScheme();
    scheme.from_hue(0) // Start the scheme
    .scheme('tetrade') // Use the 'triade' scheme, that is, colors
    // selected from 3 points equidistant around
    // the color wheel.
    .variation('soft'); // Use the 'soft' color variation
    let colors = scheme.colors();
    scheme.from_hue(10) // Start the scheme
    .scheme('tetrade') // Use the 'triade' scheme, that is, colors
    // selected from 3 points equidistant around
    // the color wheel.
    .variation('pastel'); // Use the 'soft' color variation
    colors = colors.concat(scheme.colors());
    scheme.from_hue(20) // Start the scheme
    .scheme('tetrade') // Use the 'triade' scheme, that is, colors
    // selected from 3 points equidistant around
    // the color wheel.
    .variation('hard'); // Use the 'soft' color variation
    colors = colors.concat(scheme.colors());
    scheme.from_hue(30) // Start the scheme
    .scheme('tetrade') // Use the 'triade' scheme, that is, colors
    // selected from 3 points equidistant around
    // the color wheel.
    .variation('hard'); // Use the 'soft' color variation
    colors = colors.concat(scheme.colors());
    scheme.from_hue(40) // Start the scheme
    .scheme('tetrade') // Use the 'triade' scheme, that is, colors
    // selected from 3 points equidistant around
    // the color wheel.
    .variation('hard'); // Use the 'soft' color variation
    colors = colors.concat(scheme.colors());
    colors = colors.map(c => "#" + c);
    data.forEach(soc => {
      soc.objects.forEach((oc, i) => {
        if (!oc.color) {
          oc.color = colors[i];
        }
      });
    });
    return data;
  },
  /*
      'rebuildTagList'() {
          const all = SseSamples.find().fetch();
          const tags = new Set();
          all.forEach(s => {
              if (s.tags) {
                  s.tags.forEach(t => {
                      tags.add(t)
                  })
              }
          });
          SseProps.remove({});
          SseProps.upsert({key: "tags"}, {key: "tags", value: Array.from(tags)});
      },
  */
  'images'(folder, pageIndex, pageLength) {
    const isDirectory = source => lstatSync(source).isDirectory();
    const isImage = source => {
      const stat = lstatSync(source);
      return (stat.isFile() || stat.isSymbolicLink()) && (extname(source).toLowerCase() == ".bmp" || extname(source).toLowerCase() == ".jpeg" || extname(source).toLowerCase() == ".jpg" || extname(source).toLowerCase() == ".pcd" || extname(source).toLowerCase() == ".png");
    };
    const getDirectories = source => readdirSync(source).map(name => join(source, name)).filter(isDirectory).map(a => basename(a));
    const getImages = source => readdirSync(source).map(name => join(source, name)).filter(isImage);
    const getImageDesc = path => {
      return {
        name: basename(path),
        editUrl: "/edit/" + encodeURIComponent(folderSlash + basename(path)),
        url: (folderSlash ? "/" + folderSlash : "") + "" + basename(path)
      };
    };
    const getFolderDesc = path => {
      return {
        name: basename(path),
        url: "/browse/".concat(pageIndex, "/").concat(pageLength, "/") + encodeURIComponent(folderSlash + path)
      };
    };
    pageIndex = parseInt(pageIndex);
    pageLength = parseInt(pageLength);
    const folderSlash = folder ? decodeURIComponent(folder) + "/" : "/";
    const leaf = join(config.imagesFolder, folderSlash ? folderSlash : "");
    const existing = existsSync(leaf);
    if (existing && !isDirectory(leaf)) {
      return {
        error: leaf + " is a file but should be a folder. Check the documentation and your settings.json"
      };
    }
    if (!existing) {
      return {
        error: leaf + " does not exists. Check the documentation and your settings.json"
      };
    }
    const dirs = getDirectories(leaf);
    const images = getImages(leaf);
    const res = {
      folders: dirs.map(getFolderDesc),
      images: images.map(getImageDesc).slice(pageIndex * pageLength, pageIndex * pageLength + pageLength),
      imagesCount: images.length
    };
    if (pageIndex * pageLength + pageLength < images.length) {
      res.nextPage = "/browse/".concat(pageIndex + 1, "/").concat(pageLength, "/") + (folder ? encodeURIComponent(folder) : "");
    }
    if (pageIndex > 0) {
      res.previousPage = "/browse/".concat(pageIndex - 1, "/").concat(pageLength, "/") + (folder ? encodeURIComponent(folder) : "");
    }
    return res;
  },
  'saveData'(sample) {
    if (demoMode) return;
    const attrs = url.parse(sample.url);
    let path = decodeURIComponent(attrs.pathname);
    sample.folder = path.substring(1, path.lastIndexOf("/"));
    sample.file = path.substring(path.lastIndexOf("/") + 1);
    sample.lastEditDate = new Date();
    if (!sample.firstEditDate) sample.firstEditDate = new Date();
    if (sample.tags) {
      SseProps.upsert({
        key: "tags"
      }, {
        $addToSet: {
          value: {
            $each: sample.tags
          }
        }
      });
    }
    SseSamples.upsert({
      url: sample.url
    }, sample);
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".jsx"
  ]
});

require("/lib/collections.js");
require("/server/SseDataWorkerServer.js");
require("/server/api.js");
require("/server/config.js");
require("/server/files.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2VkaXRvci8zZC9Tc2VQQ0RMb2FkZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9Tc2VEYXRhV29ya2VyU2VydmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29uZmlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZmlsZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiU3NlU2FtcGxlcyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIlNzZVByb3BzIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwiaW1hZ2VVcmwiLCJmaW5kIiwidXJsIiwiJHdoZXJlIiwiZmllbGRzIiwiZmlsZSIsImV4cG9ydCIsImRlZmF1bHQiLCJTc2VQQ0RMb2FkZXIiLCJjb25zdHJ1Y3RvciIsIlRIUkVFIiwiUENETG9hZGVyIiwic2VydmVyTW9kZSIsInByb3RvdHlwZSIsImxvYWQiLCJvbkxvYWQiLCJvblByb2dyZXNzIiwib25FcnJvciIsInNjb3BlIiwibG9hZGVyIiwiRmlsZUxvYWRlciIsIm1hbmFnZXIiLCJzZXRSZXNwb25zZVR5cGUiLCJkYXRhIiwicGFyc2UiLCJkZWNvbXByZXNzTFpGIiwiaW5EYXRhIiwib3V0TGVuZ3RoIiwiaW5MZW5ndGgiLCJsZW5ndGgiLCJvdXREYXRhIiwiVWludDhBcnJheSIsImluUHRyIiwib3V0UHRyIiwiY3RybCIsImxlbiIsInJlZiIsIkVycm9yIiwicGFyc2VIZWFkZXIiLCJQQ0RoZWFkZXIiLCJyZXN1bHQxIiwic2VhcmNoIiwicmVzdWx0MiIsImV4ZWMiLCJzdWJzdHIiLCJoZWFkZXJMZW4iLCJzdHIiLCJyZXBsYWNlIiwidmVyc2lvbiIsInNpemUiLCJ0eXBlIiwiY291bnQiLCJ3aWR0aCIsImhlaWdodCIsInZpZXdwb2ludCIsInBvaW50cyIsInBhcnNlRmxvYXQiLCJzcGxpdCIsInBhcnNlSW50IiwibWFwIiwieCIsInR4IiwidHkiLCJ0eiIsInF3IiwicXgiLCJxeSIsInF6IiwiaSIsImwiLCJwdXNoIiwib2Zmc2V0Iiwic2l6ZVN1bSIsInJvd1NpemUiLCJ0ZXh0RGF0YSIsIkJ1ZmZlciIsImZyb20iLCJ0b1N0cmluZyIsIkxvYWRlclV0aWxzIiwiZGVjb2RlVGV4dCIsInBvc2l0aW9uIiwiY29sb3IiLCJsYWJlbCIsInBheWxvYWQiLCJyZ2IiLCJtZXRhIiwiY2FtUG9zaXRpb24iLCJWZWN0b3IzIiwiY2FtUXVhdGVybmlvbiIsIlF1YXRlcm5pb24iLCJwY2REYXRhIiwibGluZXMiLCJwdCIsIml0ZW0iLCJsaW5lIiwieSIsInoiLCJzdWIiLCJhcHBseVF1YXRlcm5pb24iLCJ1bmRlZmluZWQiLCJjbGFzc0luZGV4IiwiY29sb3JSR0IiLCJyIiwiZyIsImIiLCJkYXRhdmlldyIsIkRhdGFWaWV3Iiwic2xpY2UiLCJjb21wcmVzc2VkU2l6ZSIsImdldFVpbnQzMiIsImRlY29tcHJlc3NlZFNpemUiLCJkZWNvbXByZXNzZWQiLCJidWZmZXIiLCJnZXRGbG9hdDMyIiwiZ2V0VWludDgiLCJyb3ciLCJnZW9tZXRyeSIsIkJ1ZmZlckdlb21ldHJ5Iiwic2V0QXR0cmlidXRlIiwiRmxvYXQzMkJ1ZmZlckF0dHJpYnV0ZSIsIlVpbnQ4QnVmZmVyQXR0cmlidXRlIiwiY29sb3JBdHQiLCJjb21wdXRlQm91bmRpbmdTcGhlcmUiLCJtYXRlcmlhbCIsIlBvaW50c01hdGVyaWFsIiwic2l6ZUF0dGVudWF0aW9uIiwibWVzaCIsIlBvaW50cyIsIm5hbWUiLCJyZXZlcnNlIiwiam9pbiIsImhlYWRlciIsIkZhc3RJbnRlZ2VyQ29tcHJlc3Npb24iLCJieXRlbG9nIiwidmFsIiwiY29tcHV0ZUNvbXByZXNzZWRTaXplSW5CeXRlcyIsImlucHV0IiwiYyIsImFuc3dlciIsImNvbXByZXNzIiwiYnVmIiwiQXJyYXlCdWZmZXIiLCJ2aWV3IiwiSW50OEFycmF5IiwicG9zIiwiY29tcHV0ZUhvd01hbnlJbnRlZ2VycyIsInVuY29tcHJlc3MiLCJhcnJheSIsImluYnl0ZSIsImVuZCIsIkxaVyIsInVuY29tcHJlc3NlZCIsImRpY3Rpb25hcnkiLCJ3YyIsInciLCJyZXN1bHQiLCJkaWN0U2l6ZSIsIlN0cmluZyIsImZyb21DaGFyQ29kZSIsImNoYXJBdCIsImhhc093blByb3BlcnR5IiwiZGVjb21wcmVzcyIsImNvbXByZXNzZWQiLCJrIiwiZW50cnkiLCJvYmplY3RUb0J5dGVzIiwib2JqIiwiSlNPTiIsInN0cmluZ2lmeSIsImJ5dGVzVG9PYmplY3QiLCJieXRlcyIsImJ5dGVMZW5ndGgiLCJleHBvcnREZWZhdWx0IiwiU3NlRGF0YVdvcmtlclNlcnZlciIsImNvbmZpZ3VyYXRpb25GaWxlIiwiYmFzZW5hbWUiLCJyZWFkRmlsZSIsIioiLCJXZWJBcHAiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJnZW5lcmF0ZUpzb24iLCJnZW5lcmF0ZVBDRE91dHB1dCIsImJpbmQiLCJmaWxlTW9kZSIsImltYWdlc0xpc3RpbmciLCJpbWFnZXNGb2xkZXIiLCJwb2ludGNsb3Vkc0ZvbGRlciIsInNldHNPZkNsYXNzZXNNYXAiLCJyZXEiLCJyZXMiLCJuZXh0IiwiYWxsIiwiZm9sZGVyIiwidGFncyIsImZpcnN0RWRpdERhdGUiLCJsYXN0RWRpdERhdGUiLCJmZXRjaCIsInNldEhlYWRlciIsImZpbmRPbmUiLCJzb2MiLCJnZXQiLCJzb2NOYW1lIiwib2JqZWN0cyIsImZvckVhY2giLCJwY2RGaWxlIiwiZGVjb2RlVVJJQ29tcG9uZW50IiwiZmlsZU5hbWUiLCJsYWJlbEZpbGUiLCJvYmplY3RGaWxlIiwiY2hhcnNldCIsImVyciIsImNvbnRlbnQiLCJwY2RDb250ZW50IiwiaGFzUmdiIiwiaGVhZCIsInJnYjJpbnQiLCJvdXQiLCJ3cml0ZSIsImxhYmVsRXJyIiwibGFiZWxDb250ZW50IiwibGFiZWxzIiwib2JqZWN0RXJyIiwib2JqZWN0Q29udGVudCIsIm9iamVjdHNBdmFpbGFibGUiLCJvYmplY3RCeVBvaW50SW5kZXgiLCJNYXAiLCJvYmpJbmRleCIsInB0SWR4Iiwic2V0IiwiTWF0aCIsImZsb29yIiwiYXNzaWduZWRPYmplY3QiLCJta2RpclN5bmMiLCJleGlzdHNTeW5jIiwib3MiLCJkb3dubG9hZCIsImRlZmF1bHRDbGFzc2VzIiwiaW5pdCIsImNvbmZpZyIsInNldHRpbmdzIiwiY29uZmlndXJhdGlvbiIsImhvbWVkaXIiLCJzZXRzT2ZDbGFzc2VzIiwibyIsImNvbnNvbGUiLCJsb2ciLCJlIiwiZXJyb3IiLCJzaGVsbCIsInNlcnZlU3RhdGljIiwiYm9keVBhcnNlciIsImNyZWF0ZVdyaXRlU3RyZWFtIiwibHN0YXRTeW5jIiwicmVhZGRpclN5bmMiLCJyZWFkRmlsZVN5bmMiLCJleHRuYW1lIiwiZGVtb01vZGUiLCJzdGFydHVwIiwiZmFsbHRocm91Z2giLCJyYXciLCJsaW1pdCIsImZpbGVUb1NhdmUiLCJkaXIiLCJtYXRjaCIsIm1rZGlyIiwid3N0cmVhbSIsImJvZHkiLCJDb2xvclNjaGVtZSIsImNsYXNzZXMiLCJtZXRob2RzIiwiZ2V0Q2xhc3Nlc1NldHMiLCJzY2hlbWUiLCJmcm9tX2h1ZSIsInZhcmlhdGlvbiIsImNvbG9ycyIsImNvbmNhdCIsIm9jIiwiaW1hZ2VzIiwicGFnZUluZGV4IiwicGFnZUxlbmd0aCIsImlzRGlyZWN0b3J5Iiwic291cmNlIiwiaXNJbWFnZSIsInN0YXQiLCJpc0ZpbGUiLCJpc1N5bWJvbGljTGluayIsInRvTG93ZXJDYXNlIiwiZ2V0RGlyZWN0b3JpZXMiLCJmaWx0ZXIiLCJhIiwiZ2V0SW1hZ2VzIiwiZ2V0SW1hZ2VEZXNjIiwicGF0aCIsImVkaXRVcmwiLCJlbmNvZGVVUklDb21wb25lbnQiLCJmb2xkZXJTbGFzaCIsImdldEZvbGRlckRlc2MiLCJsZWFmIiwiZXhpc3RpbmciLCJkaXJzIiwiZm9sZGVycyIsImltYWdlc0NvdW50IiwibmV4dFBhZ2UiLCJwcmV2aW91c1BhZ2UiLCJzYXZlRGF0YSIsInNhbXBsZSIsImF0dHJzIiwicGF0aG5hbWUiLCJzdWJzdHJpbmciLCJsYXN0SW5kZXhPZiIsIkRhdGUiLCJ1cHNlcnQiLCJrZXkiLCIkYWRkVG9TZXQiLCJ2YWx1ZSIsIiRlYWNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFFL0RDLFVBQVUsR0FBRyxJQUFJQyxLQUFLLENBQUNDLFVBQVUsQ0FBQyxZQUFZLENBQUM7QUFDL0NDLFFBQVEsR0FBRyxJQUFJRixLQUFLLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7QUFFM0MsSUFBSU4sTUFBTSxDQUFDUSxRQUFRLEVBQUU7RUFDakJSLE1BQU0sQ0FBQ1MsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFVBQVVDLFFBQVEsRUFBRTtJQUN0RCxPQUFPTixVQUFVLENBQUNPLElBQUksQ0FBQztNQUFDQyxHQUFHLEVBQUVGO0lBQVEsQ0FBQyxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGVixNQUFNLENBQUNTLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxZQUFZO0lBQzdDLE9BQU9MLFVBQVUsQ0FBQ08sSUFBSSxDQUNsQjtNQUFDRSxNQUFNLEVBQUU7SUFBdUMsQ0FBQyxFQUNqRDtNQUFDQyxNQUFNLEVBQUU7UUFBQ0MsSUFBSSxFQUFFLENBQUM7UUFBRUgsR0FBRyxFQUFFO01BQUM7SUFBQyxDQUM5QixDQUFDO0VBQ0wsQ0FBQyxDQUFDO0VBRUZaLE1BQU0sQ0FBQ1MsT0FBTyxDQUFDLFdBQVcsRUFBRSxZQUFZO0lBQ3BDLE9BQU9GLFFBQVEsQ0FBQ0ksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzVCLENBQUMsQ0FBQztBQUNOLEM7Ozs7Ozs7Ozs7O0FDcEJBVixNQUFNLENBQUNlLE1BQU0sQ0FBQztFQUFDQyxPQUFPLEVBQUNBLENBQUEsS0FBSUM7QUFBWSxDQUFDLENBQUM7QUFDMUIsTUFBTUEsWUFBWSxDQUFDO0VBQzlCQyxXQUFXQSxDQUFDQyxLQUFLLEVBQUU7SUFDZkEsS0FBSyxDQUFDQyxTQUFTLEdBQUcsVUFBVUMsVUFBVSxFQUFFO01BQ3BDLElBQUksQ0FBQ0EsVUFBVSxHQUFHQSxVQUFVO0lBQ2hDLENBQUM7SUFFREYsS0FBSyxDQUFDQyxTQUFTLENBQUNFLFNBQVMsR0FBRztNQUN4QkosV0FBVyxFQUFFQyxLQUFLLENBQUNDLFNBQVM7TUFDNUJHLElBQUksRUFBRSxTQUFBQSxDQUFVWixHQUFHLEVBQUVhLE1BQU0sRUFBRUMsVUFBVSxFQUFFQyxPQUFPLEVBQUU7UUFDOUMsSUFBSUMsS0FBSyxHQUFHLElBQUk7UUFDaEIsSUFBSUMsTUFBTSxHQUFHLElBQUlULEtBQUssQ0FBQ1UsVUFBVSxDQUFDRixLQUFLLENBQUNHLE9BQU8sQ0FBQztRQUNoREYsTUFBTSxDQUFDRyxlQUFlLENBQUMsYUFBYSxDQUFDO1FBQ3JDSCxNQUFNLENBQUNMLElBQUksQ0FBQ1osR0FBRyxFQUFFLFVBQVVxQixJQUFJLEVBQUU7VUFDN0JSLE1BQU0sQ0FBQ0csS0FBSyxDQUFDTSxLQUFLLENBQUNELElBQUksRUFBRXJCLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLENBQUMsRUFBRWMsVUFBVSxFQUFFQyxPQUFPLENBQUM7TUFFM0IsQ0FBQztNQUVETyxLQUFLLEVBQUUsU0FBQUEsQ0FBVUQsSUFBSSxFQUFFckIsR0FBRyxFQUFFO1FBQ3hCLFNBQVN1QixhQUFhQSxDQUFFQyxNQUFNLEVBQUVDLFNBQVMsRUFBRztVQUN4QztVQUNBLElBQUlDLFFBQVEsR0FBR0YsTUFBTSxDQUFDRyxNQUFNO1VBQzVCLElBQUlDLE9BQU8sR0FBRyxJQUFJQyxVQUFVLENBQUVKLFNBQVUsQ0FBQztVQUN6QyxJQUFJSyxLQUFLLEdBQUcsQ0FBQztVQUNiLElBQUlDLE1BQU0sR0FBRyxDQUFDO1VBQ2QsSUFBSUMsSUFBSTtVQUNSLElBQUlDLEdBQUc7VUFDUCxJQUFJQyxHQUFHO1VBQ1AsR0FBRztZQUNDRixJQUFJLEdBQUdSLE1BQU0sQ0FBRU0sS0FBSyxFQUFHLENBQUU7WUFDekIsSUFBS0UsSUFBSSxHQUFLLENBQUMsSUFBSSxDQUFHLEVBQUc7Y0FDckJBLElBQUksRUFBRztjQUNQLElBQUtELE1BQU0sR0FBR0MsSUFBSSxHQUFHUCxTQUFTLEVBQUcsTUFBTSxJQUFJVSxLQUFLLENBQUUsbUNBQW9DLENBQUM7Y0FDdkYsSUFBS0wsS0FBSyxHQUFHRSxJQUFJLEdBQUdOLFFBQVEsRUFBRyxNQUFNLElBQUlTLEtBQUssQ0FBRSx5QkFBMEIsQ0FBQztjQUMzRSxHQUFHO2dCQUNDUCxPQUFPLENBQUVHLE1BQU0sRUFBRyxDQUFFLEdBQUdQLE1BQU0sQ0FBRU0sS0FBSyxFQUFHLENBQUU7Y0FDN0MsQ0FBQyxRQUFTLEVBQUdFLElBQUk7WUFDckIsQ0FBQyxNQUFNO2NBQ0hDLEdBQUcsR0FBR0QsSUFBSSxJQUFJLENBQUM7Y0FDZkUsR0FBRyxHQUFHSCxNQUFNLElBQUssQ0FBRUMsSUFBSSxHQUFHLElBQUksS0FBTSxDQUFDLENBQUUsR0FBRyxDQUFDO2NBQzNDLElBQUtGLEtBQUssSUFBSUosUUFBUSxFQUFHLE1BQU0sSUFBSVMsS0FBSyxDQUFFLHlCQUEwQixDQUFDO2NBQ3JFLElBQUtGLEdBQUcsS0FBSyxDQUFDLEVBQUc7Z0JBQ2JBLEdBQUcsSUFBSVQsTUFBTSxDQUFFTSxLQUFLLEVBQUcsQ0FBRTtnQkFDekIsSUFBS0EsS0FBSyxJQUFJSixRQUFRLEVBQUcsTUFBTSxJQUFJUyxLQUFLLENBQUUseUJBQTBCLENBQUM7Y0FDekU7Y0FDQUQsR0FBRyxJQUFJVixNQUFNLENBQUVNLEtBQUssRUFBRyxDQUFFO2NBQ3pCLElBQUtDLE1BQU0sR0FBR0UsR0FBRyxHQUFHLENBQUMsR0FBR1IsU0FBUyxFQUFHLE1BQU0sSUFBSVUsS0FBSyxDQUFFLG1DQUFvQyxDQUFDO2NBQzFGLElBQUtELEdBQUcsR0FBRyxDQUFDLEVBQUcsTUFBTSxJQUFJQyxLQUFLLENBQUUseUJBQTBCLENBQUM7Y0FDM0QsSUFBS0QsR0FBRyxJQUFJSCxNQUFNLEVBQUcsTUFBTSxJQUFJSSxLQUFLLENBQUUseUJBQTBCLENBQUM7Y0FDakUsR0FBRztnQkFDQ1AsT0FBTyxDQUFFRyxNQUFNLEVBQUcsQ0FBRSxHQUFHSCxPQUFPLENBQUVNLEdBQUcsRUFBRyxDQUFFO2NBQzVDLENBQUMsUUFBUyxFQUFHRCxHQUFHLEdBQUcsQ0FBQztZQUN4QjtVQUNKLENBQUMsUUFBU0gsS0FBSyxHQUFHSixRQUFRO1VBQzFCLE9BQU9FLE9BQU87UUFDbEI7UUFFQSxTQUFTUSxXQUFXQSxDQUFDZixJQUFJLEVBQUU7VUFDdkIsSUFBSWdCLFNBQVMsR0FBRyxDQUFDLENBQUM7VUFDbEIsSUFBSUMsT0FBTyxHQUFHakIsSUFBSSxDQUFDa0IsTUFBTSxDQUFDLHNCQUFzQixDQUFDO1VBQ2pELElBQUlDLE9BQU8sR0FBRyxzQkFBc0IsQ0FBQ0MsSUFBSSxDQUFDcEIsSUFBSSxDQUFDcUIsTUFBTSxDQUFDSixPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7VUFDbkVELFNBQVMsQ0FBQ2hCLElBQUksR0FBR21CLE9BQU8sQ0FBQyxDQUFDLENBQUM7VUFDM0JILFNBQVMsQ0FBQ00sU0FBUyxHQUFHSCxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNiLE1BQU0sR0FBR1csT0FBTztVQUNqREQsU0FBUyxDQUFDTyxHQUFHLEdBQUd2QixJQUFJLENBQUNxQixNQUFNLENBQUMsQ0FBQyxFQUFFTCxTQUFTLENBQUNNLFNBQVMsQ0FBQzs7VUFFbkQ7VUFDQU4sU0FBUyxDQUFDTyxHQUFHLEdBQUdQLFNBQVMsQ0FBQ08sR0FBRyxDQUFDQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQzs7VUFFbkQ7VUFDQVIsU0FBUyxDQUFDUyxPQUFPLEdBQUcsZUFBZSxDQUFDTCxJQUFJLENBQUNKLFNBQVMsQ0FBQ08sR0FBRyxDQUFDO1VBQ3ZEUCxTQUFTLENBQUNuQyxNQUFNLEdBQUcsY0FBYyxDQUFDdUMsSUFBSSxDQUFDSixTQUFTLENBQUNPLEdBQUcsQ0FBQztVQUNyRFAsU0FBUyxDQUFDVSxJQUFJLEdBQUcsWUFBWSxDQUFDTixJQUFJLENBQUNKLFNBQVMsQ0FBQ08sR0FBRyxDQUFDO1VBQ2pEUCxTQUFTLENBQUNXLElBQUksR0FBRyxZQUFZLENBQUNQLElBQUksQ0FBQ0osU0FBUyxDQUFDTyxHQUFHLENBQUM7VUFDakRQLFNBQVMsQ0FBQ1ksS0FBSyxHQUFHLGFBQWEsQ0FBQ1IsSUFBSSxDQUFDSixTQUFTLENBQUNPLEdBQUcsQ0FBQztVQUNuRFAsU0FBUyxDQUFDYSxLQUFLLEdBQUcsYUFBYSxDQUFDVCxJQUFJLENBQUNKLFNBQVMsQ0FBQ08sR0FBRyxDQUFDO1VBQ25EUCxTQUFTLENBQUNjLE1BQU0sR0FBRyxjQUFjLENBQUNWLElBQUksQ0FBQ0osU0FBUyxDQUFDTyxHQUFHLENBQUM7VUFDckRQLFNBQVMsQ0FBQ2UsU0FBUyxHQUFHLGlCQUFpQixDQUFDWCxJQUFJLENBQUNKLFNBQVMsQ0FBQ08sR0FBRyxDQUFDO1VBQzNEUCxTQUFTLENBQUNnQixNQUFNLEdBQUcsY0FBYyxDQUFDWixJQUFJLENBQUNKLFNBQVMsQ0FBQ08sR0FBRyxDQUFDO1VBQ3JEO1VBQ0EsSUFBSVAsU0FBUyxDQUFDUyxPQUFPLEtBQUssSUFBSSxFQUMxQlQsU0FBUyxDQUFDUyxPQUFPLEdBQUdRLFVBQVUsQ0FBQ2pCLFNBQVMsQ0FBQ1MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQ3hELElBQUlULFNBQVMsQ0FBQ25DLE1BQU0sS0FBSyxJQUFJLEVBQ3pCbUMsU0FBUyxDQUFDbkMsTUFBTSxHQUFHbUMsU0FBUyxDQUFDbkMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDcUQsS0FBSyxDQUFDLEdBQUcsQ0FBQztVQUNyRCxJQUFJbEIsU0FBUyxDQUFDVyxJQUFJLEtBQUssSUFBSSxFQUN2QlgsU0FBUyxDQUFDVyxJQUFJLEdBQUdYLFNBQVMsQ0FBQ1csSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDTyxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQ2pELElBQUlsQixTQUFTLENBQUNhLEtBQUssS0FBSyxJQUFJLEVBQ3hCYixTQUFTLENBQUNhLEtBQUssR0FBR00sUUFBUSxDQUFDbkIsU0FBUyxDQUFDYSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDbEQsSUFBSWIsU0FBUyxDQUFDYyxNQUFNLEtBQUssSUFBSSxFQUN6QmQsU0FBUyxDQUFDYyxNQUFNLEdBQUdLLFFBQVEsQ0FBQ25CLFNBQVMsQ0FBQ2MsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQ3BELElBQUlkLFNBQVMsQ0FBQ2UsU0FBUyxLQUFLLElBQUksRUFDNUJmLFNBQVMsQ0FBQ2UsU0FBUyxHQUFHZixTQUFTLENBQUNlLFNBQVMsQ0FBQyxDQUFDLENBQUM7VUFDaEQsSUFBSWYsU0FBUyxDQUFDZ0IsTUFBTSxLQUFLLElBQUksRUFDekJoQixTQUFTLENBQUNnQixNQUFNLEdBQUdHLFFBQVEsQ0FBQ25CLFNBQVMsQ0FBQ2dCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7VUFDeEQsSUFBSWhCLFNBQVMsQ0FBQ2dCLE1BQU0sS0FBSyxJQUFJLEVBQ3pCaEIsU0FBUyxDQUFDZ0IsTUFBTSxHQUFHaEIsU0FBUyxDQUFDYSxLQUFLLEdBQUdiLFNBQVMsQ0FBQ2MsTUFBTTtVQUN6RCxJQUFJZCxTQUFTLENBQUNVLElBQUksS0FBSyxJQUFJLEVBQUU7WUFDekJWLFNBQVMsQ0FBQ1UsSUFBSSxHQUFHVixTQUFTLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDRSxHQUFHLENBQUMsVUFBVUMsQ0FBQyxFQUFFO2NBQzNELE9BQU9GLFFBQVEsQ0FBQ0UsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUMxQixDQUFDLENBQUM7VUFDTjtVQUVBLE1BQU1ILEtBQUssR0FBR2xCLFNBQVMsQ0FBQ2UsU0FBUyxDQUFDRyxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQzVDbEIsU0FBUyxDQUFDZSxTQUFTLEdBQUc7WUFDbEJPLEVBQUUsRUFBRUosS0FBSyxDQUFDLENBQUMsQ0FBQztZQUFFSyxFQUFFLEVBQUVMLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFBRU0sRUFBRSxFQUFFTixLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3hDTyxFQUFFLEVBQUVQLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFBRVEsRUFBRSxFQUFFUixLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQUVTLEVBQUUsRUFBRVQsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUFFVSxFQUFFLEVBQUVWLEtBQUssQ0FBQyxDQUFDO1VBQ3pELENBQUM7VUFDRCxJQUFJbEIsU0FBUyxDQUFDWSxLQUFLLEtBQUssSUFBSSxFQUFFO1lBQzFCWixTQUFTLENBQUNZLEtBQUssR0FBR1osU0FBUyxDQUFDWSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNNLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0UsR0FBRyxDQUFDLFVBQVVDLENBQUMsRUFBRTtjQUM3RCxPQUFPRixRQUFRLENBQUNFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDMUIsQ0FBQyxDQUFDO1VBQ04sQ0FBQyxNQUFNO1lBQ0hyQixTQUFTLENBQUNZLEtBQUssR0FBRyxFQUFFO1lBQ3BCLEtBQUssSUFBSWlCLENBQUMsR0FBRyxDQUFDLEVBQUVDLENBQUMsR0FBRzlCLFNBQVMsQ0FBQ25DLE1BQU0sQ0FBQ3lCLE1BQU0sRUFBRXVDLENBQUMsR0FBR0MsQ0FBQyxFQUFFRCxDQUFDLEVBQUUsRUFBRTtjQUNyRDdCLFNBQVMsQ0FBQ1ksS0FBSyxDQUFDbUIsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUMzQjtVQUNKO1VBRUEvQixTQUFTLENBQUNnQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1VBRXJCLElBQUlDLE9BQU8sR0FBRyxDQUFDO1VBRWYsS0FBSyxJQUFJSixDQUFDLEdBQUcsQ0FBQyxFQUFFQyxDQUFDLEdBQUc5QixTQUFTLENBQUNuQyxNQUFNLENBQUN5QixNQUFNLEVBQUV1QyxDQUFDLEdBQUdDLENBQUMsRUFBRUQsQ0FBQyxFQUFFLEVBQUU7WUFDckQsSUFBSTdCLFNBQVMsQ0FBQ2hCLElBQUksS0FBSyxPQUFPLEVBQUU7Y0FDNUJnQixTQUFTLENBQUNnQyxNQUFNLENBQUNoQyxTQUFTLENBQUNuQyxNQUFNLENBQUNnRSxDQUFDLENBQUMsQ0FBQyxHQUFHQSxDQUFDO1lBQzdDLENBQUMsTUFBTTtjQUNIN0IsU0FBUyxDQUFDZ0MsTUFBTSxDQUFDaEMsU0FBUyxDQUFDbkMsTUFBTSxDQUFDZ0UsQ0FBQyxDQUFDLENBQUMsR0FBR0ksT0FBTztjQUMvQ0EsT0FBTyxJQUFJakMsU0FBUyxDQUFDVSxJQUFJLENBQUNtQixDQUFDLENBQUM7WUFDaEM7VUFDSjtVQUNBN0IsU0FBUyxDQUFDa0MsT0FBTyxHQUFHRCxPQUFPO1VBQzNCLE9BQU9qQyxTQUFTO1FBQ3BCO1FBRUEsSUFBSW1DLFFBQVEsR0FBRyxJQUFJLENBQUM5RCxVQUFVLEdBQUkrRCxNQUFNLENBQUNDLElBQUksQ0FBQ3JELElBQUksQ0FBQyxDQUFFc0QsUUFBUSxDQUFDLENBQUMsR0FBR25FLEtBQUssQ0FBQ29FLFdBQVcsQ0FBQ0MsVUFBVSxDQUFDeEQsSUFBSSxDQUFDOztRQUVwRztRQUNBLElBQUlnQixTQUFTLEdBQUdELFdBQVcsQ0FBQ29DLFFBQVEsQ0FBQzs7UUFFckM7O1FBRUEsSUFBSU0sUUFBUSxHQUFHLEVBQUU7UUFDakIsSUFBSUMsS0FBSyxHQUFHLEVBQUU7UUFDZCxJQUFJQyxLQUFLLEdBQUcsRUFBRTtRQUNkLElBQUlDLE9BQU8sR0FBRyxFQUFFO1FBQ2hCLElBQUlDLEdBQUcsR0FBRyxFQUFFO1FBRVosSUFBSTdDLFNBQVMsQ0FBQ2hCLElBQUksS0FBSyxPQUFPLEVBQUU7VUFDNUIsTUFBTThELElBQUksR0FBRzlDLFNBQVM7VUFFdEIsSUFBSStDLFdBQVcsR0FBRyxJQUFJNUUsS0FBSyxDQUFDNkUsT0FBTyxDQUFDL0IsVUFBVSxDQUFDNkIsSUFBSSxDQUFDL0IsU0FBUyxDQUFDTyxFQUFFLENBQUMsRUFBRUwsVUFBVSxDQUFDNkIsSUFBSSxDQUFDL0IsU0FBUyxDQUFDUSxFQUFFLENBQUMsRUFDNUZOLFVBQVUsQ0FBQzZCLElBQUksQ0FBQy9CLFNBQVMsQ0FBQ1MsRUFBRSxDQUFDLENBQUM7VUFDbEMsSUFBSXlCLGFBQWEsR0FBRyxJQUFJOUUsS0FBSyxDQUFDK0UsVUFBVSxDQUFDSixJQUFJLENBQUMvQixTQUFTLENBQUNXLEVBQUUsRUFDdERvQixJQUFJLENBQUMvQixTQUFTLENBQUNZLEVBQUUsRUFBRW1CLElBQUksQ0FBQy9CLFNBQVMsQ0FBQ2EsRUFBRSxFQUFFa0IsSUFBSSxDQUFDL0IsU0FBUyxDQUFDVSxFQUFFLENBQUM7VUFFNUQsSUFBSU8sTUFBTSxHQUFHaEMsU0FBUyxDQUFDZ0MsTUFBTTtVQUU3QixJQUFJbUIsT0FBTyxHQUFHaEIsUUFBUSxDQUFDOUIsTUFBTSxDQUFDTCxTQUFTLENBQUNNLFNBQVMsQ0FBQztVQUNsRCxJQUFJOEMsS0FBSyxHQUFHRCxPQUFPLENBQUNqQyxLQUFLLENBQUMsSUFBSSxDQUFDO1VBQy9CLElBQUltQyxFQUFFLEVBQUVDLElBQUk7VUFDWixLQUFLLElBQUl6QixDQUFDLEdBQUcsQ0FBQyxFQUFFQyxDQUFDLEdBQUdzQixLQUFLLENBQUM5RCxNQUFNLEdBQUcsQ0FBQyxFQUFFdUMsQ0FBQyxHQUFHQyxDQUFDLEVBQUVELENBQUMsRUFBRSxFQUFFO1lBQzlDLElBQUd1QixLQUFLLENBQUN2QixDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUM7Y0FBQztZQUFTLENBQUMsQ0FBRTs7WUFFL0IsSUFBSTBCLElBQUksR0FBR0gsS0FBSyxDQUFDdkIsQ0FBQyxDQUFDLENBQUNYLEtBQUssQ0FBQyxHQUFHLENBQUM7WUFDOUJvQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ1RWLE9BQU8sQ0FBQ2IsSUFBSSxDQUFDdUIsSUFBSSxDQUFDO1lBRWxCRCxFQUFFLEdBQUcsSUFBSWxGLEtBQUssQ0FBQzZFLE9BQU8sQ0FBQy9CLFVBQVUsQ0FBQ3NDLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQ1gsQ0FBQyxDQUFDLENBQUMsRUFBRUosVUFBVSxDQUFDc0MsSUFBSSxDQUFDdkIsTUFBTSxDQUFDd0IsQ0FBQyxDQUFDLENBQUMsRUFBRXZDLFVBQVUsQ0FBQ3NDLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQ3lCLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFMUcsSUFBSSxDQUFDLElBQUksQ0FBQ3BGLFVBQVUsRUFBRTtjQUNsQmdGLEVBQUUsR0FBR0EsRUFBRSxDQUFDSyxHQUFHLENBQUNYLFdBQVcsQ0FBQztjQUN4Qk0sRUFBRSxDQUFDTSxlQUFlLENBQUNWLGFBQWEsQ0FBQztZQUNyQztZQUVBSyxJQUFJLENBQUNqQyxDQUFDLEdBQUdnQyxFQUFFLENBQUNoQyxDQUFDO1lBQ2JvQixRQUFRLENBQUNWLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQ2hDLENBQUMsQ0FBQztZQUVuQmlDLElBQUksQ0FBQ0UsQ0FBQyxHQUFHSCxFQUFFLENBQUNHLENBQUM7WUFDYmYsUUFBUSxDQUFDVixJQUFJLENBQUNzQixFQUFFLENBQUNHLENBQUMsQ0FBQztZQUNuQkYsSUFBSSxDQUFDRyxDQUFDLEdBQUdKLEVBQUUsQ0FBQ0ksQ0FBQztZQUNiaEIsUUFBUSxDQUFDVixJQUFJLENBQUNzQixFQUFFLENBQUNJLENBQUMsQ0FBQztZQUVuQixJQUFJekIsTUFBTSxDQUFDVyxLQUFLLEtBQUtpQixTQUFTLEVBQUU7Y0FDNUIsTUFBTUMsVUFBVSxHQUFHMUMsUUFBUSxDQUFDb0MsSUFBSSxDQUFDdkIsTUFBTSxDQUFDVyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7Y0FDcERXLElBQUksQ0FBQ08sVUFBVSxHQUFHQSxVQUFVO2NBQzVCbEIsS0FBSyxDQUFDWixJQUFJLENBQUM4QixVQUFVLENBQUM7WUFDMUIsQ0FBQyxNQUFNO2NBQ0hQLElBQUksQ0FBQ08sVUFBVSxHQUFHLENBQUM7Y0FDbkJsQixLQUFLLENBQUNaLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDakI7O1lBRUE7WUFDQSxJQUFJQyxNQUFNLENBQUNhLEdBQUcsSUFBSWUsU0FBUyxFQUFFO2NBQ3pCLElBQUlFLFFBQVEsR0FBRzNDLFFBQVEsQ0FBQ29DLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQ2EsR0FBRyxDQUFDLENBQUM7Y0FDekMsSUFBSWtCLENBQUMsR0FBSUQsUUFBUSxJQUFJLEVBQUUsR0FBSSxRQUFRO2NBQ25DLElBQUlFLENBQUMsR0FBSUYsUUFBUSxJQUFJLENBQUMsR0FBSSxRQUFRO2NBQ2xDLElBQUlHLENBQUMsR0FBSUgsUUFBUSxHQUFJLFFBQVE7Y0FDN0JqQixHQUFHLENBQUNkLElBQUksQ0FBQyxDQUFDZ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCO1lBRUF2QixLQUFLLENBQUNYLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDYlcsS0FBSyxDQUFDWCxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2JXLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLENBQUMsQ0FBQztVQUVqQjtRQUNKOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSy9CLFNBQVMsQ0FBQ2hCLElBQUksS0FBSyxtQkFBbUIsRUFBRztVQUMxQyxJQUFJa0YsUUFBUSxHQUFHLElBQUlDLFFBQVEsQ0FBRW5GLElBQUksQ0FBQ29GLEtBQUssQ0FBRXBFLFNBQVMsQ0FBQ00sU0FBUyxFQUFFTixTQUFTLENBQUNNLFNBQVMsR0FBRyxDQUFFLENBQUUsQ0FBQztVQUN6RixJQUFJK0QsY0FBYyxHQUFHSCxRQUFRLENBQUNJLFNBQVMsQ0FBRSxDQUFDLEVBQUUsSUFBSyxDQUFDO1VBQ2xELElBQUlDLGdCQUFnQixHQUFHTCxRQUFRLENBQUNJLFNBQVMsQ0FBRSxDQUFDLEVBQUUsSUFBSyxDQUFDO1VBQ3BELElBQUlFLFlBQVksR0FBR3RGLGFBQWEsQ0FBRSxJQUFJTSxVQUFVLENBQUVSLElBQUksRUFBRWdCLFNBQVMsQ0FBQ00sU0FBUyxHQUFHLENBQUMsRUFBRStELGNBQWUsQ0FBQyxFQUFFRSxnQkFBaUIsQ0FBQztVQUNySEwsUUFBUSxHQUFHLElBQUlDLFFBQVEsQ0FBRUssWUFBWSxDQUFDQyxNQUFPLENBQUM7VUFFOUMsSUFBSXpDLE1BQU0sR0FBR2hDLFNBQVMsQ0FBQ2dDLE1BQU07VUFDN0IsSUFBSXFCLEVBQUUsRUFBRUMsSUFBSTtVQUVaLElBQUlQLFdBQVcsR0FBRyxJQUFJNUUsS0FBSyxDQUFDNkUsT0FBTyxDQUFDL0IsVUFBVSxDQUFDakIsU0FBUyxDQUFDZSxTQUFTLENBQUNPLEVBQUUsQ0FBQyxFQUFFTCxVQUFVLENBQUNqQixTQUFTLENBQUNlLFNBQVMsQ0FBQ1EsRUFBRSxDQUFDLEVBQ3RHTixVQUFVLENBQUNqQixTQUFTLENBQUNlLFNBQVMsQ0FBQ1MsRUFBRSxDQUFDLENBQUM7VUFDdkMsSUFBSXlCLGFBQWEsR0FBRyxJQUFJOUUsS0FBSyxDQUFDK0UsVUFBVSxDQUFDbEQsU0FBUyxDQUFDZSxTQUFTLENBQUNXLEVBQUUsRUFDM0QxQixTQUFTLENBQUNlLFNBQVMsQ0FBQ1ksRUFBRSxFQUFFM0IsU0FBUyxDQUFDZSxTQUFTLENBQUNhLEVBQUUsRUFBRTVCLFNBQVMsQ0FBQ2UsU0FBUyxDQUFDVSxFQUFFLENBQUM7VUFFM0UsS0FBTSxJQUFJSSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc3QixTQUFTLENBQUNnQixNQUFNLEVBQUVhLENBQUMsRUFBRyxFQUFHO1lBQzFDeUIsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUNUVixPQUFPLENBQUNiLElBQUksQ0FBQ3VCLElBQUksQ0FBQztZQUVsQixNQUFNakMsQ0FBQyxHQUFHNkMsUUFBUSxDQUFDUSxVQUFVLENBQUkxRSxTQUFTLENBQUNnQixNQUFNLEdBQUdnQixNQUFNLENBQUNYLENBQUMsR0FBS3JCLFNBQVMsQ0FBQ1UsSUFBSSxDQUFFLENBQUMsQ0FBRSxHQUFHbUIsQ0FBQyxFQUFFLElBQUssQ0FBQztZQUNoRyxNQUFNMkIsQ0FBQyxHQUFHVSxRQUFRLENBQUNRLFVBQVUsQ0FBSTFFLFNBQVMsQ0FBQ2dCLE1BQU0sR0FBR2dCLE1BQU0sQ0FBQ3dCLENBQUMsR0FBS3hELFNBQVMsQ0FBQ1UsSUFBSSxDQUFFLENBQUMsQ0FBRSxHQUFHbUIsQ0FBQyxFQUFFLElBQUssQ0FBQztZQUNoRyxNQUFNNEIsQ0FBQyxHQUFHUyxRQUFRLENBQUNRLFVBQVUsQ0FBSTFFLFNBQVMsQ0FBQ2dCLE1BQU0sR0FBR2dCLE1BQU0sQ0FBQ3lCLENBQUMsR0FBS3pELFNBQVMsQ0FBQ1UsSUFBSSxDQUFFLENBQUMsQ0FBRSxHQUFHbUIsQ0FBQyxFQUFFLElBQUssQ0FBQztZQUVoR3dCLEVBQUUsR0FBRyxJQUFJbEYsS0FBSyxDQUFDNkUsT0FBTyxDQUFDM0IsQ0FBQyxFQUFFbUMsQ0FBQyxFQUFFQyxDQUFDLENBQUM7WUFFL0IsSUFBSSxDQUFDLElBQUksQ0FBQ3BGLFVBQVUsRUFBRTtjQUNsQmdGLEVBQUUsR0FBR0EsRUFBRSxDQUFDSyxHQUFHLENBQUNYLFdBQVcsQ0FBQztjQUN4Qk0sRUFBRSxDQUFDTSxlQUFlLENBQUNWLGFBQWEsQ0FBQztZQUNyQztZQUVBSyxJQUFJLENBQUNqQyxDQUFDLEdBQUdnQyxFQUFFLENBQUNoQyxDQUFDO1lBQ2JvQixRQUFRLENBQUNWLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQ2hDLENBQUMsQ0FBQztZQUVuQmlDLElBQUksQ0FBQ0UsQ0FBQyxHQUFHSCxFQUFFLENBQUNHLENBQUM7WUFDYmYsUUFBUSxDQUFDVixJQUFJLENBQUNzQixFQUFFLENBQUNHLENBQUMsQ0FBQztZQUNuQkYsSUFBSSxDQUFDRyxDQUFDLEdBQUdKLEVBQUUsQ0FBQ0ksQ0FBQztZQUNiaEIsUUFBUSxDQUFDVixJQUFJLENBQUNzQixFQUFFLENBQUNJLENBQUMsQ0FBQztZQUVuQixJQUFLekIsTUFBTSxDQUFDVyxLQUFLLEtBQUtpQixTQUFTLEVBQUc7Y0FDOUIsTUFBTUMsVUFBVSxHQUFHSyxRQUFRLENBQUNTLFFBQVEsQ0FBRTNFLFNBQVMsQ0FBQ2dCLE1BQU0sR0FBR2dCLE1BQU0sQ0FBQ1csS0FBSyxHQUFHM0MsU0FBUyxDQUFDVSxJQUFJLENBQUUsQ0FBQyxDQUFFLEdBQUdtQixDQUFFLENBQUM7Y0FDakd5QixJQUFJLENBQUNPLFVBQVUsR0FBR0EsVUFBVTtjQUM1QmxCLEtBQUssQ0FBQ1osSUFBSSxDQUFFOEIsVUFBVyxDQUFDO1lBQzVCLENBQUMsTUFBTTtjQUNIUCxJQUFJLENBQUNPLFVBQVUsR0FBRyxDQUFDO2NBQ25CbEIsS0FBSyxDQUFDWixJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2pCOztZQUVBO1lBQ0EsSUFBSUMsTUFBTSxDQUFDYSxHQUFHLElBQUllLFNBQVMsRUFBRTtjQUN6QixJQUFJRSxRQUFRLEdBQUdJLFFBQVEsQ0FBQ0ksU0FBUyxDQUFDTSxHQUFHLEdBQUc1QyxNQUFNLENBQUNhLEdBQUcsRUFBRSxJQUFJLENBQUM7Y0FDekQsSUFBSWtCLENBQUMsR0FBSUQsUUFBUSxJQUFJLEVBQUUsR0FBSSxRQUFRO2NBQ25DLElBQUlFLENBQUMsR0FBSUYsUUFBUSxJQUFJLENBQUMsR0FBSSxRQUFRO2NBQ2xDLElBQUlHLENBQUMsR0FBSUgsUUFBUSxHQUFJLFFBQVE7Y0FDN0JqQixHQUFHLENBQUNkLElBQUksQ0FBQyxDQUFDZ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCO1lBRUF2QixLQUFLLENBQUNYLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDYlcsS0FBSyxDQUFDWCxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2JXLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLENBQUMsQ0FBQztVQUNqQjtRQUNKOztRQUVBOztRQUVBLElBQUsvQixTQUFTLENBQUNoQixJQUFJLEtBQUssUUFBUSxFQUFHO1VBQy9CLElBQUlrRixRQUFRLEdBQUcsSUFBSUMsUUFBUSxDQUFFbkYsSUFBSSxFQUFFZ0IsU0FBUyxDQUFDTSxTQUFVLENBQUM7VUFDeEQsSUFBSTBCLE1BQU0sR0FBR2hDLFNBQVMsQ0FBQ2dDLE1BQU07VUFDN0IsSUFBSXFCLEVBQUUsRUFBRUMsSUFBSTtVQUNaO1VBQ0EsSUFBSVAsV0FBVyxHQUFHLElBQUk1RSxLQUFLLENBQUM2RSxPQUFPLENBQUMvQixVQUFVLENBQUNqQixTQUFTLENBQUNlLFNBQVMsQ0FBQ08sRUFBRSxDQUFDLEVBQUVMLFVBQVUsQ0FBQ2pCLFNBQVMsQ0FBQ2UsU0FBUyxDQUFDUSxFQUFFLENBQUMsRUFDdEdOLFVBQVUsQ0FBQ2pCLFNBQVMsQ0FBQ2UsU0FBUyxDQUFDUyxFQUFFLENBQUMsQ0FBQztVQUN2QyxJQUFJeUIsYUFBYSxHQUFHLElBQUk5RSxLQUFLLENBQUMrRSxVQUFVLENBQUNsRCxTQUFTLENBQUNlLFNBQVMsQ0FBQ1csRUFBRSxFQUMzRDFCLFNBQVMsQ0FBQ2UsU0FBUyxDQUFDWSxFQUFFLEVBQUUzQixTQUFTLENBQUNlLFNBQVMsQ0FBQ2EsRUFBRSxFQUFFNUIsU0FBUyxDQUFDZSxTQUFTLENBQUNVLEVBQUUsQ0FBQztVQUUzRSxLQUFNLElBQUlJLENBQUMsR0FBRyxDQUFDLEVBQUUrQyxHQUFHLEdBQUcsQ0FBQyxFQUFFL0MsQ0FBQyxHQUFHN0IsU0FBUyxDQUFDZ0IsTUFBTSxFQUFFYSxDQUFDLEVBQUcsRUFBRStDLEdBQUcsSUFBSTVFLFNBQVMsQ0FBQ2tDLE9BQU8sRUFBRztZQUM3RW9CLElBQUksR0FBRyxDQUFDLENBQUM7WUFDVFYsT0FBTyxDQUFDYixJQUFJLENBQUN1QixJQUFJLENBQUM7WUFFbEIsTUFBTWpDLENBQUMsR0FBRzZDLFFBQVEsQ0FBQ1EsVUFBVSxDQUFFRSxHQUFHLEdBQUc1QyxNQUFNLENBQUNYLENBQUMsRUFBRSxJQUFLLENBQUM7WUFDckQsTUFBTW1DLENBQUMsR0FBR1UsUUFBUSxDQUFDUSxVQUFVLENBQUVFLEdBQUcsR0FBRzVDLE1BQU0sQ0FBQ3dCLENBQUMsRUFBRSxJQUFLLENBQUM7WUFDckQsTUFBTUMsQ0FBQyxHQUFHUyxRQUFRLENBQUNRLFVBQVUsQ0FBRUUsR0FBRyxHQUFHNUMsTUFBTSxDQUFDeUIsQ0FBQyxFQUFFLElBQUssQ0FBQztZQUVyREosRUFBRSxHQUFHLElBQUlsRixLQUFLLENBQUM2RSxPQUFPLENBQUMzQixDQUFDLEVBQUVtQyxDQUFDLEVBQUVDLENBQUMsQ0FBQztZQUUvQixJQUFJLENBQUMsSUFBSSxDQUFDcEYsVUFBVSxFQUFFO2NBQ2xCZ0YsRUFBRSxHQUFHQSxFQUFFLENBQUNLLEdBQUcsQ0FBQ1gsV0FBVyxDQUFDO2NBQ3hCTSxFQUFFLENBQUNNLGVBQWUsQ0FBQ1YsYUFBYSxDQUFDO1lBQ3JDO1lBRUFLLElBQUksQ0FBQ2pDLENBQUMsR0FBR2dDLEVBQUUsQ0FBQ2hDLENBQUM7WUFDYm9CLFFBQVEsQ0FBQ1YsSUFBSSxDQUFDc0IsRUFBRSxDQUFDaEMsQ0FBQyxDQUFDO1lBRW5CaUMsSUFBSSxDQUFDRSxDQUFDLEdBQUdILEVBQUUsQ0FBQ0csQ0FBQztZQUNiZixRQUFRLENBQUNWLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQ0csQ0FBQyxDQUFDO1lBQ25CRixJQUFJLENBQUNHLENBQUMsR0FBR0osRUFBRSxDQUFDSSxDQUFDO1lBQ2JoQixRQUFRLENBQUNWLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQ0ksQ0FBQyxDQUFDO1lBRW5CLElBQUt6QixNQUFNLENBQUNXLEtBQUssS0FBS2lCLFNBQVMsRUFBRztjQUM5QixNQUFNQyxVQUFVLEdBQUdLLFFBQVEsQ0FBQ1MsUUFBUSxDQUFFQyxHQUFHLEdBQUc1QyxNQUFNLENBQUNXLEtBQU0sQ0FBQztjQUMxRFcsSUFBSSxDQUFDTyxVQUFVLEdBQUdBLFVBQVU7Y0FDNUJsQixLQUFLLENBQUNaLElBQUksQ0FBQzhCLFVBQVUsQ0FBQztZQUMxQixDQUFDLE1BQU07Y0FDSFAsSUFBSSxDQUFDTyxVQUFVLEdBQUcsQ0FBQztjQUNuQmxCLEtBQUssQ0FBQ1osSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNqQjs7WUFFQTtZQUNBLElBQUlDLE1BQU0sQ0FBQ2EsR0FBRyxJQUFJZSxTQUFTLEVBQUU7Y0FDekIsSUFBSUUsUUFBUSxHQUFHSSxRQUFRLENBQUNJLFNBQVMsQ0FBQ00sR0FBRyxHQUFHNUMsTUFBTSxDQUFDYSxHQUFHLEVBQUUsSUFBSSxDQUFDO2NBQ3pELElBQUlrQixDQUFDLEdBQUlELFFBQVEsSUFBSSxFQUFFLEdBQUksUUFBUTtjQUNuQyxJQUFJRSxDQUFDLEdBQUlGLFFBQVEsSUFBSSxDQUFDLEdBQUksUUFBUTtjQUNsQyxJQUFJRyxDQUFDLEdBQUlILFFBQVEsR0FBSSxRQUFRO2NBQzdCakIsR0FBRyxDQUFDZCxJQUFJLENBQUMsQ0FBQ2dDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLENBQUMsQ0FBQztZQUN2QjtZQUVBdkIsS0FBSyxDQUFDWCxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2JXLEtBQUssQ0FBQ1gsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNiVyxLQUFLLENBQUNYLElBQUksQ0FBQyxDQUFDLENBQUM7VUFDakI7UUFDSjs7UUFFQTs7UUFFQSxJQUFJOEMsUUFBUSxHQUFHLElBQUkxRyxLQUFLLENBQUMyRyxjQUFjLENBQUMsQ0FBQztRQUV6QyxJQUFJckMsUUFBUSxDQUFDbkQsTUFBTSxHQUFHLENBQUMsRUFDbkJ1RixRQUFRLENBQUNFLFlBQVksQ0FBQyxVQUFVLEVBQUUsSUFBSTVHLEtBQUssQ0FBQzZHLHNCQUFzQixDQUFDdkMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BGLElBQUlFLEtBQUssQ0FBQ3JELE1BQU0sR0FBRyxDQUFDLEVBQ2hCdUYsUUFBUSxDQUFDRSxZQUFZLENBQUMsT0FBTyxFQUFFLElBQUk1RyxLQUFLLENBQUM4RyxvQkFBb0IsQ0FBQ3RDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1RSxJQUFJRCxLQUFLLENBQUNwRCxNQUFNLEdBQUcsQ0FBQyxFQUFFO1VBQ2xCLE1BQU00RixRQUFRLEdBQUcsSUFBSS9HLEtBQUssQ0FBQzZHLHNCQUFzQixDQUFDdEMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUMzRG1DLFFBQVEsQ0FBQ0UsWUFBWSxDQUFDLE9BQU8sRUFBRUcsUUFBUSxDQUFDO1FBQzVDO1FBRUFMLFFBQVEsQ0FBQ00scUJBQXFCLENBQUMsQ0FBQztRQUVoQyxJQUFJQyxRQUFRLEdBQUcsSUFBSWpILEtBQUssQ0FBQ2tILGNBQWMsQ0FBQztVQUFDM0UsSUFBSSxFQUFFLENBQUM7VUFBRWdDLEtBQUssRUFBRTtRQUFRLENBQUMsQ0FBQztRQUNuRTBDLFFBQVEsQ0FBQ0UsZUFBZSxHQUFHLEtBQUs7O1FBRWhDO1FBQ0EsSUFBSUMsSUFBSSxHQUFHLElBQUlwSCxLQUFLLENBQUNxSCxNQUFNLENBQUNYLFFBQVEsRUFBRU8sUUFBUSxDQUFDO1FBQy9DLElBQUlLLElBQUksR0FBRzlILEdBQUcsQ0FBQ3VELEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQ3dFLE9BQU8sQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDM0NGLElBQUksR0FBRyxVQUFVLENBQUNyRixJQUFJLENBQUNxRixJQUFJLENBQUM7UUFDNUJBLElBQUksR0FBR0EsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDdkUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDd0UsT0FBTyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUMzQ0osSUFBSSxDQUFDRSxJQUFJLEdBQUc5SCxHQUFHO1FBQ2YsT0FBTztVQUFDOEUsUUFBUTtVQUFFRSxLQUFLO1VBQUVpRCxNQUFNLEVBQUU1RixTQUFTO1VBQUU2QztRQUFHLENBQUM7TUFDcEQ7SUFFSixDQUFDO0VBRUw7QUFDSixDOzs7Ozs7Ozs7OztBQ3pXQSxTQUFTZ0Qsc0JBQXNCQSxDQUFBLEVBQUcsQ0FDbEM7QUFFQSxTQUFTQyxPQUFPQSxDQUFDQyxHQUFHLEVBQUU7RUFDbEIsSUFBSUEsR0FBRyxHQUFJLENBQUMsSUFBSSxDQUFFLEVBQUU7SUFDaEIsT0FBTyxDQUFDO0VBQ1osQ0FBQyxNQUFNLElBQUlBLEdBQUcsR0FBSSxDQUFDLElBQUksRUFBRyxFQUFFO0lBQ3hCLE9BQU8sQ0FBQztFQUNaLENBQUMsTUFBTSxJQUFJQSxHQUFHLEdBQUksQ0FBQyxJQUFJLEVBQUcsRUFBRTtJQUN4QixPQUFPLENBQUM7RUFDWixDQUFDLE1BQU0sSUFBSUEsR0FBRyxHQUFJLENBQUMsSUFBSSxFQUFHLEVBQUU7SUFDeEIsT0FBTyxDQUFDO0VBQ1o7RUFDQSxPQUFPLENBQUM7QUFDWjs7QUFFQTtBQUNBRixzQkFBc0IsQ0FBQ0csNEJBQTRCLEdBQUcsVUFBU0MsS0FBSyxFQUFFO0VBQ2xFLElBQUlDLENBQUMsR0FBR0QsS0FBSyxDQUFDM0csTUFBTTtFQUNwQixJQUFJNkcsTUFBTSxHQUFHLENBQUM7RUFDZCxLQUFJLElBQUl0RSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdxRSxDQUFDLEVBQUVyRSxDQUFDLEVBQUUsRUFBRTtJQUN2QnNFLE1BQU0sSUFBSUwsT0FBTyxDQUFDRyxLQUFLLENBQUNwRSxDQUFDLENBQUMsQ0FBQztFQUMvQjtFQUNBLE9BQU9zRSxNQUFNO0FBQ2pCLENBQUM7O0FBR0Q7QUFDQU4sc0JBQXNCLENBQUNPLFFBQVEsR0FBRyxVQUFTSCxLQUFLLEVBQUU7RUFDOUMsSUFBSUMsQ0FBQyxHQUFHRCxLQUFLLENBQUMzRyxNQUFNO0VBQ3BCLElBQUkrRyxHQUFHLEdBQUcsSUFBSUMsV0FBVyxDQUFDVCxzQkFBc0IsQ0FBQ0csNEJBQTRCLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQ3JGLElBQUlNLElBQUksR0FBSyxJQUFJQyxTQUFTLENBQUNILEdBQUcsQ0FBQztFQUMvQixJQUFJSSxHQUFHLEdBQUcsQ0FBQztFQUNYLEtBQUksSUFBSTVFLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3FFLENBQUMsRUFBRXJFLENBQUMsRUFBRSxFQUFFO0lBQ3ZCLElBQUlrRSxHQUFHLEdBQUdFLEtBQUssQ0FBQ3BFLENBQUMsQ0FBQztJQUNsQixJQUFJa0UsR0FBRyxHQUFJLENBQUMsSUFBSSxDQUFFLEVBQUU7TUFDaEJRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBR1YsR0FBRztJQUNyQixDQUFDLE1BQU0sSUFBSUEsR0FBRyxHQUFJLENBQUMsSUFBSSxFQUFHLEVBQUU7TUFDeEJRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBSVYsR0FBRyxHQUFHLElBQUksR0FBSSxJQUFJO01BQ2pDUSxJQUFJLENBQUNFLEdBQUcsRUFBRSxDQUFDLEdBQUdWLEdBQUcsS0FBSyxDQUFDO0lBQzNCLENBQUMsTUFBTSxJQUFJQSxHQUFHLEdBQUksQ0FBQyxJQUFJLEVBQUcsRUFBRTtNQUN4QlEsSUFBSSxDQUFDRSxHQUFHLEVBQUUsQ0FBQyxHQUFJVixHQUFHLEdBQUcsSUFBSSxHQUFJLElBQUk7TUFDakNRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBTVYsR0FBRyxLQUFLLENBQUMsR0FBSSxJQUFJLEdBQUssSUFBSTtNQUMzQ1EsSUFBSSxDQUFDRSxHQUFHLEVBQUUsQ0FBQyxHQUFHVixHQUFHLEtBQUssRUFBRTtJQUM1QixDQUFDLE1BQU0sSUFBSUEsR0FBRyxHQUFJLENBQUMsSUFBSSxFQUFHLEVBQUU7TUFDeEJRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBSVYsR0FBRyxHQUFHLElBQUksR0FBSyxJQUFJO01BQ2xDUSxJQUFJLENBQUNFLEdBQUcsRUFBRSxDQUFDLEdBQU1WLEdBQUcsS0FBSyxDQUFDLEdBQUksSUFBSSxHQUFLLElBQUk7TUFDM0NRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBTVYsR0FBRyxLQUFLLEVBQUUsR0FBSSxJQUFJLEdBQUssSUFBSTtNQUM1Q1EsSUFBSSxDQUFDRSxHQUFHLEVBQUUsQ0FBQyxHQUFHVixHQUFHLEtBQUssRUFBRTtJQUM1QixDQUFDLE1BQU07TUFDSFEsSUFBSSxDQUFDRSxHQUFHLEVBQUUsQ0FBQyxHQUFLVixHQUFHLEdBQUcsSUFBSSxHQUFLLElBQUk7TUFDbkNRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBTVYsR0FBRyxLQUFLLENBQUMsR0FBSSxJQUFJLEdBQUssSUFBSTtNQUMzQ1EsSUFBSSxDQUFDRSxHQUFHLEVBQUUsQ0FBQyxHQUFNVixHQUFHLEtBQUssRUFBRSxHQUFJLElBQUksR0FBSyxJQUFJO01BQzVDUSxJQUFJLENBQUNFLEdBQUcsRUFBRSxDQUFDLEdBQU1WLEdBQUcsS0FBSyxFQUFFLEdBQUksSUFBSSxHQUFLLElBQUk7TUFDNUNRLElBQUksQ0FBQ0UsR0FBRyxFQUFFLENBQUMsR0FBR1YsR0FBRyxLQUFLLEVBQUU7SUFDNUI7RUFDSjtFQUNBLE9BQU9NLEdBQUc7QUFDZCxDQUFDOztBQUVEO0FBQ0FSLHNCQUFzQixDQUFDYSxzQkFBc0IsR0FBRyxVQUFTVCxLQUFLLEVBQUU7RUFDNUQsSUFBSU0sSUFBSSxHQUFLLElBQUlDLFNBQVMsQ0FBQ1AsS0FBSyxDQUFDO0VBQ2pDLElBQUlDLENBQUMsR0FBR0ssSUFBSSxDQUFDakgsTUFBTTtFQUNuQixJQUFJc0IsS0FBSyxHQUFHLENBQUM7RUFDYixLQUFJLElBQUlpQixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdxRSxDQUFDLEVBQUVyRSxDQUFDLEVBQUUsRUFBRTtJQUN2QmpCLEtBQUssSUFBS3FGLEtBQUssQ0FBQ3BFLENBQUMsQ0FBQyxLQUFHLENBQUU7RUFDM0I7RUFDQSxPQUFPcUUsQ0FBQyxHQUFHdEYsS0FBSztBQUNwQixDQUFDO0FBQ0Q7QUFDQWlGLHNCQUFzQixDQUFDYyxVQUFVLEdBQUcsVUFBU1YsS0FBSyxFQUFFO0VBQ2hELElBQUlXLEtBQUssR0FBRyxFQUFFO0VBQ2QsSUFBSUMsTUFBTSxHQUFHLElBQUlMLFNBQVMsQ0FBQ1AsS0FBSyxDQUFDO0VBQ2pDLElBQUlhLEdBQUcsR0FBR0QsTUFBTSxDQUFDdkgsTUFBTTtFQUN2QixJQUFJbUgsR0FBRyxHQUFHLENBQUM7RUFFWCxPQUFPSyxHQUFHLEdBQUdMLEdBQUcsRUFBRTtJQUNkLElBQUlQLENBQUMsR0FBR1csTUFBTSxDQUFDSixHQUFHLEVBQUUsQ0FBQztJQUNyQixJQUFJdkosQ0FBQyxHQUFHZ0osQ0FBQyxHQUFHLElBQUk7SUFDaEIsSUFBSUEsQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUNSVSxLQUFLLENBQUM3RSxJQUFJLENBQUM3RSxDQUFDLENBQUM7TUFDYjtJQUNKO0lBQ0FnSixDQUFDLEdBQUdXLE1BQU0sQ0FBQ0osR0FBRyxFQUFFLENBQUM7SUFDakJ2SixDQUFDLElBQUksQ0FBQ2dKLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQztJQUNwQixJQUFJQSxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ1JVLEtBQUssQ0FBQzdFLElBQUksQ0FBQzdFLENBQUMsQ0FBQztNQUNiO0lBQ0o7SUFDQWdKLENBQUMsR0FBR1csTUFBTSxDQUFDSixHQUFHLEVBQUUsQ0FBQztJQUNqQnZKLENBQUMsSUFBSSxDQUFDZ0osQ0FBQyxHQUFHLElBQUksS0FBSyxFQUFFO0lBQ3JCLElBQUlBLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFDUlUsS0FBSyxDQUFDN0UsSUFBSSxDQUFDN0UsQ0FBQyxDQUFDO01BQ2I7SUFDSjtJQUNBZ0osQ0FBQyxHQUFHVyxNQUFNLENBQUNKLEdBQUcsRUFBRSxDQUFDO0lBQ2pCdkosQ0FBQyxJQUFJLENBQUNnSixDQUFDLEdBQUcsSUFBSSxLQUFLLEVBQUU7SUFDckIsSUFBSUEsQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUNSVSxLQUFLLENBQUM3RSxJQUFJLENBQUM3RSxDQUFDLENBQUM7TUFDYjtJQUNKO0lBQ0FnSixDQUFDLEdBQUdXLE1BQU0sQ0FBQ0osR0FBRyxFQUFFLENBQUM7SUFDakJ2SixDQUFDLElBQUlnSixDQUFDLElBQUksRUFBRTtJQUNaVSxLQUFLLENBQUM3RSxJQUFJLENBQUM3RSxDQUFDLENBQUM7RUFDakI7RUFDQSxPQUFPMEosS0FBSztBQUNoQixDQUFDO0FBRURHLEdBQUcsR0FBRztFQUNGWCxRQUFRLEVBQUUsU0FBQUEsQ0FBVVksWUFBWSxFQUFFO0lBQzlCLFlBQVk7O0lBQ1o7SUFDQSxJQUFJbkYsQ0FBQztNQUNEb0YsVUFBVSxHQUFHLENBQUMsQ0FBQztNQUNmZixDQUFDO01BQ0RnQixFQUFFO01BQ0ZDLENBQUMsR0FBRyxFQUFFO01BQ05DLE1BQU0sR0FBRyxFQUFFO01BQ1hDLFFBQVEsR0FBRyxHQUFHO0lBQ2xCLEtBQUt4RixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUcsR0FBRyxFQUFFQSxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ3pCb0YsVUFBVSxDQUFDSyxNQUFNLENBQUNDLFlBQVksQ0FBQzFGLENBQUMsQ0FBQyxDQUFDLEdBQUdBLENBQUM7SUFDMUM7SUFFQSxLQUFLQSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdtRixZQUFZLENBQUMxSCxNQUFNLEVBQUV1QyxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ3pDcUUsQ0FBQyxHQUFHYyxZQUFZLENBQUNRLE1BQU0sQ0FBQzNGLENBQUMsQ0FBQztNQUMxQnFGLEVBQUUsR0FBR0MsQ0FBQyxHQUFHakIsQ0FBQztNQUNWO01BQ0E7TUFDQTtNQUNBLElBQUllLFVBQVUsQ0FBQ1EsY0FBYyxDQUFDUCxFQUFFLENBQUMsRUFBRTtRQUMvQkMsQ0FBQyxHQUFHRCxFQUFFO01BQ1YsQ0FBQyxNQUFNO1FBQ0hFLE1BQU0sQ0FBQ3JGLElBQUksQ0FBQ2tGLFVBQVUsQ0FBQ0UsQ0FBQyxDQUFDLENBQUM7UUFDMUI7UUFDQUYsVUFBVSxDQUFDQyxFQUFFLENBQUMsR0FBR0csUUFBUSxFQUFFO1FBQzNCRixDQUFDLEdBQUdHLE1BQU0sQ0FBQ3BCLENBQUMsQ0FBQztNQUNqQjtJQUNKOztJQUVBO0lBQ0EsSUFBSWlCLENBQUMsS0FBSyxFQUFFLEVBQUU7TUFDVkMsTUFBTSxDQUFDckYsSUFBSSxDQUFDa0YsVUFBVSxDQUFDRSxDQUFDLENBQUMsQ0FBQztJQUM5QjtJQUNBLE9BQU9DLE1BQU07RUFDakIsQ0FBQztFQUdETSxVQUFVLEVBQUUsU0FBQUEsQ0FBVUMsVUFBVSxFQUFFO0lBQzlCLFlBQVk7O0lBQ1o7SUFDQSxJQUFJOUYsQ0FBQztNQUNEb0YsVUFBVSxHQUFHLEVBQUU7TUFDZkUsQ0FBQztNQUNEQyxNQUFNO01BQ05RLENBQUM7TUFDREMsS0FBSyxHQUFHLEVBQUU7TUFDVlIsUUFBUSxHQUFHLEdBQUc7SUFDbEIsS0FBS3hGLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyxHQUFHLEVBQUVBLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFDekJvRixVQUFVLENBQUNwRixDQUFDLENBQUMsR0FBR3lGLE1BQU0sQ0FBQ0MsWUFBWSxDQUFDMUYsQ0FBQyxDQUFDO0lBQzFDO0lBRUFzRixDQUFDLEdBQUdHLE1BQU0sQ0FBQ0MsWUFBWSxDQUFDSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdENQLE1BQU0sR0FBR0QsQ0FBQztJQUNWLEtBQUt0RixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc4RixVQUFVLENBQUNySSxNQUFNLEVBQUV1QyxDQUFDLElBQUksQ0FBQyxFQUFFO01BRXZDK0YsQ0FBQyxHQUFHRCxVQUFVLENBQUM5RixDQUFDLENBQUM7TUFDakIsSUFBSW9GLFVBQVUsQ0FBQ1csQ0FBQyxDQUFDLEVBQUU7UUFDZkMsS0FBSyxHQUFHWixVQUFVLENBQUNXLENBQUMsQ0FBQztNQUN6QixDQUFDLE1BQU07UUFDSCxJQUFJQSxDQUFDLEtBQUtQLFFBQVEsRUFBRTtVQUNoQlEsS0FBSyxHQUFHVixDQUFDLEdBQUdBLENBQUMsQ0FBQ0ssTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMzQixDQUFDLE1BQU07VUFDSCxPQUFPLElBQUk7UUFDZjtNQUNKO01BRUFKLE1BQU0sSUFBSVMsS0FBSztNQUVmWixVQUFVLENBQUNJLFFBQVEsRUFBRSxDQUFDLEdBQUdGLENBQUMsR0FBR1UsS0FBSyxDQUFDTCxNQUFNLENBQUMsQ0FBQyxDQUFDO01BRTVDTCxDQUFDLEdBQUdVLEtBQUs7SUFDYjtJQUNBLE9BQU9ULE1BQU07RUFDakI7QUFDSixDQUFDO0FBRUQsU0FBU1UsYUFBYUEsQ0FBQ0MsR0FBRyxFQUFDO0VBQ3ZCLElBQUluRixPQUFPLEdBQUdvRixJQUFJLENBQUNDLFNBQVMsQ0FBQ0YsR0FBRyxDQUFDO0VBQ2pDbkYsT0FBTyxHQUFHbUUsR0FBRyxDQUFDWCxRQUFRLENBQUN4RCxPQUFPLENBQUM7RUFDL0JBLE9BQU8sR0FBR2lELHNCQUFzQixDQUFDTyxRQUFRLENBQUN4RCxPQUFPLENBQUM7RUFDbEQsT0FBT0EsT0FBTztBQUNsQjtBQUVBLFNBQVNzRixhQUFhQSxDQUFDQyxLQUFLLEVBQUM7RUFFekIsSUFBSUEsS0FBSyxDQUFDQyxVQUFVLEdBQUksQ0FBQyxFQUFFO0lBQ3ZCLE1BQU1wSixJQUFJLEdBQUc2RyxzQkFBc0IsQ0FBQ2MsVUFBVSxDQUFDd0IsS0FBSyxDQUFDO0lBQ3JELE1BQU01SCxHQUFHLEdBQUd3RyxHQUFHLENBQUNXLFVBQVUsQ0FBQzFJLElBQUksQ0FBQztJQUNoQyxPQUFPZ0osSUFBSSxDQUFDL0ksS0FBSyxDQUFDc0IsR0FBRyxDQUFDO0VBQzFCLENBQUMsTUFBSyxPQUFPLElBQUk7QUFDckI7QUExTUF2RCxNQUFNLENBQUNxTCxhQUFhLENBNE1MO0VBQ1hqQyxRQUFRLEVBQUdwSCxJQUFJLElBQUk4SSxhQUFhLENBQUM5SSxJQUFJLENBQUU7RUFDdkMySCxVQUFVLEVBQUczSCxJQUFJLElBQUlrSixhQUFhLENBQUNsSixJQUFJO0FBQzNDLENBL013QixDQUFDLEM7Ozs7Ozs7Ozs7O0FDQXpCLElBQUlzSixtQkFBbUI7QUFBQ3RMLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLHVCQUF1QixFQUFDO0VBQUNlLE9BQU9BLENBQUNkLENBQUMsRUFBQztJQUFDb0wsbUJBQW1CLEdBQUNwTCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSXFMLGlCQUFpQjtBQUFDdkwsTUFBTSxDQUFDQyxJQUFJLENBQUMsVUFBVSxFQUFDO0VBQUNlLE9BQU9BLENBQUNkLENBQUMsRUFBQztJQUFDcUwsaUJBQWlCLEdBQUNyTCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSXNMLFFBQVE7QUFBQ3hMLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLE1BQU0sRUFBQztFQUFDdUwsUUFBUUEsQ0FBQ3RMLENBQUMsRUFBQztJQUFDc0wsUUFBUSxHQUFDdEwsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUl1TCxRQUFRO0FBQUN6TCxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ3dMLFFBQVFBLENBQUN2TCxDQUFDLEVBQUM7SUFBQ3VMLFFBQVEsR0FBQ3ZMLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJaUIsS0FBSztBQUFDbkIsTUFBTSxDQUFDQyxJQUFJLENBQUMsT0FBTyxFQUFDO0VBQUMsR0FBR3lMLENBQUN4TCxDQUFDLEVBQUM7SUFBQ2lCLEtBQUssR0FBQ2pCLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJZSxZQUFZO0FBQUNqQixNQUFNLENBQUNDLElBQUksQ0FBQyxtQ0FBbUMsRUFBQztFQUFDZSxPQUFPQSxDQUFDZCxDQUFDLEVBQUM7SUFBQ2UsWUFBWSxHQUFDZixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBT2hjeUwsTUFBTSxDQUFDQyxlQUFlLENBQUNDLEdBQUcsQ0FBQyxXQUFXLEVBQUVDLFlBQVksQ0FBQztBQUNyREgsTUFBTSxDQUFDQyxlQUFlLENBQUNDLEdBQUcsQ0FBQyxjQUFjLEVBQUVFLGlCQUFpQixDQUFDQyxJQUFJLENBQUM7RUFBQ0MsUUFBUSxFQUFFO0FBQUssQ0FBQyxDQUFDLENBQUM7QUFDckZOLE1BQU0sQ0FBQ0MsZUFBZSxDQUFDQyxHQUFHLENBQUMsY0FBYyxFQUFFRSxpQkFBaUIsQ0FBQ0MsSUFBSSxDQUFDO0VBQUNDLFFBQVEsRUFBRTtBQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3BGTixNQUFNLENBQUNDLGVBQWUsQ0FBQ0MsR0FBRyxDQUFDLGNBQWMsRUFBRUssYUFBYSxDQUFDO0FBRXpELE1BQU07RUFBQ0MsWUFBWTtFQUFFQyxpQkFBaUI7RUFBRUM7QUFBZ0IsQ0FBQyxHQUFHZCxpQkFBaUI7QUFDN0UsSUFBSXRLLFlBQVksQ0FBQ0UsS0FBSyxDQUFDO0FBRXZCLFNBQVMrSyxhQUFhQSxDQUFDSSxHQUFHLEVBQUVDLEdBQUcsRUFBRUMsSUFBSSxFQUFFO0VBQ25DLE1BQU1DLEdBQUcsR0FBR3RNLFVBQVUsQ0FBQ08sSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQzVCRyxNQUFNLEVBQUU7TUFDSkYsR0FBRyxFQUFFLENBQUM7TUFDTitMLE1BQU0sRUFBRSxDQUFDO01BQ1Q1TCxJQUFJLEVBQUUsQ0FBQztNQUNQNkwsSUFBSSxFQUFFLENBQUM7TUFDUEMsYUFBYSxFQUFFLENBQUM7TUFDaEJDLFlBQVksRUFBRTtJQUNsQjtFQUNKLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUNWUCxHQUFHLENBQUN6QyxHQUFHLENBQUNrQixJQUFJLENBQUNDLFNBQVMsQ0FBQ3dCLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDekM7QUFFQSxTQUFTWCxZQUFZQSxDQUFDUSxHQUFHLEVBQUVDLEdBQUcsRUFBRUMsSUFBSSxFQUFFO0VBQ2xDRCxHQUFHLENBQUNRLFNBQVMsQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLENBQUM7RUFDakQsTUFBTXpHLElBQUksR0FBR25HLFVBQVUsQ0FBQzZNLE9BQU8sQ0FBQztJQUFDck0sR0FBRyxFQUFFMkwsR0FBRyxDQUFDM0w7RUFBRyxDQUFDLENBQUM7RUFDL0MsSUFBSTJGLElBQUksRUFBRTtJQUNOLE1BQU0yRyxHQUFHLEdBQUdaLGdCQUFnQixDQUFDYSxHQUFHLENBQUM1RyxJQUFJLENBQUM2RyxPQUFPLENBQUM7SUFDOUM3RyxJQUFJLENBQUM4RyxPQUFPLENBQUNDLE9BQU8sQ0FBQ3RDLEdBQUcsSUFBSTtNQUN4QkEsR0FBRyxDQUFDcEYsS0FBSyxHQUFHc0gsR0FBRyxDQUFDRyxPQUFPLENBQUNyQyxHQUFHLENBQUNsRSxVQUFVLENBQUMsQ0FBQ2xCLEtBQUs7SUFDakQsQ0FBQyxDQUFDO0lBQ0Y0RyxHQUFHLENBQUN6QyxHQUFHLENBQUNrQixJQUFJLENBQUNDLFNBQVMsQ0FBQzNFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDMUMsQ0FBQyxNQUFJO0lBQ0RpRyxHQUFHLENBQUN6QyxHQUFHLENBQUMsSUFBSSxDQUFDO0VBQ2pCO0FBQ0o7QUFFQSxTQUFTaUMsaUJBQWlCQSxDQUFDTyxHQUFHLEVBQUVDLEdBQUcsRUFBRUMsSUFBSSxFQUFFO0VBQ3ZDLE1BQU1jLE9BQU8sR0FBR25CLFlBQVksR0FBR29CLGtCQUFrQixDQUFDakIsR0FBRyxDQUFDM0wsR0FBRyxDQUFDO0VBQzFELE1BQU02TSxRQUFRLEdBQUdoQyxRQUFRLENBQUM4QixPQUFPLENBQUM7RUFDbEMsTUFBTUcsU0FBUyxHQUFHckIsaUJBQWlCLEdBQUdtQixrQkFBa0IsQ0FBQ2pCLEdBQUcsQ0FBQzNMLEdBQUcsQ0FBQyxHQUFHLFNBQVM7RUFDN0UsTUFBTStNLFVBQVUsR0FBR3RCLGlCQUFpQixHQUFHbUIsa0JBQWtCLENBQUNqQixHQUFHLENBQUMzTCxHQUFHLENBQUMsR0FBRyxVQUFVO0VBRS9FLElBQUksSUFBSSxDQUFDc0wsUUFBUSxFQUFFO0lBQ2ZNLEdBQUcsQ0FBQ1EsU0FBUyxDQUFDLHFCQUFxQixFQUFFLDBCQUEwQixDQUFDdkosT0FBTyxDQUFDLEtBQUssRUFBRWdLLFFBQVEsQ0FBQyxDQUFDO0lBQ3pGakIsR0FBRyxDQUFDUSxTQUFTLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQztJQUMzQ1IsR0FBRyxDQUFDb0IsT0FBTyxHQUFHLE9BQU87RUFDekI7RUFHQWxDLFFBQVEsQ0FBQzZCLE9BQU8sRUFBRSxDQUFDTSxHQUFHLEVBQUVDLE9BQU8sS0FBSztJQUNoQyxJQUFJRCxHQUFHLEVBQUU7TUFDTHJCLEdBQUcsQ0FBQ3pDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQztJQUM1QztJQUVBLE1BQU1sSSxNQUFNLEdBQUcsSUFBSVQsS0FBSyxDQUFDQyxTQUFTLENBQUMsSUFBSSxDQUFDO0lBQ3hDLE1BQU0wTSxVQUFVLEdBQUdsTSxNQUFNLENBQUNLLEtBQUssQ0FBQzRMLE9BQU8sQ0FBQ3BHLE1BQU0sRUFBRSxFQUFFLENBQUM7SUFDbkQsTUFBTXNHLE1BQU0sR0FBR0QsVUFBVSxDQUFDakksR0FBRyxDQUFDdkQsTUFBTSxHQUFHLENBQUM7SUFDeEMsTUFBTTBMLElBQUksR0FBR0YsVUFBVSxDQUFDbEYsTUFBTTtJQUM5QixNQUFNcUYsT0FBTyxHQUFHcEksR0FBRyxJQUFJQSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHQSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBR0EsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUVqRSxJQUFJcUksR0FBRyxHQUFHLGNBQWM7SUFDeEJBLEdBQUcsSUFBSUgsTUFBTSxHQUFHLGlDQUFpQyxHQUFHLDZCQUE2QjtJQUNqRkcsR0FBRyxJQUFJSCxNQUFNLEdBQUcsb0JBQW9CLEdBQUcsa0JBQWtCO0lBQ3pERyxHQUFHLElBQUlILE1BQU0sR0FBRyxvQkFBb0IsR0FBRyxrQkFBa0I7SUFDekRHLEdBQUcsSUFBSUgsTUFBTSxHQUFHLHFCQUFxQixHQUFHLG1CQUFtQjtJQUMzREcsR0FBRyxJQUFJLFFBQVEsR0FBR0osVUFBVSxDQUFDbEYsTUFBTSxDQUFDL0UsS0FBSyxHQUFHLElBQUk7SUFDaERxSyxHQUFHLElBQUksU0FBUyxHQUFHSixVQUFVLENBQUNsRixNQUFNLENBQUM5RSxNQUFNLEdBQUcsSUFBSTtJQUNsRG9LLEdBQUcsSUFBSSxTQUFTLEdBQUdKLFVBQVUsQ0FBQ2xGLE1BQU0sQ0FBQy9FLEtBQUssR0FBQ2lLLFVBQVUsQ0FBQ2xGLE1BQU0sQ0FBQzlFLE1BQU0sR0FBRyxJQUFJO0lBQzFFb0ssR0FBRyxJQUFJLFlBQVksR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDTyxFQUFFO0lBQ3ZDNEosR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDUSxFQUFFO0lBQzlCMkosR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDUyxFQUFFO0lBQzlCMEosR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDVSxFQUFFO0lBQzlCeUosR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDVyxFQUFFO0lBQzlCd0osR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDWSxFQUFFO0lBQzlCdUosR0FBRyxJQUFJLEdBQUcsR0FBR0YsSUFBSSxDQUFDakssU0FBUyxDQUFDYSxFQUFFLEdBQUcsSUFBSTtJQUNyQ3NKLEdBQUcsSUFBSSxjQUFjO0lBQ3JCM0IsR0FBRyxDQUFDNEIsS0FBSyxDQUFDRCxHQUFHLENBQUM7SUFDZEEsR0FBRyxHQUFHLEVBQUU7SUFDUnpDLFFBQVEsQ0FBQ2dDLFNBQVMsRUFBRSxDQUFDVyxRQUFRLEVBQUVDLFlBQVksS0FBSztNQUM1QyxJQUFJRCxRQUFRLEVBQUU7UUFDVjdCLEdBQUcsQ0FBQ3pDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQztNQUMvQztNQUNBLE1BQU13RSxNQUFNLEdBQUdoRCxtQkFBbUIsQ0FBQzNCLFVBQVUsQ0FBQzBFLFlBQVksQ0FBQztNQUUzRDVDLFFBQVEsQ0FBQ2lDLFVBQVUsRUFBRSxDQUFDYSxTQUFTLEVBQUVDLGFBQWEsS0FBSztRQUMvQyxJQUFJQyxnQkFBZ0IsR0FBRyxJQUFJO1FBQzNCLElBQUlGLFNBQVMsRUFBRTtVQUNYRSxnQkFBZ0IsR0FBRyxLQUFLO1FBQzVCO1FBRUEsTUFBTUMsa0JBQWtCLEdBQUcsSUFBSUMsR0FBRyxDQUFDLENBQUM7UUFFcEMsSUFBSUYsZ0JBQWdCLEVBQUU7VUFDbEIsTUFBTXJCLE9BQU8sR0FBRzlCLG1CQUFtQixDQUFDM0IsVUFBVSxDQUFDNkUsYUFBYSxDQUFDO1VBQzdEcEIsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQ3RDLEdBQUcsRUFBRTZELFFBQVEsS0FBSztZQUMvQjdELEdBQUcsQ0FBQy9HLE1BQU0sQ0FBQ3FKLE9BQU8sQ0FBQ3dCLEtBQUssSUFBSTtjQUN4Qkgsa0JBQWtCLENBQUNJLEdBQUcsQ0FBQ0QsS0FBSyxFQUFFRCxRQUFRLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1VBQ04sQ0FBQyxDQUFDO1FBQ047UUFDQSxJQUFJN0QsR0FBRztRQUVQK0MsVUFBVSxDQUFDckksUUFBUSxDQUFDNEgsT0FBTyxDQUFDLENBQUNuTixDQUFDLEVBQUUyRSxDQUFDLEtBQUs7VUFDbEMsTUFBTVksUUFBUSxHQUFHc0osSUFBSSxDQUFDQyxLQUFLLENBQUNuSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1VBRWxDLFFBQVFBLENBQUMsR0FBRyxDQUFDO1lBQ1QsS0FBSyxDQUFDO2NBQ0YsSUFBSWtKLE1BQU0sRUFBRTtnQkFDUmhELEdBQUcsR0FBRztrQkFBQ2xGLEdBQUcsRUFBRWlJLFVBQVUsQ0FBQ2pJLEdBQUcsQ0FBQ0osUUFBUSxDQUFDO2tCQUFFcEIsQ0FBQyxFQUFFbkU7Z0JBQUMsQ0FBQztjQUMvQyxDQUFDLE1BQUk7Z0JBQ0Q2SyxHQUFHLEdBQUc7a0JBQUMxRyxDQUFDLEVBQUVuRTtnQkFBQyxDQUFDO2NBQ2hCO2NBQ0E7WUFDSixLQUFLLENBQUM7Y0FDRjZLLEdBQUcsQ0FBQ3ZFLENBQUMsR0FBR3RHLENBQUM7Y0FDVDtZQUNKLEtBQUssQ0FBQztjQUNGNkssR0FBRyxDQUFDdEUsQ0FBQyxHQUFHdkcsQ0FBQztjQUNUZ08sR0FBRyxJQUFJbkQsR0FBRyxDQUFDMUcsQ0FBQyxHQUFHLEdBQUcsR0FBRzBHLEdBQUcsQ0FBQ3ZFLENBQUMsR0FBRyxHQUFHLEdBQUd1RSxHQUFHLENBQUN0RSxDQUFDLEdBQUcsR0FBRztjQUM5QyxJQUFJc0gsTUFBTSxFQUFFO2dCQUNSRyxHQUFHLElBQUlELE9BQU8sQ0FBQ2xELEdBQUcsQ0FBQ2xGLEdBQUcsQ0FBQyxHQUFHLEdBQUc7Y0FDakM7Y0FDQXFJLEdBQUcsSUFBSUksTUFBTSxDQUFDN0ksUUFBUSxDQUFDLEdBQUcsR0FBRztjQUM3QixNQUFNd0osY0FBYyxHQUFHUCxrQkFBa0IsQ0FBQ3hCLEdBQUcsQ0FBQ3pILFFBQVEsQ0FBQztjQUN2RCxJQUFJd0osY0FBYyxJQUFJckksU0FBUyxFQUMzQnNILEdBQUcsSUFBSWUsY0FBYyxDQUFDLEtBRXRCZixHQUFHLElBQUksSUFBSTtjQUNmQSxHQUFHLElBQUksSUFBSTtjQUNYM0IsR0FBRyxDQUFDNEIsS0FBSyxDQUFDRCxHQUFHLENBQUM7Y0FDZEEsR0FBRyxHQUFHLEVBQUU7Y0FDUjtVQUNSO1FBQ0osQ0FBQyxDQUFDO1FBRUYzQixHQUFHLENBQUN6QyxHQUFHLENBQUMsQ0FBQztNQUNiLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztFQUNOLENBQUMsQ0FBQztBQUNOLEM7Ozs7Ozs7Ozs7O0FDbEpBLElBQUkvSixNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSXlJLElBQUk7QUFBQzNJLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLE1BQU0sRUFBQztFQUFDMEksSUFBSUEsQ0FBQ3pJLENBQUMsRUFBQztJQUFDeUksSUFBSSxHQUFDekksQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlnUCxTQUFTLEVBQUNDLFVBQVU7QUFBQ25QLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQztFQUFDaVAsU0FBU0EsQ0FBQ2hQLENBQUMsRUFBQztJQUFDZ1AsU0FBUyxHQUFDaFAsQ0FBQztFQUFBLENBQUM7RUFBQ2lQLFVBQVVBLENBQUNqUCxDQUFDLEVBQUM7SUFBQ2lQLFVBQVUsR0FBQ2pQLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJa1AsRUFBRTtBQUFDcFAsTUFBTSxDQUFDQyxJQUFJLENBQUMsSUFBSSxFQUFDO0VBQUNlLE9BQU9BLENBQUNkLENBQUMsRUFBQztJQUFDa1AsRUFBRSxHQUFDbFAsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUltUCxRQUFRO0FBQUNyUCxNQUFNLENBQUNDLElBQUksQ0FBQyxVQUFVLEVBQUM7RUFBQ2UsT0FBT0EsQ0FBQ2QsQ0FBQyxFQUFDO0lBQUNtUCxRQUFRLEdBQUNuUCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBTW5VLE1BQU1xTCxpQkFBaUIsR0FBRyxDQUFDLENBQUM7QUFDNUIsTUFBTStELGNBQWMsR0FBRyxDQUFDO0VBQ3BCLE1BQU0sRUFBRSxZQUFZO0VBQUUsU0FBUyxFQUFFLENBQzdCO0lBQUMsT0FBTyxFQUFFLE1BQU07SUFBRSxPQUFPLEVBQUU7RUFBUyxDQUFDLEVBQ3JDO0lBQUMsT0FBTyxFQUFFO0VBQVMsQ0FBQyxFQUNwQjtJQUFDLE9BQU8sRUFBRTtFQUFTLENBQUMsRUFDcEI7SUFBQyxPQUFPLEVBQUU7RUFBUyxDQUFDLEVBQ3BCO0lBQUMsT0FBTyxFQUFFO0VBQVMsQ0FBQyxFQUNwQjtJQUFDLE9BQU8sRUFBRTtFQUFTLENBQUMsRUFDcEI7SUFBQyxPQUFPLEVBQUU7RUFBUyxDQUFDLEVBQ3BCO0lBQUMsT0FBTyxFQUFFO0VBQVMsQ0FBQyxFQUNwQjtJQUFDLE9BQU8sRUFBRTtFQUFTLENBQUMsRUFDcEI7SUFBQyxPQUFPLEVBQUU7RUFBUyxDQUFDLEVBQ3BCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUMsRUFDckI7SUFBQyxPQUFPLEVBQUU7RUFBVSxDQUFDLEVBQ3JCO0lBQUMsT0FBTyxFQUFFO0VBQVUsQ0FBQyxFQUNyQjtJQUFDLE9BQU8sRUFBRTtFQUFVLENBQUM7QUFFN0IsQ0FBQyxDQUFDO0FBQ0YsTUFBTUMsSUFBSSxHQUFHQSxDQUFBLEtBQUs7RUFDZCxJQUFJO0lBQ0EsTUFBTUMsTUFBTSxHQUFHelAsTUFBTSxDQUFDMFAsUUFBUTtJQUU5QixJQUFJRCxNQUFNLENBQUNFLGFBQWEsSUFBSUYsTUFBTSxDQUFDRSxhQUFhLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxFQUFFO01BQ3JFbkUsaUJBQWlCLENBQUNZLFlBQVksR0FBR3FELE1BQU0sQ0FBQ0UsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDbE0sT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUM7SUFDN0YsQ0FBQyxNQUFJO01BQ0QrSCxpQkFBaUIsQ0FBQ1ksWUFBWSxHQUFHeEQsSUFBSSxDQUFDeUcsRUFBRSxDQUFDTyxPQUFPLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQztJQUNyRTtJQUVBLElBQUksQ0FBQ1IsVUFBVSxDQUFDNUQsaUJBQWlCLENBQUNZLFlBQVksQ0FBQyxFQUFDO01BQzVDK0MsU0FBUyxDQUFDM0QsaUJBQWlCLENBQUNZLFlBQVksQ0FBQztNQUN6Q2tELFFBQVEsQ0FBQywrSUFBK0ksRUFBRTlELGlCQUFpQixDQUFDWSxZQUFZLENBQUM7TUFDekxrRCxRQUFRLENBQUMsbUpBQW1KLEVBQUU5RCxpQkFBaUIsQ0FBQ1ksWUFBWSxDQUFDO0lBQ2pNO0lBRUEsSUFBSXFELE1BQU0sQ0FBQ0UsYUFBYSxJQUFJRixNQUFNLENBQUNFLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsRUFBRTtNQUN2RW5FLGlCQUFpQixDQUFDYSxpQkFBaUIsR0FBR29ELE1BQU0sQ0FBQ0UsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUNsTSxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQztJQUNwRyxDQUFDLE1BQUk7TUFFRCtILGlCQUFpQixDQUFDYSxpQkFBaUIsR0FBR3pELElBQUksQ0FBQ3lHLEVBQUUsQ0FBQ08sT0FBTyxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUM7SUFDNUU7SUFFQXBFLGlCQUFpQixDQUFDYyxnQkFBZ0IsR0FBRyxJQUFJc0MsR0FBRyxDQUFDLENBQUM7SUFDOUNwRCxpQkFBaUIsQ0FBQ3FFLGFBQWEsR0FBR0osTUFBTSxDQUFDLGlCQUFpQixDQUFDO0lBQzNELElBQUksQ0FBQ2pFLGlCQUFpQixDQUFDcUUsYUFBYSxFQUFDO01BQ2pDckUsaUJBQWlCLENBQUNxRSxhQUFhLEdBQUdOLGNBQWM7SUFDcEQ7SUFDQS9ELGlCQUFpQixDQUFDcUUsYUFBYSxDQUFDdkMsT0FBTyxDQUFDd0MsQ0FBQyxJQUFJdEUsaUJBQWlCLENBQUNjLGdCQUFnQixDQUFDeUMsR0FBRyxDQUFDZSxDQUFDLENBQUNwSCxJQUFJLEVBQUVvSCxDQUFDLENBQUMsQ0FBQztJQUMvRkMsT0FBTyxDQUFDQyxHQUFHLENBQUMsOEJBQThCLENBQUM7SUFDM0NELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLG9DQUFvQyxFQUFFeEUsaUJBQWlCLENBQUNZLFlBQVksQ0FBQztJQUNqRjJELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLHdDQUF3QyxFQUFFeEUsaUJBQWlCLENBQUNhLGlCQUFpQixDQUFDO0lBQzFGMEQsT0FBTyxDQUFDQyxHQUFHLENBQUMsNkNBQTZDLEVBQUV4RSxpQkFBaUIsQ0FBQ3FFLGFBQWEsQ0FBQ3ROLE1BQU0sQ0FBQztJQUNsRyxPQUFPaUosaUJBQWlCO0VBQzVCLENBQUMsUUFBTXlFLENBQUMsRUFBQztJQUNMRixPQUFPLENBQUNHLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRUQsQ0FBQyxDQUFDO0VBQzFEO0FBQ0osQ0FBQztBQWpGRGhRLE1BQU0sQ0FBQ3FMLGFBQWEsQ0FrRkxrRSxJQUFJLENBQUMsQ0FsRkksQ0FBQyxDOzs7Ozs7Ozs7OztBQ0F6QixJQUFJeFAsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlnUSxLQUFLO0FBQUNsUSxNQUFNLENBQUNDLElBQUksQ0FBQyxTQUFTLEVBQUM7RUFBQ2UsT0FBT0EsQ0FBQ2QsQ0FBQyxFQUFDO0lBQUNnUSxLQUFLLEdBQUNoUSxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSWlRLFdBQVc7QUFBQ25RLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDZSxPQUFPQSxDQUFDZCxDQUFDLEVBQUM7SUFBQ2lRLFdBQVcsR0FBQ2pRLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJa1EsVUFBVTtBQUFDcFEsTUFBTSxDQUFDQyxJQUFJLENBQUMsYUFBYSxFQUFDO0VBQUNlLE9BQU9BLENBQUNkLENBQUMsRUFBQztJQUFDa1EsVUFBVSxHQUFDbFEsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUltUSxpQkFBaUIsRUFBQ0MsU0FBUyxFQUFDQyxXQUFXLEVBQUM5RSxRQUFRLEVBQUMrRSxZQUFZO0FBQUN4USxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ29RLGlCQUFpQkEsQ0FBQ25RLENBQUMsRUFBQztJQUFDbVEsaUJBQWlCLEdBQUNuUSxDQUFDO0VBQUEsQ0FBQztFQUFDb1EsU0FBU0EsQ0FBQ3BRLENBQUMsRUFBQztJQUFDb1EsU0FBUyxHQUFDcFEsQ0FBQztFQUFBLENBQUM7RUFBQ3FRLFdBQVdBLENBQUNyUSxDQUFDLEVBQUM7SUFBQ3FRLFdBQVcsR0FBQ3JRLENBQUM7RUFBQSxDQUFDO0VBQUN1TCxRQUFRQSxDQUFDdkwsQ0FBQyxFQUFDO0lBQUN1TCxRQUFRLEdBQUN2TCxDQUFDO0VBQUEsQ0FBQztFQUFDc1EsWUFBWUEsQ0FBQ3RRLENBQUMsRUFBQztJQUFDc1EsWUFBWSxHQUFDdFEsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlzTCxRQUFRLEVBQUNpRixPQUFPLEVBQUM5SCxJQUFJO0FBQUMzSSxNQUFNLENBQUNDLElBQUksQ0FBQyxNQUFNLEVBQUM7RUFBQ3VMLFFBQVFBLENBQUN0TCxDQUFDLEVBQUM7SUFBQ3NMLFFBQVEsR0FBQ3RMLENBQUM7RUFBQSxDQUFDO0VBQUN1USxPQUFPQSxDQUFDdlEsQ0FBQyxFQUFDO0lBQUN1USxPQUFPLEdBQUN2USxDQUFDO0VBQUEsQ0FBQztFQUFDeUksSUFBSUEsQ0FBQ3pJLENBQUMsRUFBQztJQUFDeUksSUFBSSxHQUFDekksQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlxTCxpQkFBaUI7QUFBQ3ZMLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLFVBQVUsRUFBQztFQUFDZSxPQUFPQSxDQUFDZCxDQUFDLEVBQUM7SUFBQ3FMLGlCQUFpQixHQUFDckwsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQU83ckIsTUFBTXdRLFFBQVEsR0FBRzNRLE1BQU0sQ0FBQzBQLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLFdBQVcsQ0FBQztBQUUzRDNQLE1BQU0sQ0FBQzRRLE9BQU8sQ0FBQyxNQUFNO0VBRXJCLE1BQU07SUFBQ3hFLFlBQVk7SUFBRUM7RUFBaUIsQ0FBQyxHQUFHYixpQkFBaUI7RUFDdkRJLE1BQU0sQ0FBQ0MsZUFBZSxDQUFDQyxHQUFHLENBQUMsT0FBTyxFQUFFc0UsV0FBVyxDQUFDaEUsWUFBWSxFQUFFO0lBQUN5RSxXQUFXLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQztFQUNwRmpGLE1BQU0sQ0FBQ0MsZUFBZSxDQUFDQyxHQUFHLENBQUMsV0FBVyxFQUFFc0UsV0FBVyxDQUFDL0QsaUJBQWlCLEVBQUU7SUFBQ3dFLFdBQVcsRUFBRTtFQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzVGakYsTUFBTSxDQUFDQyxlQUFlLENBQUNDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQ1MsR0FBRyxFQUFDQyxHQUFHLEtBQUc7SUFDL0NBLEdBQUcsQ0FBQ3pDLEdBQUcsQ0FBQyxFQUFFLENBQUM7RUFDZixDQUFDLENBQUM7RUFFRjZCLE1BQU0sQ0FBQ0MsZUFBZSxDQUFDQyxHQUFHLENBQUN1RSxVQUFVLENBQUNTLEdBQUcsQ0FBQztJQUFDQyxLQUFLLEVBQUUsT0FBTztJQUFFbk4sSUFBSSxFQUFFO0VBQTBCLENBQUMsQ0FBQyxDQUFDO0VBQzlGZ0ksTUFBTSxDQUFDQyxlQUFlLENBQUNDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsVUFBVVMsR0FBRyxFQUFFQyxHQUFHLEVBQUU7SUFDcEQsSUFBSW1FLFFBQVEsRUFBRTtJQUNkLE1BQU1LLFVBQVUsR0FBRzNFLGlCQUFpQixHQUFHbUIsa0JBQWtCLENBQUNqQixHQUFHLENBQUMzTCxHQUFHLENBQUMsQ0FBQzZDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO0lBQ3ZGLE1BQU13TixHQUFHLEdBQUdELFVBQVUsQ0FBQ0UsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQ2YsS0FBSyxDQUFDZ0IsS0FBSyxDQUFDLElBQUksRUFBRUYsR0FBRyxDQUFDO0lBRXRCLElBQUlHLE9BQU8sR0FBR2QsaUJBQWlCLENBQUNVLFVBQVUsQ0FBQztJQUMzQ0ksT0FBTyxDQUFDaEQsS0FBSyxDQUFDN0IsR0FBRyxDQUFDOEUsSUFBSSxDQUFDO0lBQ3ZCRCxPQUFPLENBQUNySCxHQUFHLENBQUMsQ0FBQztJQUNieUMsR0FBRyxDQUFDUSxTQUFTLENBQUMsY0FBYyxFQUFFLDBCQUEwQixDQUFDO0lBQ3pEUixHQUFHLENBQUNRLFNBQVMsQ0FBQyw2QkFBNkIsRUFBRSxHQUFHLENBQUM7SUFDakRSLEdBQUcsQ0FBQ1EsU0FBUyxDQUFDLDhCQUE4QixFQUFFLGdEQUFnRCxDQUFDO0lBQy9GUixHQUFHLENBQUN6QyxHQUFHLENBQUMsUUFBUSxHQUFHaUgsVUFBVSxDQUFDO0VBQ2xDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQ2pDRixJQUFJaFIsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUltUSxpQkFBaUIsRUFBQ0MsU0FBUyxFQUFDQyxXQUFXLEVBQUM5RSxRQUFRLEVBQUMrRSxZQUFZLEVBQUNyQixVQUFVO0FBQUNuUCxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ29RLGlCQUFpQkEsQ0FBQ25RLENBQUMsRUFBQztJQUFDbVEsaUJBQWlCLEdBQUNuUSxDQUFDO0VBQUEsQ0FBQztFQUFDb1EsU0FBU0EsQ0FBQ3BRLENBQUMsRUFBQztJQUFDb1EsU0FBUyxHQUFDcFEsQ0FBQztFQUFBLENBQUM7RUFBQ3FRLFdBQVdBLENBQUNyUSxDQUFDLEVBQUM7SUFBQ3FRLFdBQVcsR0FBQ3JRLENBQUM7RUFBQSxDQUFDO0VBQUN1TCxRQUFRQSxDQUFDdkwsQ0FBQyxFQUFDO0lBQUN1TCxRQUFRLEdBQUN2TCxDQUFDO0VBQUEsQ0FBQztFQUFDc1EsWUFBWUEsQ0FBQ3RRLENBQUMsRUFBQztJQUFDc1EsWUFBWSxHQUFDdFEsQ0FBQztFQUFBLENBQUM7RUFBQ2lQLFVBQVVBLENBQUNqUCxDQUFDLEVBQUM7SUFBQ2lQLFVBQVUsR0FBQ2pQLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJc0wsUUFBUSxFQUFDaUYsT0FBTyxFQUFDOUgsSUFBSTtBQUFDM0ksTUFBTSxDQUFDQyxJQUFJLENBQUMsTUFBTSxFQUFDO0VBQUN1TCxRQUFRQSxDQUFDdEwsQ0FBQyxFQUFDO0lBQUNzTCxRQUFRLEdBQUN0TCxDQUFDO0VBQUEsQ0FBQztFQUFDdVEsT0FBT0EsQ0FBQ3ZRLENBQUMsRUFBQztJQUFDdVEsT0FBTyxHQUFDdlEsQ0FBQztFQUFBLENBQUM7RUFBQ3lJLElBQUlBLENBQUN6SSxDQUFDLEVBQUM7SUFBQ3lJLElBQUksR0FBQ3pJLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJUyxHQUFHO0FBQUNYLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLEtBQUssRUFBQztFQUFDZSxPQUFPQSxDQUFDZCxDQUFDLEVBQUM7SUFBQ1MsR0FBRyxHQUFDVCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSW1SLFdBQVc7QUFBQ3JSLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDZSxPQUFPQSxDQUFDZCxDQUFDLEVBQUM7SUFBQ21SLFdBQVcsR0FBQ25SLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJc1AsTUFBTTtBQUFDeFAsTUFBTSxDQUFDQyxJQUFJLENBQUMsVUFBVSxFQUFDO0VBQUNlLE9BQU9BLENBQUNkLENBQUMsRUFBQztJQUFDc1AsTUFBTSxHQUFDdFAsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQU0vbkIsTUFBTXdRLFFBQVEsR0FBRzNRLE1BQU0sQ0FBQzBQLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLFdBQVcsQ0FBQztBQUUzRCxJQUFJO0VBQUM0QjtBQUFPLENBQUMsR0FBRzlCLE1BQU07QUFFdEJ6UCxNQUFNLENBQUN3UixPQUFPLENBQUM7RUFDWCxnQkFBZ0JDLENBQUEsRUFBRztJQUNmLE1BQU14UCxJQUFJLEdBQUd3TixNQUFNLENBQUNJLGFBQWE7SUFDakMsTUFBTTZCLE1BQU0sR0FBRyxJQUFJSixXQUFXLENBQUQsQ0FBQztJQUM5QkksTUFBTSxDQUFDQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQVM7SUFBQSxDQUN0QkQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFLO0lBQ3ZCO0lBQ0E7SUFBQSxDQUNDRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBRztJQUMxQixJQUFJQyxNQUFNLEdBQUdILE1BQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7SUFDNUJILE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFTO0lBQUEsQ0FDdkJELE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBSztJQUN2QjtJQUNBO0lBQUEsQ0FDQ0UsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUc7SUFDNUJDLE1BQU0sR0FBR0EsTUFBTSxDQUFDQyxNQUFNLENBQUNKLE1BQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztJQUN2Q0gsTUFBTSxDQUFDQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQVM7SUFBQSxDQUN2QkQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFLO0lBQ3ZCO0lBQ0E7SUFBQSxDQUNDRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBRztJQUMxQkMsTUFBTSxHQUFHQSxNQUFNLENBQUNDLE1BQU0sQ0FBQ0osTUFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDSCxNQUFNLENBQUNDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBUztJQUFBLENBQ3ZCRCxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUs7SUFDdkI7SUFDQTtJQUFBLENBQ0NFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFHO0lBQzFCQyxNQUFNLEdBQUdBLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDSixNQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDdkNILE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFTO0lBQUEsQ0FDdkJELE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBSztJQUN2QjtJQUNBO0lBQUEsQ0FDQ0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUc7SUFDMUJDLE1BQU0sR0FBR0EsTUFBTSxDQUFDQyxNQUFNLENBQUNKLE1BQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztJQUN2Q0EsTUFBTSxHQUFHQSxNQUFNLENBQUN4TixHQUFHLENBQUM4RSxDQUFDLElBQUksR0FBRyxHQUFHQSxDQUFDLENBQUM7SUFDakNsSCxJQUFJLENBQUNxTCxPQUFPLENBQUNKLEdBQUcsSUFBSTtNQUNoQkEsR0FBRyxDQUFDRyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDeUUsRUFBRSxFQUFFak4sQ0FBQyxLQUFLO1FBQzNCLElBQUksQ0FBQ2lOLEVBQUUsQ0FBQ3BNLEtBQUssRUFBRTtVQUNYb00sRUFBRSxDQUFDcE0sS0FBSyxHQUFHa00sTUFBTSxDQUFDL00sQ0FBQyxDQUFDO1FBQ3hCO01BQ0osQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDO0lBQ0YsT0FBTzdDLElBQUk7RUFDZixDQUFDO0VBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0ksUUFBUStQLENBQUNyRixNQUFNLEVBQUVzRixTQUFTLEVBQUVDLFVBQVUsRUFBRTtJQUNwQyxNQUFNQyxXQUFXLEdBQUdDLE1BQU0sSUFBSTdCLFNBQVMsQ0FBQzZCLE1BQU0sQ0FBQyxDQUFDRCxXQUFXLENBQUMsQ0FBQztJQUM3RCxNQUFNRSxPQUFPLEdBQUdELE1BQU0sSUFBSTtNQUN0QixNQUFNRSxJQUFJLEdBQUcvQixTQUFTLENBQUM2QixNQUFNLENBQUM7TUFDOUIsT0FBTyxDQUFDRSxJQUFJLENBQUNDLE1BQU0sQ0FBQyxDQUFDLElBQUlELElBQUksQ0FBQ0UsY0FBYyxDQUFDLENBQUMsTUFFdEM5QixPQUFPLENBQUMwQixNQUFNLENBQUMsQ0FBQ0ssV0FBVyxDQUFDLENBQUMsSUFBSSxNQUFNLElBQ3ZDL0IsT0FBTyxDQUFDMEIsTUFBTSxDQUFDLENBQUNLLFdBQVcsQ0FBQyxDQUFDLElBQUksT0FBTyxJQUN4Qy9CLE9BQU8sQ0FBQzBCLE1BQU0sQ0FBQyxDQUFDSyxXQUFXLENBQUMsQ0FBQyxJQUFJLE1BQU0sSUFDdkMvQixPQUFPLENBQUMwQixNQUFNLENBQUMsQ0FBQ0ssV0FBVyxDQUFDLENBQUMsSUFBSSxNQUFNLElBQ3ZDL0IsT0FBTyxDQUFDMEIsTUFBTSxDQUFDLENBQUNLLFdBQVcsQ0FBQyxDQUFDLElBQUksTUFBTSxDQUMxQztJQUNULENBQUM7SUFDRCxNQUFNQyxjQUFjLEdBQUdOLE1BQU0sSUFDekI1QixXQUFXLENBQUM0QixNQUFNLENBQUMsQ0FBQy9OLEdBQUcsQ0FBQ3FFLElBQUksSUFBSUUsSUFBSSxDQUFDd0osTUFBTSxFQUFFMUosSUFBSSxDQUFDLENBQUMsQ0FBQ2lLLE1BQU0sQ0FBQ1IsV0FBVyxDQUFDLENBQUM5TixHQUFHLENBQUN1TyxDQUFDLElBQUluSCxRQUFRLENBQUNtSCxDQUFDLENBQUMsQ0FBQztJQUVqRyxNQUFNQyxTQUFTLEdBQUdULE1BQU0sSUFDcEI1QixXQUFXLENBQUM0QixNQUFNLENBQUMsQ0FBQy9OLEdBQUcsQ0FBQ3FFLElBQUksSUFBSUUsSUFBSSxDQUFDd0osTUFBTSxFQUFFMUosSUFBSSxDQUFDLENBQUMsQ0FBQ2lLLE1BQU0sQ0FBQ04sT0FBTyxDQUFDO0lBRXZFLE1BQU1TLFlBQVksR0FBR0MsSUFBSSxJQUFJO01BQ3pCLE9BQU87UUFDSHJLLElBQUksRUFBRStDLFFBQVEsQ0FBQ3NILElBQUksQ0FBQztRQUNwQkMsT0FBTyxFQUFFLFFBQVEsR0FBR0Msa0JBQWtCLENBQUNDLFdBQVcsR0FBR3pILFFBQVEsQ0FBQ3NILElBQUksQ0FBQyxDQUFDO1FBQ3BFblMsR0FBRyxFQUFFLENBQUNzUyxXQUFXLEdBQUcsR0FBRyxHQUFHQSxXQUFXLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBR3pILFFBQVEsQ0FBQ3NILElBQUk7TUFDcEUsQ0FBQztJQUNMLENBQUM7SUFFRCxNQUFNSSxhQUFhLEdBQUlKLElBQUksSUFBSztNQUM1QixPQUFPO1FBQ0hySyxJQUFJLEVBQUUrQyxRQUFRLENBQUNzSCxJQUFJLENBQUM7UUFDcEJuUyxHQUFHLEVBQUUsV0FBQWtSLE1BQUEsQ0FBV0csU0FBUyxPQUFBSCxNQUFBLENBQUlJLFVBQVUsU0FBTWUsa0JBQWtCLENBQUNDLFdBQVcsR0FBR0gsSUFBSTtNQUN0RixDQUFDO0lBQ0wsQ0FBQztJQUVEZCxTQUFTLEdBQUc3TixRQUFRLENBQUM2TixTQUFTLENBQUM7SUFDL0JDLFVBQVUsR0FBRzlOLFFBQVEsQ0FBQzhOLFVBQVUsQ0FBQztJQUNqQyxNQUFNZ0IsV0FBVyxHQUFHdkcsTUFBTSxHQUFHYSxrQkFBa0IsQ0FBQ2IsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUc7SUFDbkUsTUFBTXlHLElBQUksR0FBR3hLLElBQUksQ0FBQzZHLE1BQU0sQ0FBQ3JELFlBQVksRUFBRzhHLFdBQVcsR0FBR0EsV0FBVyxHQUFHLEVBQUcsQ0FBQztJQUV4RSxNQUFNRyxRQUFRLEdBQUdqRSxVQUFVLENBQUNnRSxJQUFJLENBQUM7SUFFakMsSUFBSUMsUUFBUSxJQUFJLENBQUNsQixXQUFXLENBQUNpQixJQUFJLENBQUMsRUFBRTtNQUNoQyxPQUFPO1FBQUNsRCxLQUFLLEVBQUVrRCxJQUFJLEdBQUc7TUFBbUYsQ0FBQztJQUM5RztJQUNBLElBQUksQ0FBQ0MsUUFBUSxFQUFFO01BQ1gsT0FBTztRQUFDbkQsS0FBSyxFQUFFa0QsSUFBSSxHQUFHO01BQWtFLENBQUM7SUFDN0Y7SUFFQSxNQUFNRSxJQUFJLEdBQUdaLGNBQWMsQ0FBQ1UsSUFBSSxDQUFDO0lBQ2pDLE1BQU1wQixNQUFNLEdBQUdhLFNBQVMsQ0FBQ08sSUFBSSxDQUFDO0lBQzlCLE1BQU01RyxHQUFHLEdBQUc7TUFDUitHLE9BQU8sRUFBRUQsSUFBSSxDQUFDalAsR0FBRyxDQUFDOE8sYUFBYSxDQUFDO01BQ2hDbkIsTUFBTSxFQUFFQSxNQUFNLENBQUMzTixHQUFHLENBQUN5TyxZQUFZLENBQUMsQ0FBQ3pMLEtBQUssQ0FBQzRLLFNBQVMsR0FBR0MsVUFBVSxFQUFFRCxTQUFTLEdBQUdDLFVBQVUsR0FBR0EsVUFBVSxDQUFDO01BQ25Hc0IsV0FBVyxFQUFFeEIsTUFBTSxDQUFDelA7SUFDeEIsQ0FBQztJQUVELElBQUkwUCxTQUFTLEdBQUdDLFVBQVUsR0FBR0EsVUFBVSxHQUFHRixNQUFNLENBQUN6UCxNQUFNLEVBQUU7TUFDckRpSyxHQUFHLENBQUNpSCxRQUFRLEdBQUcsV0FBQTNCLE1BQUEsQ0FBV0csU0FBUyxHQUFHLENBQUMsT0FBQUgsTUFBQSxDQUFJSSxVQUFVLFVBQU92RixNQUFNLEdBQUdzRyxrQkFBa0IsQ0FBQ3RHLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUN6RztJQUNBLElBQUlzRixTQUFTLEdBQUcsQ0FBQyxFQUFFO01BQ2Z6RixHQUFHLENBQUNrSCxZQUFZLEdBQUcsV0FBQTVCLE1BQUEsQ0FBV0csU0FBUyxHQUFHLENBQUMsT0FBQUgsTUFBQSxDQUFJSSxVQUFVLFVBQU92RixNQUFNLEdBQUdzRyxrQkFBa0IsQ0FBQ3RHLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUM3RztJQUVBLE9BQU9ILEdBQUc7RUFDZCxDQUFDO0VBRUQsVUFBVW1ILENBQUNDLE1BQU0sRUFBRTtJQUNmLElBQUlqRCxRQUFRLEVBQUU7SUFDZCxNQUFNa0QsS0FBSyxHQUFHalQsR0FBRyxDQUFDc0IsS0FBSyxDQUFDMFIsTUFBTSxDQUFDaFQsR0FBRyxDQUFDO0lBQ25DLElBQUltUyxJQUFJLEdBQUd2RixrQkFBa0IsQ0FBQ3FHLEtBQUssQ0FBQ0MsUUFBUSxDQUFDO0lBQzdDRixNQUFNLENBQUNqSCxNQUFNLEdBQUdvRyxJQUFJLENBQUNnQixTQUFTLENBQUMsQ0FBQyxFQUFFaEIsSUFBSSxDQUFDaUIsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3hESixNQUFNLENBQUM3UyxJQUFJLEdBQUdnUyxJQUFJLENBQUNnQixTQUFTLENBQUNoQixJQUFJLENBQUNpQixXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZESixNQUFNLENBQUM5RyxZQUFZLEdBQUcsSUFBSW1ILElBQUksQ0FBQyxDQUFDO0lBQ2hDLElBQUksQ0FBQ0wsTUFBTSxDQUFDL0csYUFBYSxFQUNyQitHLE1BQU0sQ0FBQy9HLGFBQWEsR0FBRyxJQUFJb0gsSUFBSSxDQUFDLENBQUM7SUFDckMsSUFBSUwsTUFBTSxDQUFDaEgsSUFBSSxFQUFFO01BQ2JyTSxRQUFRLENBQUMyVCxNQUFNLENBQUM7UUFBQ0MsR0FBRyxFQUFFO01BQU0sQ0FBQyxFQUFFO1FBQUNDLFNBQVMsRUFBRTtVQUFDQyxLQUFLLEVBQUU7WUFBQ0MsS0FBSyxFQUFFVixNQUFNLENBQUNoSDtVQUFJO1FBQUM7TUFBQyxDQUFDLENBQUM7SUFDOUU7SUFDQXhNLFVBQVUsQ0FBQzhULE1BQU0sQ0FBQztNQUFDdFQsR0FBRyxFQUFFZ1QsTUFBTSxDQUFDaFQ7SUFBRyxDQUFDLEVBQUVnVCxNQUFNLENBQUM7RUFDaEQ7QUFDSixDQUFDLENBQUMsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5Tc2VTYW1wbGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJTc2VTYW1wbGVzXCIpO1xuU3NlUHJvcHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcIlNzZVByb3BzXCIpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgTWV0ZW9yLnB1Ymxpc2goXCJzc2UtZGF0YS1kZXNjcmlwdG9yXCIsIGZ1bmN0aW9uIChpbWFnZVVybCkge1xuICAgICAgICByZXR1cm4gU3NlU2FtcGxlcy5maW5kKHt1cmw6IGltYWdlVXJsfSk7XG4gICAgfSk7XG5cbiAgICBNZXRlb3IucHVibGlzaChcInNzZS1sYWJlbGVkLWltYWdlc1wiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBTc2VTYW1wbGVzLmZpbmQoXG4gICAgICAgICAgICB7JHdoZXJlOiAndGhpcy5vYmplY3RzICYmIHRoaXMub2JqZWN0cy5sZW5ndGg+MCd9LFxuICAgICAgICAgICAge2ZpZWxkczoge2ZpbGU6IDEsIHVybDogMX19LFxuICAgICAgICApO1xuICAgIH0pO1xuXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3NzZS1wcm9wcycsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIFNzZVByb3BzLmZpbmQoe30pO1xuICAgIH0pO1xufVxuXG4iLCIvLyBCYXNlZCBvbiB0aHJlZS5qcyBQQ0RMb2FkZXIgY2xhc3MgKG9ubHkgc3VwcG9ydCBBU0NJSSBQQ0QgZmlsZXMpXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTc2VQQ0RMb2FkZXIge1xuICAgIGNvbnN0cnVjdG9yKFRIUkVFKSB7XG4gICAgICAgIFRIUkVFLlBDRExvYWRlciA9IGZ1bmN0aW9uIChzZXJ2ZXJNb2RlKSB7XG4gICAgICAgICAgICB0aGlzLnNlcnZlck1vZGUgPSBzZXJ2ZXJNb2RlO1xuICAgICAgICB9O1xuXG4gICAgICAgIFRIUkVFLlBDRExvYWRlci5wcm90b3R5cGUgPSB7XG4gICAgICAgICAgICBjb25zdHJ1Y3RvcjogVEhSRUUuUENETG9hZGVyLFxuICAgICAgICAgICAgbG9hZDogZnVuY3Rpb24gKHVybCwgb25Mb2FkLCBvblByb2dyZXNzLCBvbkVycm9yKSB7XG4gICAgICAgICAgICAgICAgdmFyIHNjb3BlID0gdGhpcztcbiAgICAgICAgICAgICAgICB2YXIgbG9hZGVyID0gbmV3IFRIUkVFLkZpbGVMb2FkZXIoc2NvcGUubWFuYWdlcik7XG4gICAgICAgICAgICAgICAgbG9hZGVyLnNldFJlc3BvbnNlVHlwZSgnYXJyYXlidWZmZXInKTtcbiAgICAgICAgICAgICAgICBsb2FkZXIubG9hZCh1cmwsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIG9uTG9hZChzY29wZS5wYXJzZShkYXRhLCB1cmwpKTtcbiAgICAgICAgICAgICAgICB9LCBvblByb2dyZXNzLCBvbkVycm9yKTtcblxuICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgcGFyc2U6IGZ1bmN0aW9uIChkYXRhLCB1cmwpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBkZWNvbXByZXNzTFpGKCBpbkRhdGEsIG91dExlbmd0aCApIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZnJvbSBodHRwczovL2dpdGxhYi5jb20vdGFrZXR3by90aHJlZS1wY2QtbG9hZGVyL2Jsb2IvbWFzdGVyL2RlY29tcHJlc3MtbHpmLmpzXG4gICAgICAgICAgICAgICAgICAgIHZhciBpbkxlbmd0aCA9IGluRGF0YS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvdXREYXRhID0gbmV3IFVpbnQ4QXJyYXkoIG91dExlbmd0aCApO1xuICAgICAgICAgICAgICAgICAgICB2YXIgaW5QdHIgPSAwO1xuICAgICAgICAgICAgICAgICAgICB2YXIgb3V0UHRyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN0cmw7XG4gICAgICAgICAgICAgICAgICAgIHZhciBsZW47XG4gICAgICAgICAgICAgICAgICAgIHZhciByZWY7XG4gICAgICAgICAgICAgICAgICAgIGRvIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwgPSBpbkRhdGFbIGluUHRyICsrIF07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIGN0cmwgPCAoIDEgPDwgNSApICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwgKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCBvdXRQdHIgKyBjdHJsID4gb3V0TGVuZ3RoICkgdGhyb3cgbmV3IEVycm9yKCAnT3V0cHV0IGJ1ZmZlciBpcyBub3QgbGFyZ2UgZW5vdWdoJyApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICggaW5QdHIgKyBjdHJsID4gaW5MZW5ndGggKSB0aHJvdyBuZXcgRXJyb3IoICdJbnZhbGlkIGNvbXByZXNzZWQgZGF0YScgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkbyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dERhdGFbIG91dFB0ciArKyBdID0gaW5EYXRhWyBpblB0ciArKyBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gd2hpbGUgKCAtLSBjdHJsICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlbiA9IGN0cmwgPj4gNTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWYgPSBvdXRQdHIgLSAoICggY3RybCAmIDB4MWYgKSA8PCA4ICkgLSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICggaW5QdHIgPj0gaW5MZW5ndGggKSB0aHJvdyBuZXcgRXJyb3IoICdJbnZhbGlkIGNvbXByZXNzZWQgZGF0YScgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIGxlbiA9PT0gNyApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVuICs9IGluRGF0YVsgaW5QdHIgKysgXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCBpblB0ciA+PSBpbkxlbmd0aCApIHRocm93IG5ldyBFcnJvciggJ0ludmFsaWQgY29tcHJlc3NlZCBkYXRhJyApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWYgLT0gaW5EYXRhWyBpblB0ciArKyBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICggb3V0UHRyICsgbGVuICsgMiA+IG91dExlbmd0aCApIHRocm93IG5ldyBFcnJvciggJ091dHB1dCBidWZmZXIgaXMgbm90IGxhcmdlIGVub3VnaCcgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIHJlZiA8IDAgKSB0aHJvdyBuZXcgRXJyb3IoICdJbnZhbGlkIGNvbXByZXNzZWQgZGF0YScgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIHJlZiA+PSBvdXRQdHIgKSB0aHJvdyBuZXcgRXJyb3IoICdJbnZhbGlkIGNvbXByZXNzZWQgZGF0YScgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkbyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dERhdGFbIG91dFB0ciArKyBdID0gb3V0RGF0YVsgcmVmICsrIF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSB3aGlsZSAoIC0tIGxlbiArIDIgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSB3aGlsZSAoIGluUHRyIDwgaW5MZW5ndGggKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG91dERhdGE7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gcGFyc2VIZWFkZXIoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgUENEaGVhZGVyID0ge307XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQxID0gZGF0YS5zZWFyY2goL1tcXHJcXG5dREFUQVxccyhcXFMqKVxccy9pKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdDIgPSAvW1xcclxcbl1EQVRBXFxzKFxcUyopXFxzL2kuZXhlYyhkYXRhLnN1YnN0cihyZXN1bHQxIC0gMSkpO1xuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIuZGF0YSA9IHJlc3VsdDJbMV07XG4gICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci5oZWFkZXJMZW4gPSByZXN1bHQyWzBdLmxlbmd0aCArIHJlc3VsdDE7XG4gICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci5zdHIgPSBkYXRhLnN1YnN0cigwLCBQQ0RoZWFkZXIuaGVhZGVyTGVuKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyByZW1vdmUgY29tbWVudHNcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnN0ciA9IFBDRGhlYWRlci5zdHIucmVwbGFjZSgvXFwjLiovZ2ksICcnKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBwYXJzZVxuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIudmVyc2lvbiA9IC9WRVJTSU9OICguKikvaS5leGVjKFBDRGhlYWRlci5zdHIpO1xuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIuZmllbGRzID0gL0ZJRUxEUyAoLiopL2kuZXhlYyhQQ0RoZWFkZXIuc3RyKTtcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnNpemUgPSAvU0laRSAoLiopL2kuZXhlYyhQQ0RoZWFkZXIuc3RyKTtcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnR5cGUgPSAvVFlQRSAoLiopL2kuZXhlYyhQQ0RoZWFkZXIuc3RyKTtcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLmNvdW50ID0gL0NPVU5UICguKikvaS5leGVjKFBDRGhlYWRlci5zdHIpO1xuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIud2lkdGggPSAvV0lEVEggKC4qKS9pLmV4ZWMoUENEaGVhZGVyLnN0cik7XG4gICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci5oZWlnaHQgPSAvSEVJR0hUICguKikvaS5leGVjKFBDRGhlYWRlci5zdHIpO1xuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIudmlld3BvaW50ID0gL1ZJRVdQT0lOVCAoLiopL2kuZXhlYyhQQ0RoZWFkZXIuc3RyKTtcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnBvaW50cyA9IC9QT0lOVFMgKC4qKS9pLmV4ZWMoUENEaGVhZGVyLnN0cik7XG4gICAgICAgICAgICAgICAgICAgIC8vIGV2YWx1YXRlXG4gICAgICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIudmVyc2lvbiAhPT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci52ZXJzaW9uID0gcGFyc2VGbG9hdChQQ0RoZWFkZXIudmVyc2lvblsxXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIuZmllbGRzICE9PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLmZpZWxkcyA9IFBDRGhlYWRlci5maWVsZHNbMV0uc3BsaXQoJyAnKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFBDRGhlYWRlci50eXBlICE9PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnR5cGUgPSBQQ0RoZWFkZXIudHlwZVsxXS5zcGxpdCgnICcpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoUENEaGVhZGVyLndpZHRoICE9PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLndpZHRoID0gcGFyc2VJbnQoUENEaGVhZGVyLndpZHRoWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFBDRGhlYWRlci5oZWlnaHQgIT09IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIuaGVpZ2h0ID0gcGFyc2VJbnQoUENEaGVhZGVyLmhlaWdodFsxXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIudmlld3BvaW50ICE9PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnZpZXdwb2ludCA9IFBDRGhlYWRlci52aWV3cG9pbnRbMV07XG4gICAgICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIucG9pbnRzICE9PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnBvaW50cyA9IHBhcnNlSW50KFBDRGhlYWRlci5wb2ludHNbMV0sIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFBDRGhlYWRlci5wb2ludHMgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIucG9pbnRzID0gUENEaGVhZGVyLndpZHRoICogUENEaGVhZGVyLmhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFBDRGhlYWRlci5zaXplICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIuc2l6ZSA9IFBDRGhlYWRlci5zaXplWzFdLnNwbGl0KCcgJykubWFwKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KHgsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3BsaXQgPSBQQ0RoZWFkZXIudmlld3BvaW50LnNwbGl0KFwiIFwiKTtcbiAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnZpZXdwb2ludCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR4OiBzcGxpdFswXSwgdHk6IHNwbGl0WzFdLCB0ejogc3BsaXRbMl0sXG4gICAgICAgICAgICAgICAgICAgICAgICBxdzogc3BsaXRbM10sIHF4OiBzcGxpdFs0XSwgcXk6IHNwbGl0WzVdLCBxejogc3BsaXRbNl1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFBDRGhlYWRlci5jb3VudCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLmNvdW50ID0gUENEaGVhZGVyLmNvdW50WzFdLnNwbGl0KCcgJykubWFwKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KHgsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLmNvdW50ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbCA9IFBDRGhlYWRlci5maWVsZHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLmNvdW50LnB1c2goMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIub2Zmc2V0ID0ge307XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHNpemVTdW0gPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBsID0gUENEaGVhZGVyLmZpZWxkcy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIuZGF0YSA9PT0gJ2FzY2lpJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci5vZmZzZXRbUENEaGVhZGVyLmZpZWxkc1tpXV0gPSBpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQQ0RoZWFkZXIub2Zmc2V0W1BDRGhlYWRlci5maWVsZHNbaV1dID0gc2l6ZVN1bTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplU3VtICs9IFBDRGhlYWRlci5zaXplW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci5yb3dTaXplID0gc2l6ZVN1bTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFBDRGhlYWRlcjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB2YXIgdGV4dERhdGEgPSB0aGlzLnNlcnZlck1vZGUgPyAoQnVmZmVyLmZyb20oZGF0YSkpLnRvU3RyaW5nKCkgOiBUSFJFRS5Mb2FkZXJVdGlscy5kZWNvZGVUZXh0KGRhdGEpO1xuXG4gICAgICAgICAgICAgICAgLy8gcGFyc2UgaGVhZGVyIChhbHdheXMgYXNjaWkgZm9ybWF0KVxuICAgICAgICAgICAgICAgIHZhciBQQ0RoZWFkZXIgPSBwYXJzZUhlYWRlcih0ZXh0RGF0YSk7XG5cbiAgICAgICAgICAgICAgICAvLyBwYXJzZSBkYXRhXG5cbiAgICAgICAgICAgICAgICB2YXIgcG9zaXRpb24gPSBbXTtcbiAgICAgICAgICAgICAgICB2YXIgY29sb3IgPSBbXTtcbiAgICAgICAgICAgICAgICB2YXIgbGFiZWwgPSBbXTtcbiAgICAgICAgICAgICAgICB2YXIgcGF5bG9hZCA9IFtdO1xuICAgICAgICAgICAgICAgIHZhciByZ2IgPSBbXTtcblxuICAgICAgICAgICAgICAgIGlmIChQQ0RoZWFkZXIuZGF0YSA9PT0gJ2FzY2lpJykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBtZXRhID0gUENEaGVhZGVyO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBjYW1Qb3NpdGlvbiA9IG5ldyBUSFJFRS5WZWN0b3IzKHBhcnNlRmxvYXQobWV0YS52aWV3cG9pbnQudHgpLCBwYXJzZUZsb2F0KG1ldGEudmlld3BvaW50LnR5KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQobWV0YS52aWV3cG9pbnQudHopKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNhbVF1YXRlcm5pb24gPSBuZXcgVEhSRUUuUXVhdGVybmlvbihtZXRhLnZpZXdwb2ludC5xeCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGEudmlld3BvaW50LnF5LCBtZXRhLnZpZXdwb2ludC5xeiwgbWV0YS52aWV3cG9pbnQucXcpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBvZmZzZXQgPSBQQ0RoZWFkZXIub2Zmc2V0O1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBwY2REYXRhID0gdGV4dERhdGEuc3Vic3RyKFBDRGhlYWRlci5oZWFkZXJMZW4pO1xuICAgICAgICAgICAgICAgICAgICB2YXIgbGluZXMgPSBwY2REYXRhLnNwbGl0KCdcXG4nKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHB0LCBpdGVtO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IGxpbmVzLmxlbmd0aCAtIDE7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKGxpbmVzW2ldID09IFwiXCIpe2NvbnRpbnVlO30gIC8vIFNvbWV0aW1lcyBlbXB0eSBsaW5lcyBhcmUgaW5zZXJ0ZWQuLi5cblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGxpbmUgPSBsaW5lc1tpXS5zcGxpdCgnICcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF5bG9hZC5wdXNoKGl0ZW0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBwdCA9IG5ldyBUSFJFRS5WZWN0b3IzKHBhcnNlRmxvYXQobGluZVtvZmZzZXQueF0pLCBwYXJzZUZsb2F0KGxpbmVbb2Zmc2V0LnldKSwgcGFyc2VGbG9hdChsaW5lW29mZnNldC56XSkpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuc2VydmVyTW9kZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0ID0gcHQuc3ViKGNhbVBvc2l0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdC5hcHBseVF1YXRlcm5pb24oY2FtUXVhdGVybmlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ueCA9IHB0Lng7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbi5wdXNoKHB0LngpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnkgPSBwdC55O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24ucHVzaChwdC55KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ueiA9IHB0Lno7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbi5wdXNoKHB0LnopO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAob2Zmc2V0LmxhYmVsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGFzc0luZGV4ID0gcGFyc2VJbnQobGluZVtvZmZzZXQubGFiZWxdKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uY2xhc3NJbmRleCA9IGNsYXNzSW5kZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWwucHVzaChjbGFzc0luZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5jbGFzc0luZGV4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbC5wdXNoKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJbml0aWFsaXplIGNvbG9yc1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9mZnNldC5yZ2IgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNvbG9yUkdCID0gcGFyc2VJbnQobGluZVtvZmZzZXQucmdiXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHIgPSAoY29sb3JSR0IgPj4gMTYpICYgMHgwMDAwZmY7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGcgPSAoY29sb3JSR0IgPj4gOCkgJiAweDAwMDBmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYiA9IChjb2xvclJHQikgJiAweDAwMDBmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZ2IucHVzaChbciwgZywgYl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvci5wdXNoKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IucHVzaCgwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yLnB1c2goMCk7XG5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIGJpbmFyeS1jb21wcmVzc2VkXG4gICAgICAgICAgICAgICAgLy8gbm9ybWFsbHkgZGF0YSBpbiBQQ0QgZmlsZXMgYXJlIG9yZ2FuaXplZCBhcyBhcnJheSBvZiBzdHJ1Y3R1cmVzOiBYWVpSR0JYWVpSR0JcbiAgICAgICAgICAgICAgICAvLyBiaW5hcnkgY29tcHJlc3NlZCBQQ0QgZmlsZXMgb3JnYW5pemUgdGhlaXIgZGF0YSBhcyBzdHJ1Y3R1cmUgb2YgYXJyYXlzOiBYWFlZWlpSR0JSR0JcbiAgICAgICAgICAgICAgICAvLyB0aGF0IHJlcXVpcmVzIGEgdG90YWxseSBkaWZmZXJlbnQgcGFyc2luZyBhcHByb2FjaCBjb21wYXJlZCB0byBub24tY29tcHJlc3NlZCBkYXRhXG4gICAgICAgICAgICAgICAgaWYgKCBQQ0RoZWFkZXIuZGF0YSA9PT0gJ2JpbmFyeV9jb21wcmVzc2VkJyApIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRhdGF2aWV3ID0gbmV3IERhdGFWaWV3KCBkYXRhLnNsaWNlKCBQQ0RoZWFkZXIuaGVhZGVyTGVuLCBQQ0RoZWFkZXIuaGVhZGVyTGVuICsgOCApICk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjb21wcmVzc2VkU2l6ZSA9IGRhdGF2aWV3LmdldFVpbnQzMiggMCwgdHJ1ZSApO1xuICAgICAgICAgICAgICAgICAgICB2YXIgZGVjb21wcmVzc2VkU2l6ZSA9IGRhdGF2aWV3LmdldFVpbnQzMiggNCwgdHJ1ZSApO1xuICAgICAgICAgICAgICAgICAgICB2YXIgZGVjb21wcmVzc2VkID0gZGVjb21wcmVzc0xaRiggbmV3IFVpbnQ4QXJyYXkoIGRhdGEsIFBDRGhlYWRlci5oZWFkZXJMZW4gKyA4LCBjb21wcmVzc2VkU2l6ZSApLCBkZWNvbXByZXNzZWRTaXplICk7XG4gICAgICAgICAgICAgICAgICAgIGRhdGF2aWV3ID0gbmV3IERhdGFWaWV3KCBkZWNvbXByZXNzZWQuYnVmZmVyICk7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIG9mZnNldCA9IFBDRGhlYWRlci5vZmZzZXQ7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwdCwgaXRlbTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgY2FtUG9zaXRpb24gPSBuZXcgVEhSRUUuVmVjdG9yMyhwYXJzZUZsb2F0KFBDRGhlYWRlci52aWV3cG9pbnQudHgpLCBwYXJzZUZsb2F0KFBDRGhlYWRlci52aWV3cG9pbnQudHkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChQQ0RoZWFkZXIudmlld3BvaW50LnR6KSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBjYW1RdWF0ZXJuaW9uID0gbmV3IFRIUkVFLlF1YXRlcm5pb24oUENEaGVhZGVyLnZpZXdwb2ludC5xeCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFBDRGhlYWRlci52aWV3cG9pbnQucXksIFBDRGhlYWRlci52aWV3cG9pbnQucXosIFBDRGhlYWRlci52aWV3cG9pbnQucXcpO1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAoIHZhciBpID0gMDsgaSA8IFBDRGhlYWRlci5wb2ludHM7IGkgKysgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXlsb2FkLnB1c2goaXRlbSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHggPSBkYXRhdmlldy5nZXRGbG9hdDMyKCAoIFBDRGhlYWRlci5wb2ludHMgKiBvZmZzZXQueCApICsgUENEaGVhZGVyLnNpemVbIDAgXSAqIGksIHRydWUgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHkgPSBkYXRhdmlldy5nZXRGbG9hdDMyKCAoIFBDRGhlYWRlci5wb2ludHMgKiBvZmZzZXQueSApICsgUENEaGVhZGVyLnNpemVbIDEgXSAqIGksIHRydWUgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHogPSBkYXRhdmlldy5nZXRGbG9hdDMyKCAoIFBDRGhlYWRlci5wb2ludHMgKiBvZmZzZXQueiApICsgUENEaGVhZGVyLnNpemVbIDIgXSAqIGksIHRydWUgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgcHQgPSBuZXcgVEhSRUUuVmVjdG9yMyh4LCB5LCB6KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLnNlcnZlck1vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdCA9IHB0LnN1YihjYW1Qb3NpdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHQuYXBwbHlRdWF0ZXJuaW9uKGNhbVF1YXRlcm5pb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnggPSBwdC54O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24ucHVzaChwdC54KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS55ID0gcHQueTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uLnB1c2gocHQueSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnogPSBwdC56O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24ucHVzaChwdC56KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCBvZmZzZXQubGFiZWwgIT09IHVuZGVmaW5lZCApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGFzc0luZGV4ID0gZGF0YXZpZXcuZ2V0VWludDgoIFBDRGhlYWRlci5wb2ludHMgKiBvZmZzZXQubGFiZWwgKyBQQ0RoZWFkZXIuc2l6ZVsgMyBdICogaSApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uY2xhc3NJbmRleCA9IGNsYXNzSW5kZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWwucHVzaCggY2xhc3NJbmRleCApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmNsYXNzSW5kZXggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsLnB1c2goMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEluaXRpYWxpemUgY29sb3JzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAob2Zmc2V0LnJnYiAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY29sb3JSR0IgPSBkYXRhdmlldy5nZXRVaW50MzIocm93ICsgb2Zmc2V0LnJnYiwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHIgPSAoY29sb3JSR0IgPj4gMTYpICYgMHgwMDAwZmY7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGcgPSAoY29sb3JSR0IgPj4gOCkgJiAweDAwMDBmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYiA9IChjb2xvclJHQikgJiAweDAwMDBmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZ2IucHVzaChbciwgZywgYl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvci5wdXNoKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IucHVzaCgwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yLnB1c2goMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBiaW5hcnlcblxuICAgICAgICAgICAgICAgIGlmICggUENEaGVhZGVyLmRhdGEgPT09ICdiaW5hcnknICkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZGF0YXZpZXcgPSBuZXcgRGF0YVZpZXcoIGRhdGEsIFBDRGhlYWRlci5oZWFkZXJMZW4gKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9mZnNldCA9IFBDRGhlYWRlci5vZmZzZXQ7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwdCwgaXRlbTtcbiAgICAgICAgICAgICAgICAgICAgLy8gdGVzdC5wdXNoKG9mZnNldCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBjYW1Qb3NpdGlvbiA9IG5ldyBUSFJFRS5WZWN0b3IzKHBhcnNlRmxvYXQoUENEaGVhZGVyLnZpZXdwb2ludC50eCksIHBhcnNlRmxvYXQoUENEaGVhZGVyLnZpZXdwb2ludC50eSksXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KFBDRGhlYWRlci52aWV3cG9pbnQudHopKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNhbVF1YXRlcm5pb24gPSBuZXcgVEhSRUUuUXVhdGVybmlvbihQQ0RoZWFkZXIudmlld3BvaW50LnF4LFxuICAgICAgICAgICAgICAgICAgICAgICAgUENEaGVhZGVyLnZpZXdwb2ludC5xeSwgUENEaGVhZGVyLnZpZXdwb2ludC5xeiwgUENEaGVhZGVyLnZpZXdwb2ludC5xdyk7XG5cbiAgICAgICAgICAgICAgICAgICAgZm9yICggdmFyIGkgPSAwLCByb3cgPSAwOyBpIDwgUENEaGVhZGVyLnBvaW50czsgaSArKywgcm93ICs9IFBDRGhlYWRlci5yb3dTaXplICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF5bG9hZC5wdXNoKGl0ZW0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB4ID0gZGF0YXZpZXcuZ2V0RmxvYXQzMiggcm93ICsgb2Zmc2V0LngsIHRydWUgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHkgPSBkYXRhdmlldy5nZXRGbG9hdDMyKCByb3cgKyBvZmZzZXQueSwgdHJ1ZSApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeiA9IGRhdGF2aWV3LmdldEZsb2F0MzIoIHJvdyArIG9mZnNldC56LCB0cnVlICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHB0ID0gbmV3IFRIUkVFLlZlY3RvcjMoeCwgeSwgeik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5zZXJ2ZXJNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHQgPSBwdC5zdWIoY2FtUG9zaXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0LmFwcGx5UXVhdGVybmlvbihjYW1RdWF0ZXJuaW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS54ID0gcHQueDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uLnB1c2gocHQueCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ueSA9IHB0Lnk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbi5wdXNoKHB0LnkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS56ID0gcHQuejtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uLnB1c2gocHQueik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICggb2Zmc2V0LmxhYmVsICE9PSB1bmRlZmluZWQgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xhc3NJbmRleCA9IGRhdGF2aWV3LmdldFVpbnQ4KCByb3cgKyBvZmZzZXQubGFiZWwgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmNsYXNzSW5kZXggPSBjbGFzc0luZGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsLnB1c2goY2xhc3NJbmRleCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uY2xhc3NJbmRleCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWwucHVzaCgwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSBjb2xvcnNcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvZmZzZXQucmdiICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb2xvclJHQiA9IGRhdGF2aWV3LmdldFVpbnQzMihyb3cgKyBvZmZzZXQucmdiLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgciA9IChjb2xvclJHQiA+PiAxNikgJiAweDAwMDBmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZyA9IChjb2xvclJHQiA+PiA4KSAmIDB4MDAwMGZmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBiID0gKGNvbG9yUkdCKSAmIDB4MDAwMGZmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJnYi5wdXNoKFtyLCBnLCBiXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yLnB1c2goMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvci5wdXNoKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IucHVzaCgwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIGJ1aWxkIGdlb21ldHJ5XG5cbiAgICAgICAgICAgICAgICB2YXIgZ2VvbWV0cnkgPSBuZXcgVEhSRUUuQnVmZmVyR2VvbWV0cnkoKTtcblxuICAgICAgICAgICAgICAgIGlmIChwb3NpdGlvbi5sZW5ndGggPiAwKVxuICAgICAgICAgICAgICAgICAgICBnZW9tZXRyeS5zZXRBdHRyaWJ1dGUoJ3Bvc2l0aW9uJywgbmV3IFRIUkVFLkZsb2F0MzJCdWZmZXJBdHRyaWJ1dGUocG9zaXRpb24sIDMpKTtcbiAgICAgICAgICAgICAgICBpZiAobGFiZWwubGVuZ3RoID4gMClcbiAgICAgICAgICAgICAgICAgICAgZ2VvbWV0cnkuc2V0QXR0cmlidXRlKCdsYWJlbCcsIG5ldyBUSFJFRS5VaW50OEJ1ZmZlckF0dHJpYnV0ZShsYWJlbCwgMykpO1xuICAgICAgICAgICAgICAgIGlmIChjb2xvci5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbG9yQXR0ID0gbmV3IFRIUkVFLkZsb2F0MzJCdWZmZXJBdHRyaWJ1dGUoY29sb3IsIDMpO1xuICAgICAgICAgICAgICAgICAgICBnZW9tZXRyeS5zZXRBdHRyaWJ1dGUoJ2NvbG9yJywgY29sb3JBdHQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGdlb21ldHJ5LmNvbXB1dGVCb3VuZGluZ1NwaGVyZSgpO1xuXG4gICAgICAgICAgICAgICAgdmFyIG1hdGVyaWFsID0gbmV3IFRIUkVFLlBvaW50c01hdGVyaWFsKHtzaXplOiAyLCBjb2xvcjogMHhFOUE5NkZ9KTtcbiAgICAgICAgICAgICAgICBtYXRlcmlhbC5zaXplQXR0ZW51YXRpb24gPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIC8vIGJ1aWxkIG1lc2hcbiAgICAgICAgICAgICAgICB2YXIgbWVzaCA9IG5ldyBUSFJFRS5Qb2ludHMoZ2VvbWV0cnksIG1hdGVyaWFsKTtcbiAgICAgICAgICAgICAgICB2YXIgbmFtZSA9IHVybC5zcGxpdCgnJykucmV2ZXJzZSgpLmpvaW4oJycpO1xuICAgICAgICAgICAgICAgIG5hbWUgPSAvKFteXFwvXSopLy5leGVjKG5hbWUpO1xuICAgICAgICAgICAgICAgIG5hbWUgPSBuYW1lWzFdLnNwbGl0KCcnKS5yZXZlcnNlKCkuam9pbignJyk7XG4gICAgICAgICAgICAgICAgbWVzaC5uYW1lID0gdXJsO1xuICAgICAgICAgICAgICAgIHJldHVybiB7cG9zaXRpb24sIGxhYmVsLCBoZWFkZXI6IFBDRGhlYWRlciwgcmdifTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9O1xuXG4gICAgfVxufVxuIiwiXG5mdW5jdGlvbiBGYXN0SW50ZWdlckNvbXByZXNzaW9uKCkge1xufVxuXG5mdW5jdGlvbiBieXRlbG9nKHZhbCkge1xuICAgIGlmICh2YWwgPCAoMSA8PCA3KSkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICB9IGVsc2UgaWYgKHZhbCA8ICgxIDw8IDE0KSkge1xuICAgICAgICByZXR1cm4gMjtcbiAgICB9IGVsc2UgaWYgKHZhbCA8ICgxIDw8IDIxKSkge1xuICAgICAgICByZXR1cm4gMztcbiAgICB9IGVsc2UgaWYgKHZhbCA8ICgxIDw8IDI4KSkge1xuICAgICAgICByZXR1cm4gNDtcbiAgICB9XG4gICAgcmV0dXJuIDU7XG59XG5cbi8vIGNvbXB1dGUgaG93IG1hbnkgYnl0ZXMgYW4gYXJyYXkgb2YgaW50ZWdlcnMgd291bGQgdXNlIG9uY2UgY29tcHJlc3NlZFxuRmFzdEludGVnZXJDb21wcmVzc2lvbi5jb21wdXRlQ29tcHJlc3NlZFNpemVJbkJ5dGVzID0gZnVuY3Rpb24oaW5wdXQpIHtcbiAgICB2YXIgYyA9IGlucHV0Lmxlbmd0aDtcbiAgICB2YXIgYW5zd2VyID0gMDtcbiAgICBmb3IodmFyIGkgPSAwOyBpIDwgYzsgaSsrKSB7XG4gICAgICAgIGFuc3dlciArPSBieXRlbG9nKGlucHV0W2ldKTtcbiAgICB9XG4gICAgcmV0dXJuIGFuc3dlcjtcbn07XG5cblxuLy8gY29tcHJlc3MgYW4gYXJyYXkgb2YgaW50ZWdlcnMsIHJldHVybiBhIGNvbXByZXNzZWQgYnVmZmVyIChhcyBhbiBBcnJheUJ1ZmZlcilcbkZhc3RJbnRlZ2VyQ29tcHJlc3Npb24uY29tcHJlc3MgPSBmdW5jdGlvbihpbnB1dCkge1xuICAgIHZhciBjID0gaW5wdXQubGVuZ3RoO1xuICAgIHZhciBidWYgPSBuZXcgQXJyYXlCdWZmZXIoRmFzdEludGVnZXJDb21wcmVzc2lvbi5jb21wdXRlQ29tcHJlc3NlZFNpemVJbkJ5dGVzKGlucHV0KSk7XG4gICAgdmFyIHZpZXcgICA9IG5ldyBJbnQ4QXJyYXkoYnVmKTtcbiAgICB2YXIgcG9zID0gMDtcbiAgICBmb3IodmFyIGkgPSAwOyBpIDwgYzsgaSsrKSB7XG4gICAgICAgIHZhciB2YWwgPSBpbnB1dFtpXTtcbiAgICAgICAgaWYgKHZhbCA8ICgxIDw8IDcpKSB7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9IHZhbCA7XG4gICAgICAgIH0gZWxzZSBpZiAodmFsIDwgKDEgPDwgMTQpKSB7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9ICh2YWwgJiAweDdGKSB8IDB4ODA7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9IHZhbCA+Pj4gNztcbiAgICAgICAgfSBlbHNlIGlmICh2YWwgPCAoMSA8PCAyMSkpIHtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gKHZhbCAmIDB4N0YpIHwgMHg4MDtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gKCAodmFsID4+PiA3KSAmIDB4N0YgKSB8IDB4ODA7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9IHZhbCA+Pj4gMTQ7XG4gICAgICAgIH0gZWxzZSBpZiAodmFsIDwgKDEgPDwgMjgpKSB7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9ICh2YWwgJiAweDdGICkgfCAweDgwIDtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gKCAodmFsID4+PiA3KSAmIDB4N0YgKSB8IDB4ODA7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9ICggKHZhbCA+Pj4gMTQpICYgMHg3RiApIHwgMHg4MDtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gdmFsID4+PiAyMTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gKCB2YWwgJiAweDdGICkgfCAweDgwO1xuICAgICAgICAgICAgdmlld1twb3MrK10gPSAoICh2YWwgPj4+IDcpICYgMHg3RiApIHwgMHg4MDtcbiAgICAgICAgICAgIHZpZXdbcG9zKytdID0gKCAodmFsID4+PiAxNCkgJiAweDdGICkgfCAweDgwO1xuICAgICAgICAgICAgdmlld1twb3MrK10gPSAoICh2YWwgPj4+IDIxKSAmIDB4N0YgKSB8IDB4ODA7XG4gICAgICAgICAgICB2aWV3W3BvcysrXSA9IHZhbCA+Pj4gMjg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGJ1Zjtcbn07XG5cbi8vIGZyb20gYSBjb21wcmVzc2VkIGFycmF5IG9mIGludGVnZXJzIHN0b3JlZCBBcnJheUJ1ZmZlciwgY29tcHV0ZSB0aGUgbnVtYmVyIG9mIGNvbXByZXNzZWQgaW50ZWdlcnMgYnkgc2Nhbm5pbmcgdGhlIGlucHV0XG5GYXN0SW50ZWdlckNvbXByZXNzaW9uLmNvbXB1dGVIb3dNYW55SW50ZWdlcnMgPSBmdW5jdGlvbihpbnB1dCkge1xuICAgIHZhciB2aWV3ICAgPSBuZXcgSW50OEFycmF5KGlucHV0KTtcbiAgICB2YXIgYyA9IHZpZXcubGVuZ3RoO1xuICAgIHZhciBjb3VudCA9IDA7XG4gICAgZm9yKHZhciBpID0gMDsgaSA8IGM7IGkrKykge1xuICAgICAgICBjb3VudCArPSAoaW5wdXRbaV0+Pj43KTtcbiAgICB9XG4gICAgcmV0dXJuIGMgLSBjb3VudDtcbn07XG4vLyB1bmNvbXByZXNzIGFuIGFycmF5IG9mIGludGVnZXIgZnJvbSBhbiBBcnJheUJ1ZmZlciwgcmV0dXJuIHRoZSBhcnJheVxuRmFzdEludGVnZXJDb21wcmVzc2lvbi51bmNvbXByZXNzID0gZnVuY3Rpb24oaW5wdXQpIHtcbiAgICB2YXIgYXJyYXkgPSBbXTtcbiAgICB2YXIgaW5ieXRlID0gbmV3IEludDhBcnJheShpbnB1dCk7XG4gICAgdmFyIGVuZCA9IGluYnl0ZS5sZW5ndGg7XG4gICAgdmFyIHBvcyA9IDA7XG5cbiAgICB3aGlsZSAoZW5kID4gcG9zKSB7XG4gICAgICAgIHZhciBjID0gaW5ieXRlW3BvcysrXTtcbiAgICAgICAgdmFyIHYgPSBjICYgMHg3RjtcbiAgICAgICAgaWYgKGMgPj0gMCkge1xuICAgICAgICAgICAgYXJyYXkucHVzaCh2KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGMgPSBpbmJ5dGVbcG9zKytdO1xuICAgICAgICB2IHw9IChjICYgMHg3RikgPDwgNztcbiAgICAgICAgaWYgKGMgPj0gMCkge1xuICAgICAgICAgICAgYXJyYXkucHVzaCh2KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGMgPSBpbmJ5dGVbcG9zKytdO1xuICAgICAgICB2IHw9IChjICYgMHg3RikgPDwgMTQ7XG4gICAgICAgIGlmIChjID49IDApIHtcbiAgICAgICAgICAgIGFycmF5LnB1c2godik7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjID0gaW5ieXRlW3BvcysrXTtcbiAgICAgICAgdiB8PSAoYyAmIDB4N0YpIDw8IDIxO1xuICAgICAgICBpZiAoYyA+PSAwKSB7XG4gICAgICAgICAgICBhcnJheS5wdXNoKHYpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgYyA9IGluYnl0ZVtwb3MrK107XG4gICAgICAgIHYgfD0gYyA8PCAyODtcbiAgICAgICAgYXJyYXkucHVzaCh2KVxuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59O1xuXG5MWlcgPSB7XG4gICAgY29tcHJlc3M6IGZ1bmN0aW9uICh1bmNvbXByZXNzZWQpIHtcbiAgICAgICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgICAgIC8vIEJ1aWxkIHRoZSBkaWN0aW9uYXJ5LlxuICAgICAgICB2YXIgaSxcbiAgICAgICAgICAgIGRpY3Rpb25hcnkgPSB7fSxcbiAgICAgICAgICAgIGMsXG4gICAgICAgICAgICB3YyxcbiAgICAgICAgICAgIHcgPSBcIlwiLFxuICAgICAgICAgICAgcmVzdWx0ID0gW10sXG4gICAgICAgICAgICBkaWN0U2l6ZSA9IDI1NjtcbiAgICAgICAgZm9yIChpID0gMDsgaSA8IDI1NjsgaSArPSAxKSB7XG4gICAgICAgICAgICBkaWN0aW9uYXJ5W1N0cmluZy5mcm9tQ2hhckNvZGUoaSldID0gaTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCB1bmNvbXByZXNzZWQubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICAgIGMgPSB1bmNvbXByZXNzZWQuY2hhckF0KGkpO1xuICAgICAgICAgICAgd2MgPSB3ICsgYztcbiAgICAgICAgICAgIC8vRG8gbm90IHVzZSBkaWN0aW9uYXJ5W3djXSBiZWNhdXNlIGphdmFzY3JpcHQgYXJyYXlzXG4gICAgICAgICAgICAvL3dpbGwgcmV0dXJuIHZhbHVlcyBmb3IgYXJyYXlbJ3BvcCddLCBhcnJheVsncHVzaCddIGV0Y1xuICAgICAgICAgICAgLy8gaWYgKGRpY3Rpb25hcnlbd2NdKSB7XG4gICAgICAgICAgICBpZiAoZGljdGlvbmFyeS5oYXNPd25Qcm9wZXJ0eSh3YykpIHtcbiAgICAgICAgICAgICAgICB3ID0gd2M7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKGRpY3Rpb25hcnlbd10pO1xuICAgICAgICAgICAgICAgIC8vIEFkZCB3YyB0byB0aGUgZGljdGlvbmFyeS5cbiAgICAgICAgICAgICAgICBkaWN0aW9uYXJ5W3djXSA9IGRpY3RTaXplKys7XG4gICAgICAgICAgICAgICAgdyA9IFN0cmluZyhjKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE91dHB1dCB0aGUgY29kZSBmb3Igdy5cbiAgICAgICAgaWYgKHcgIT09IFwiXCIpIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGRpY3Rpb25hcnlbd10pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSxcblxuXG4gICAgZGVjb21wcmVzczogZnVuY3Rpb24gKGNvbXByZXNzZWQpIHtcbiAgICAgICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgICAgIC8vIEJ1aWxkIHRoZSBkaWN0aW9uYXJ5LlxuICAgICAgICB2YXIgaSxcbiAgICAgICAgICAgIGRpY3Rpb25hcnkgPSBbXSxcbiAgICAgICAgICAgIHcsXG4gICAgICAgICAgICByZXN1bHQsXG4gICAgICAgICAgICBrLFxuICAgICAgICAgICAgZW50cnkgPSBcIlwiLFxuICAgICAgICAgICAgZGljdFNpemUgPSAyNTY7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCAyNTY7IGkgKz0gMSkge1xuICAgICAgICAgICAgZGljdGlvbmFyeVtpXSA9IFN0cmluZy5mcm9tQ2hhckNvZGUoaSk7XG4gICAgICAgIH1cblxuICAgICAgICB3ID0gU3RyaW5nLmZyb21DaGFyQ29kZShjb21wcmVzc2VkWzBdKTtcbiAgICAgICAgcmVzdWx0ID0gdztcbiAgICAgICAgZm9yIChpID0gMTsgaSA8IGNvbXByZXNzZWQubGVuZ3RoOyBpICs9IDEpIHtcblxuICAgICAgICAgICAgayA9IGNvbXByZXNzZWRbaV07XG4gICAgICAgICAgICBpZiAoZGljdGlvbmFyeVtrXSkge1xuICAgICAgICAgICAgICAgIGVudHJ5ID0gZGljdGlvbmFyeVtrXTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKGsgPT09IGRpY3RTaXplKSB7XG4gICAgICAgICAgICAgICAgICAgIGVudHJ5ID0gdyArIHcuY2hhckF0KDApO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmVzdWx0ICs9IGVudHJ5O1xuXG4gICAgICAgICAgICBkaWN0aW9uYXJ5W2RpY3RTaXplKytdID0gdyArIGVudHJ5LmNoYXJBdCgwKTtcblxuICAgICAgICAgICAgdyA9IGVudHJ5O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufTtcblxuZnVuY3Rpb24gb2JqZWN0VG9CeXRlcyhvYmope1xuICAgIGxldCBwYXlsb2FkID0gSlNPTi5zdHJpbmdpZnkob2JqKTtcbiAgICBwYXlsb2FkID0gTFpXLmNvbXByZXNzKHBheWxvYWQpO1xuICAgIHBheWxvYWQgPSBGYXN0SW50ZWdlckNvbXByZXNzaW9uLmNvbXByZXNzKHBheWxvYWQpO1xuICAgIHJldHVybiBwYXlsb2FkO1xufVxuXG5mdW5jdGlvbiBieXRlc1RvT2JqZWN0KGJ5dGVzKXtcblxuICAgIGlmIChieXRlcy5ieXRlTGVuZ3RoICA+IDApIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IEZhc3RJbnRlZ2VyQ29tcHJlc3Npb24udW5jb21wcmVzcyhieXRlcyk7XG4gICAgICAgIGNvbnN0IHN0ciA9IExaVy5kZWNvbXByZXNzKGRhdGEpO1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShzdHIpO1xuICAgIH1lbHNlIHJldHVybiBudWxsO1xufVxuXG5leHBvcnQgZGVmYXVsdCB7XG4gICAgY29tcHJlc3M6IChkYXRhKT0+KG9iamVjdFRvQnl0ZXMoZGF0YSkpLFxuICAgIHVuY29tcHJlc3M6IChkYXRhKT0+KGJ5dGVzVG9PYmplY3QoZGF0YSkpXG59O1xuIiwiaW1wb3J0IFNzZURhdGFXb3JrZXJTZXJ2ZXIgZnJvbSBcIi4vU3NlRGF0YVdvcmtlclNlcnZlclwiO1xuaW1wb3J0IGNvbmZpZ3VyYXRpb25GaWxlIGZyb20gXCIuL2NvbmZpZ1wiO1xuaW1wb3J0IHtiYXNlbmFtZX0gZnJvbSBcInBhdGhcIjtcbmltcG9ydCB7cmVhZEZpbGV9IGZyb20gXCJmc1wiO1xuaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuaW1wb3J0IFNzZVBDRExvYWRlciBmcm9tIFwiLi4vaW1wb3J0cy9lZGl0b3IvM2QvU3NlUENETG9hZGVyXCI7XG5cbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKFwiL2FwaS9qc29uXCIsIGdlbmVyYXRlSnNvbik7XG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShcIi9hcGkvcGNkdGV4dFwiLCBnZW5lcmF0ZVBDRE91dHB1dC5iaW5kKHtmaWxlTW9kZTogZmFsc2V9KSk7XG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShcIi9hcGkvcGNkZmlsZVwiLCBnZW5lcmF0ZVBDRE91dHB1dC5iaW5kKHtmaWxlTW9kZTogdHJ1ZX0pKTtcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKFwiL2FwaS9saXN0aW5nXCIsIGltYWdlc0xpc3RpbmcpO1xuXG5jb25zdCB7aW1hZ2VzRm9sZGVyLCBwb2ludGNsb3Vkc0ZvbGRlciwgc2V0c09mQ2xhc3Nlc01hcH0gPSBjb25maWd1cmF0aW9uRmlsZTtcbm5ldyBTc2VQQ0RMb2FkZXIoVEhSRUUpO1xuXG5mdW5jdGlvbiBpbWFnZXNMaXN0aW5nKHJlcSwgcmVzLCBuZXh0KSB7XG4gICAgY29uc3QgYWxsID0gU3NlU2FtcGxlcy5maW5kKHt9LCB7XG4gICAgICAgIGZpZWxkczoge1xuICAgICAgICAgICAgdXJsOiAxLFxuICAgICAgICAgICAgZm9sZGVyOiAxLFxuICAgICAgICAgICAgZmlsZTogMSxcbiAgICAgICAgICAgIHRhZ3M6IDEsXG4gICAgICAgICAgICBmaXJzdEVkaXREYXRlOiAxLFxuICAgICAgICAgICAgbGFzdEVkaXREYXRlOiAxXG4gICAgICAgIH1cbiAgICB9KS5mZXRjaCgpO1xuICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoYWxsLCBudWxsLCAxKSk7XG59XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSnNvbihyZXEsIHJlcywgbmV4dCkge1xuICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJyk7XG4gICAgY29uc3QgaXRlbSA9IFNzZVNhbXBsZXMuZmluZE9uZSh7dXJsOiByZXEudXJsfSk7XG4gICAgaWYgKGl0ZW0pIHtcbiAgICAgICAgY29uc3Qgc29jID0gc2V0c09mQ2xhc3Nlc01hcC5nZXQoaXRlbS5zb2NOYW1lKTtcbiAgICAgICAgaXRlbS5vYmplY3RzLmZvckVhY2gob2JqID0+IHtcbiAgICAgICAgICAgIG9iai5sYWJlbCA9IHNvYy5vYmplY3RzW29iai5jbGFzc0luZGV4XS5sYWJlbDtcbiAgICAgICAgfSk7XG4gICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoaXRlbSwgbnVsbCwgMSkpO1xuICAgIH1lbHNle1xuICAgICAgICByZXMuZW5kKFwie31cIik7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZVBDRE91dHB1dChyZXEsIHJlcywgbmV4dCkge1xuICAgIGNvbnN0IHBjZEZpbGUgPSBpbWFnZXNGb2xkZXIgKyBkZWNvZGVVUklDb21wb25lbnQocmVxLnVybCk7XG4gICAgY29uc3QgZmlsZU5hbWUgPSBiYXNlbmFtZShwY2RGaWxlKTtcbiAgICBjb25zdCBsYWJlbEZpbGUgPSBwb2ludGNsb3Vkc0ZvbGRlciArIGRlY29kZVVSSUNvbXBvbmVudChyZXEudXJsKSArIFwiLmxhYmVsc1wiO1xuICAgIGNvbnN0IG9iamVjdEZpbGUgPSBwb2ludGNsb3Vkc0ZvbGRlciArIGRlY29kZVVSSUNvbXBvbmVudChyZXEudXJsKSArIFwiLm9iamVjdHNcIjtcblxuICAgIGlmICh0aGlzLmZpbGVNb2RlKSB7XG4gICAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtZGlzcG9zaXRpb24nLCAnYXR0YWNobWVudDsgZmlsZW5hbWU9RE9DJy5yZXBsYWNlKFwiRE9DXCIsIGZpbGVOYW1lKSk7XG4gICAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtdHlwZScsICd0ZXh0L3BsYWluJyk7XG4gICAgICAgIHJlcy5jaGFyc2V0ID0gJ1VURi04JztcbiAgICB9XG5cblxuICAgIHJlYWRGaWxlKHBjZEZpbGUsIChlcnIsIGNvbnRlbnQpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgcmVzLmVuZChcIkVycm9yIHdoaWxlIHBhcnNpbmcgUENEIGZpbGUuXCIpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBsb2FkZXIgPSBuZXcgVEhSRUUuUENETG9hZGVyKHRydWUpO1xuICAgICAgICBjb25zdCBwY2RDb250ZW50ID0gbG9hZGVyLnBhcnNlKGNvbnRlbnQuYnVmZmVyLCBcIlwiKTtcbiAgICAgICAgY29uc3QgaGFzUmdiID0gcGNkQ29udGVudC5yZ2IubGVuZ3RoID4gMDtcbiAgICAgICAgY29uc3QgaGVhZCA9IHBjZENvbnRlbnQuaGVhZGVyO1xuICAgICAgICBjb25zdCByZ2IyaW50ID0gcmdiID0+IHJnYlsyXSArIDI1NiAqIHJnYlsxXSArIDI1NiAqIDI1NiAqIHJnYlswXTtcblxuICAgICAgICBsZXQgb3V0ID0gXCJWRVJTSU9OIC43XFxuXCI7XG4gICAgICAgIG91dCArPSBoYXNSZ2IgPyBcIkZJRUxEUyB4IHkgeiByZ2IgbGFiZWwgb2JqZWN0XFxuXCIgOiBcIkZJRUxEUyB4IHkgeiBsYWJlbCBvYmplY3RcXG5cIjtcbiAgICAgICAgb3V0ICs9IGhhc1JnYiA/IFwiU0laRSA0IDQgNCA0IDQgNFxcblwiIDogXCJTSVpFIDQgNCA0IDQgNFxcblwiO1xuICAgICAgICBvdXQgKz0gaGFzUmdiID8gXCJUWVBFIEYgRiBGIEkgSSBJXFxuXCIgOiBcIlRZUEUgRiBGIEYgSSBJXFxuXCI7XG4gICAgICAgIG91dCArPSBoYXNSZ2IgPyBcIkNPVU5UIDEgMSAxIDEgMSAxXFxuXCIgOiBcIkNPVU5UIDEgMSAxIDEgMVxcblwiO1xuICAgICAgICBvdXQgKz0gXCJXSURUSCBcIiArIHBjZENvbnRlbnQuaGVhZGVyLndpZHRoICsgXCJcXG5cIjtcbiAgICAgICAgb3V0ICs9IFwiSEVJR0hUIFwiICsgcGNkQ29udGVudC5oZWFkZXIuaGVpZ2h0ICsgXCJcXG5cIjtcbiAgICAgICAgb3V0ICs9IFwiUE9JTlRTIFwiICsgcGNkQ29udGVudC5oZWFkZXIud2lkdGgqcGNkQ29udGVudC5oZWFkZXIuaGVpZ2h0ICsgXCJcXG5cIjtcbiAgICAgICAgb3V0ICs9IFwiVklFV1BPSU5UIFwiICsgaGVhZC52aWV3cG9pbnQudHg7XG4gICAgICAgIG91dCArPSBcIiBcIiArIGhlYWQudmlld3BvaW50LnR5O1xuICAgICAgICBvdXQgKz0gXCIgXCIgKyBoZWFkLnZpZXdwb2ludC50ejtcbiAgICAgICAgb3V0ICs9IFwiIFwiICsgaGVhZC52aWV3cG9pbnQucXc7XG4gICAgICAgIG91dCArPSBcIiBcIiArIGhlYWQudmlld3BvaW50LnF4O1xuICAgICAgICBvdXQgKz0gXCIgXCIgKyBoZWFkLnZpZXdwb2ludC5xeTtcbiAgICAgICAgb3V0ICs9IFwiIFwiICsgaGVhZC52aWV3cG9pbnQucXogKyBcIlxcblwiO1xuICAgICAgICBvdXQgKz0gXCJEQVRBIGFzY2lpXFxuXCI7XG4gICAgICAgIHJlcy53cml0ZShvdXQpO1xuICAgICAgICBvdXQgPSBcIlwiO1xuICAgICAgICByZWFkRmlsZShsYWJlbEZpbGUsIChsYWJlbEVyciwgbGFiZWxDb250ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAobGFiZWxFcnIpIHtcbiAgICAgICAgICAgICAgICByZXMuZW5kKFwiRXJyb3Igd2hpbGUgcGFyc2luZyBsYWJlbHMgZmlsZS5cIilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGxhYmVscyA9IFNzZURhdGFXb3JrZXJTZXJ2ZXIudW5jb21wcmVzcyhsYWJlbENvbnRlbnQpO1xuXG4gICAgICAgICAgICByZWFkRmlsZShvYmplY3RGaWxlLCAob2JqZWN0RXJyLCBvYmplY3RDb250ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IG9iamVjdHNBdmFpbGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGlmIChvYmplY3RFcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0c0F2YWlsYWJsZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdEJ5UG9pbnRJbmRleCA9IG5ldyBNYXAoKTtcblxuICAgICAgICAgICAgICAgIGlmIChvYmplY3RzQXZhaWxhYmxlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdHMgPSBTc2VEYXRhV29ya2VyU2VydmVyLnVuY29tcHJlc3Mob2JqZWN0Q29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIG9iamVjdHMuZm9yRWFjaCgob2JqLCBvYmpJbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JqLnBvaW50cy5mb3JFYWNoKHB0SWR4ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RCeVBvaW50SW5kZXguc2V0KHB0SWR4LCBvYmpJbmRleCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IG9iajtcblxuICAgICAgICAgICAgICAgIHBjZENvbnRlbnQucG9zaXRpb24uZm9yRWFjaCgodiwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwb3NpdGlvbiA9IE1hdGguZmxvb3IoaSAvIDMpO1xuXG4gICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoaSAlIDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGFzUmdiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iaiA9IHtyZ2I6IHBjZENvbnRlbnQucmdiW3Bvc2l0aW9uXSwgeDogdn07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iaiA9IHt4OiB2fTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLnkgPSB2O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai56ID0gdjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXQgKz0gb2JqLnggKyBcIiBcIiArIG9iai55ICsgXCIgXCIgKyBvYmoueiArIFwiIFwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoYXNSZ2IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0ICs9IHJnYjJpbnQob2JqLnJnYikgKyBcIiBcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0ICs9IGxhYmVsc1twb3NpdGlvbl0gKyBcIiBcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhc3NpZ25lZE9iamVjdCA9IG9iamVjdEJ5UG9pbnRJbmRleC5nZXQocG9zaXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhc3NpZ25lZE9iamVjdCAhPSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dCArPSBhc3NpZ25lZE9iamVjdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dCArPSBcIi0xXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0ICs9IFwiXFxuXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzLndyaXRlKG91dCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0ID0gXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHtqb2lufSBmcm9tIFwicGF0aFwiO1xuaW1wb3J0IHtta2RpclN5bmMsIGV4aXN0c1N5bmN9IGZyb20gXCJmc1wiO1xuaW1wb3J0IG9zIGZyb20gXCJvc1wiO1xuaW1wb3J0IGRvd25sb2FkIGZyb20gXCJkb3dubG9hZFwiO1xuXG5jb25zdCBjb25maWd1cmF0aW9uRmlsZSA9IHt9O1xuY29uc3QgZGVmYXVsdENsYXNzZXMgPSBbe1xuICAgIFwibmFtZVwiOiBcIjMzIENsYXNzZXNcIiwgXCJvYmplY3RzXCI6IFtcbiAgICAgICAge1wibGFiZWxcIjogXCJWT0lEXCIsIFwiY29sb3JcIjogXCIjQ0ZDRkNGXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDFcIn0sXG4gICAgICAgIHtcImxhYmVsXCI6IFwiQ2xhc3MgMlwifSxcbiAgICAgICAge1wibGFiZWxcIjogXCJDbGFzcyAzXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDRcIn0sXG4gICAgICAgIHtcImxhYmVsXCI6IFwiQ2xhc3MgNVwifSxcbiAgICAgICAge1wibGFiZWxcIjogXCJDbGFzcyA2XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDdcIn0sXG4gICAgICAgIHtcImxhYmVsXCI6IFwiQ2xhc3MgOFwifSxcbiAgICAgICAge1wibGFiZWxcIjogXCJDbGFzcyA5XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDEwXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDExXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDEyXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDEzXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE0XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE1XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE2XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE3XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE4XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDE5XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDIwXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDIxXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDIyXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDIzXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI0XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI1XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI2XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI3XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI4XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDI5XCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDMwXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDMxXCJ9LFxuICAgICAgICB7XCJsYWJlbFwiOiBcIkNsYXNzIDMyXCJ9XG4gICAgXVxufV07XG5jb25zdCBpbml0ID0gKCk9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29uZmlnID0gTWV0ZW9yLnNldHRpbmdzO1xuXG4gICAgICAgIGlmIChjb25maWcuY29uZmlndXJhdGlvbiAmJiBjb25maWcuY29uZmlndXJhdGlvbltcImltYWdlcy1mb2xkZXJcIl0gIT0gXCJcIikge1xuICAgICAgICAgICAgY29uZmlndXJhdGlvbkZpbGUuaW1hZ2VzRm9sZGVyID0gY29uZmlnLmNvbmZpZ3VyYXRpb25bXCJpbWFnZXMtZm9sZGVyXCJdLnJlcGxhY2UoL1xcLyQvLCBcIlwiKTtcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBjb25maWd1cmF0aW9uRmlsZS5pbWFnZXNGb2xkZXIgPSBqb2luKG9zLmhvbWVkaXIoKSwgXCJzc2UtaW1hZ2VzXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFleGlzdHNTeW5jKGNvbmZpZ3VyYXRpb25GaWxlLmltYWdlc0ZvbGRlcikpe1xuICAgICAgICAgICAgbWtkaXJTeW5jKGNvbmZpZ3VyYXRpb25GaWxlLmltYWdlc0ZvbGRlcik7XG4gICAgICAgICAgICBkb3dubG9hZChcImh0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9IaXRhY2hpLUF1dG9tb3RpdmUtQW5kLUluZHVzdHJ5LUxhYi9zZW1hbnRpYy1zZWdtZW50YXRpb24tZWRpdG9yL21hc3Rlci9wcml2YXRlL3NhbXBsZXMvYml0bWFwX2xhYmVsaW5nLnBuZ1wiLCBjb25maWd1cmF0aW9uRmlsZS5pbWFnZXNGb2xkZXIpO1xuICAgICAgICAgICAgZG93bmxvYWQoXCJodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vSGl0YWNoaS1BdXRvbW90aXZlLUFuZC1JbmR1c3RyeS1MYWIvc2VtYW50aWMtc2VnbWVudGF0aW9uLWVkaXRvci9tYXN0ZXIvcHJpdmF0ZS9zYW1wbGVzL3BvaW50Y2xvdWRfbGFiZWxpbmcucGNkXCIsIGNvbmZpZ3VyYXRpb25GaWxlLmltYWdlc0ZvbGRlcik7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY29uZmlnLmNvbmZpZ3VyYXRpb24gJiYgY29uZmlnLmNvbmZpZ3VyYXRpb25bXCJpbnRlcm5hbC1mb2xkZXJcIl0gIT0gXCJcIikge1xuICAgICAgICAgICAgY29uZmlndXJhdGlvbkZpbGUucG9pbnRjbG91ZHNGb2xkZXIgPSBjb25maWcuY29uZmlndXJhdGlvbltcImludGVybmFsLWZvbGRlclwiXS5yZXBsYWNlKC9cXC8kLywgXCJcIik7XG4gICAgICAgIH1lbHNle1xuXG4gICAgICAgICAgICBjb25maWd1cmF0aW9uRmlsZS5wb2ludGNsb3Vkc0ZvbGRlciA9IGpvaW4ob3MuaG9tZWRpcigpLCBcInNzZS1pbnRlcm5hbFwiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbmZpZ3VyYXRpb25GaWxlLnNldHNPZkNsYXNzZXNNYXAgPSBuZXcgTWFwKCk7XG4gICAgICAgIGNvbmZpZ3VyYXRpb25GaWxlLnNldHNPZkNsYXNzZXMgPSBjb25maWdbXCJzZXRzLW9mLWNsYXNzZXNcIl07XG4gICAgICAgIGlmICghY29uZmlndXJhdGlvbkZpbGUuc2V0c09mQ2xhc3Nlcyl7XG4gICAgICAgICAgICBjb25maWd1cmF0aW9uRmlsZS5zZXRzT2ZDbGFzc2VzID0gZGVmYXVsdENsYXNzZXM7XG4gICAgICAgIH1cbiAgICAgICAgY29uZmlndXJhdGlvbkZpbGUuc2V0c09mQ2xhc3Nlcy5mb3JFYWNoKG8gPT4gY29uZmlndXJhdGlvbkZpbGUuc2V0c09mQ2xhc3Nlc01hcC5zZXQoby5uYW1lLCBvKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiU2VtYW50aWMgU2VnbWVudGF0aW9uIEVkaXRvclwiKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJJbWFnZXMgKEpQRywgUE5HLCBQQ0QpIHNlcnZlZCBmcm9tXCIsIGNvbmZpZ3VyYXRpb25GaWxlLmltYWdlc0ZvbGRlcik7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUENEIGJpbmFyeSBzZWdtZW50YXRpb24gZGF0YSBzdG9yZWQgaW5cIiwgY29uZmlndXJhdGlvbkZpbGUucG9pbnRjbG91ZHNGb2xkZXIpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIk51bWJlciBvZiBhdmFpbGFibGUgc2V0cyBvZiBvYmplY3QgY2xhc3NlczpcIiwgY29uZmlndXJhdGlvbkZpbGUuc2V0c09mQ2xhc3Nlcy5sZW5ndGgpO1xuICAgICAgICByZXR1cm4gY29uZmlndXJhdGlvbkZpbGU7XG4gICAgfWNhdGNoKGUpe1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igd2hpbGUgcGFyc2luZyBzZXR0aW5ncy5qc29uOlwiLCBlKTtcbiAgICB9XG59O1xuZXhwb3J0IGRlZmF1bHQgaW5pdCgpO1xuIiwiaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgc2hlbGwgZnJvbSBcInNoZWxsanNcIjtcbmltcG9ydCBzZXJ2ZVN0YXRpYyBmcm9tIFwic2VydmUtc3RhdGljXCI7XG5pbXBvcnQgYm9keVBhcnNlciBmcm9tIFwiYm9keS1wYXJzZXJcIjtcbmltcG9ydCB7Y3JlYXRlV3JpdGVTdHJlYW0sIGxzdGF0U3luYywgcmVhZGRpclN5bmMsIHJlYWRGaWxlLCByZWFkRmlsZVN5bmN9IGZyb20gXCJmc1wiO1xuaW1wb3J0IHtiYXNlbmFtZSwgZXh0bmFtZSwgam9pbn0gZnJvbSBcInBhdGhcIjtcbmltcG9ydCBjb25maWd1cmF0aW9uRmlsZSBmcm9tIFwiLi9jb25maWdcIjtcbmNvbnN0IGRlbW9Nb2RlID0gTWV0ZW9yLnNldHRpbmdzLmNvbmZpZ3VyYXRpb25bXCJkZW1vLW1vZGVcIl07XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcblxuY29uc3Qge2ltYWdlc0ZvbGRlciwgcG9pbnRjbG91ZHNGb2xkZXJ9ID0gY29uZmlndXJhdGlvbkZpbGU7XG4gICAgV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoXCIvZmlsZVwiLCBzZXJ2ZVN0YXRpYyhpbWFnZXNGb2xkZXIsIHtmYWxsdGhyb3VnaDogZmFsc2V9KSk7XG4gICAgV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoXCIvZGF0YWZpbGVcIiwgc2VydmVTdGF0aWMocG9pbnRjbG91ZHNGb2xkZXIsIHtmYWxsdGhyb3VnaDogdHJ1ZX0pKTtcbiAgICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShcIi9kYXRhZmlsZVwiLCAocmVxLHJlcyk9PntcbiAgICAgICAgcmVzLmVuZChcIlwiKTtcbiAgICB9KTtcblxuICAgIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKGJvZHlQYXJzZXIucmF3KHtsaW1pdDogXCIyMDBtYlwiLCB0eXBlOiAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJ30pKTtcbiAgICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3NhdmUnLCBmdW5jdGlvbiAocmVxLCByZXMpIHtcbiAgICAgICAgaWYgKGRlbW9Nb2RlKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGZpbGVUb1NhdmUgPSBwb2ludGNsb3Vkc0ZvbGRlciArIGRlY29kZVVSSUNvbXBvbmVudChyZXEudXJsKS5yZXBsYWNlKFwiL3NhdmVcIiwgXCJcIik7XG4gICAgICAgIGNvbnN0IGRpciA9IGZpbGVUb1NhdmUubWF0Y2goXCIoLipcXC8pLipcIilbMV07XG4gICAgICAgIHNoZWxsLm1rZGlyKCctcCcsIGRpcik7XG5cbiAgICAgICAgdmFyIHdzdHJlYW0gPSBjcmVhdGVXcml0ZVN0cmVhbShmaWxlVG9TYXZlKTtcbiAgICAgICAgd3N0cmVhbS53cml0ZShyZXEuYm9keSk7XG4gICAgICAgIHdzdHJlYW0uZW5kKCk7XG4gICAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nKTtcbiAgICAgICAgcmVzLnNldEhlYWRlcihcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiLCBcIipcIik7XG4gICAgICAgIHJlcy5zZXRIZWFkZXIoXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCIsIFwiT3JpZ2luLCBYLVJlcXVlc3RlZC1XaXRoLCBDb250ZW50LVR5cGUsIEFjY2VwdFwiKTtcbiAgICAgICAgcmVzLmVuZChcIlNlbnQ6IFwiICsgZmlsZVRvU2F2ZSk7XG4gICAgfSk7XG59KTtcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7Y3JlYXRlV3JpdGVTdHJlYW0sIGxzdGF0U3luYywgcmVhZGRpclN5bmMsIHJlYWRGaWxlLCByZWFkRmlsZVN5bmMsIGV4aXN0c1N5bmN9IGZyb20gXCJmc1wiO1xuaW1wb3J0IHtiYXNlbmFtZSwgZXh0bmFtZSwgam9pbn0gZnJvbSBcInBhdGhcIjtcbmltcG9ydCB1cmwgZnJvbSBcInVybFwiO1xuaW1wb3J0IENvbG9yU2NoZW1lIGZyb20gXCJjb2xvci1zY2hlbWVcIjtcbmltcG9ydCBjb25maWcgZnJvbSBcIi4vY29uZmlnXCI7XG5jb25zdCBkZW1vTW9kZSA9IE1ldGVvci5zZXR0aW5ncy5jb25maWd1cmF0aW9uW1wiZGVtby1tb2RlXCJdO1xuXG5sZXQge2NsYXNzZXN9ID0gY29uZmlnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2dldENsYXNzZXNTZXRzJygpIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGNvbmZpZy5zZXRzT2ZDbGFzc2VzO1xuICAgICAgICBjb25zdCBzY2hlbWUgPSBuZXcgQ29sb3JTY2hlbWU7XG4gICAgICAgIHNjaGVtZS5mcm9tX2h1ZSgwKSAgICAgICAgIC8vIFN0YXJ0IHRoZSBzY2hlbWVcbiAgICAgICAgICAgIC5zY2hlbWUoJ3RldHJhZGUnKSAgICAgLy8gVXNlIHRoZSAndHJpYWRlJyBzY2hlbWUsIHRoYXQgaXMsIGNvbG9yc1xuICAgICAgICAgICAgLy8gc2VsZWN0ZWQgZnJvbSAzIHBvaW50cyBlcXVpZGlzdGFudCBhcm91bmRcbiAgICAgICAgICAgIC8vIHRoZSBjb2xvciB3aGVlbC5cbiAgICAgICAgICAgIC52YXJpYXRpb24oJ3NvZnQnKTsgICAvLyBVc2UgdGhlICdzb2Z0JyBjb2xvciB2YXJpYXRpb25cbiAgICAgICAgbGV0IGNvbG9ycyA9IHNjaGVtZS5jb2xvcnMoKTtcbiAgICAgICAgc2NoZW1lLmZyb21faHVlKDEwKSAgICAgICAgIC8vIFN0YXJ0IHRoZSBzY2hlbWVcbiAgICAgICAgICAgIC5zY2hlbWUoJ3RldHJhZGUnKSAgICAgLy8gVXNlIHRoZSAndHJpYWRlJyBzY2hlbWUsIHRoYXQgaXMsIGNvbG9yc1xuICAgICAgICAgICAgLy8gc2VsZWN0ZWQgZnJvbSAzIHBvaW50cyBlcXVpZGlzdGFudCBhcm91bmRcbiAgICAgICAgICAgIC8vIHRoZSBjb2xvciB3aGVlbC5cbiAgICAgICAgICAgIC52YXJpYXRpb24oJ3Bhc3RlbCcpOyAgIC8vIFVzZSB0aGUgJ3NvZnQnIGNvbG9yIHZhcmlhdGlvblxuICAgICAgICBjb2xvcnMgPSBjb2xvcnMuY29uY2F0KHNjaGVtZS5jb2xvcnMoKSk7XG4gICAgICAgIHNjaGVtZS5mcm9tX2h1ZSgyMCkgICAgICAgICAvLyBTdGFydCB0aGUgc2NoZW1lXG4gICAgICAgICAgICAuc2NoZW1lKCd0ZXRyYWRlJykgICAgIC8vIFVzZSB0aGUgJ3RyaWFkZScgc2NoZW1lLCB0aGF0IGlzLCBjb2xvcnNcbiAgICAgICAgICAgIC8vIHNlbGVjdGVkIGZyb20gMyBwb2ludHMgZXF1aWRpc3RhbnQgYXJvdW5kXG4gICAgICAgICAgICAvLyB0aGUgY29sb3Igd2hlZWwuXG4gICAgICAgICAgICAudmFyaWF0aW9uKCdoYXJkJyk7ICAgLy8gVXNlIHRoZSAnc29mdCcgY29sb3IgdmFyaWF0aW9uXG4gICAgICAgIGNvbG9ycyA9IGNvbG9ycy5jb25jYXQoc2NoZW1lLmNvbG9ycygpKTtcbiAgICAgICAgc2NoZW1lLmZyb21faHVlKDMwKSAgICAgICAgIC8vIFN0YXJ0IHRoZSBzY2hlbWVcbiAgICAgICAgICAgIC5zY2hlbWUoJ3RldHJhZGUnKSAgICAgLy8gVXNlIHRoZSAndHJpYWRlJyBzY2hlbWUsIHRoYXQgaXMsIGNvbG9yc1xuICAgICAgICAgICAgLy8gc2VsZWN0ZWQgZnJvbSAzIHBvaW50cyBlcXVpZGlzdGFudCBhcm91bmRcbiAgICAgICAgICAgIC8vIHRoZSBjb2xvciB3aGVlbC5cbiAgICAgICAgICAgIC52YXJpYXRpb24oJ2hhcmQnKTsgICAvLyBVc2UgdGhlICdzb2Z0JyBjb2xvciB2YXJpYXRpb25cbiAgICAgICAgY29sb3JzID0gY29sb3JzLmNvbmNhdChzY2hlbWUuY29sb3JzKCkpO1xuICAgICAgICBzY2hlbWUuZnJvbV9odWUoNDApICAgICAgICAgLy8gU3RhcnQgdGhlIHNjaGVtZVxuICAgICAgICAgICAgLnNjaGVtZSgndGV0cmFkZScpICAgICAvLyBVc2UgdGhlICd0cmlhZGUnIHNjaGVtZSwgdGhhdCBpcywgY29sb3JzXG4gICAgICAgICAgICAvLyBzZWxlY3RlZCBmcm9tIDMgcG9pbnRzIGVxdWlkaXN0YW50IGFyb3VuZFxuICAgICAgICAgICAgLy8gdGhlIGNvbG9yIHdoZWVsLlxuICAgICAgICAgICAgLnZhcmlhdGlvbignaGFyZCcpOyAgIC8vIFVzZSB0aGUgJ3NvZnQnIGNvbG9yIHZhcmlhdGlvblxuICAgICAgICBjb2xvcnMgPSBjb2xvcnMuY29uY2F0KHNjaGVtZS5jb2xvcnMoKSk7XG4gICAgICAgIGNvbG9ycyA9IGNvbG9ycy5tYXAoYyA9PiBcIiNcIiArIGMpO1xuICAgICAgICBkYXRhLmZvckVhY2goc29jID0+IHtcbiAgICAgICAgICAgIHNvYy5vYmplY3RzLmZvckVhY2goKG9jLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFvYy5jb2xvcikge1xuICAgICAgICAgICAgICAgICAgICBvYy5jb2xvciA9IGNvbG9yc1tpXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfSxcbiAgICAvKlxuICAgICAgICAncmVidWlsZFRhZ0xpc3QnKCkge1xuICAgICAgICAgICAgY29uc3QgYWxsID0gU3NlU2FtcGxlcy5maW5kKCkuZmV0Y2goKTtcbiAgICAgICAgICAgIGNvbnN0IHRhZ3MgPSBuZXcgU2V0KCk7XG4gICAgICAgICAgICBhbGwuZm9yRWFjaChzID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocy50YWdzKSB7XG4gICAgICAgICAgICAgICAgICAgIHMudGFncy5mb3JFYWNoKHQgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFncy5hZGQodClcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIFNzZVByb3BzLnJlbW92ZSh7fSk7XG4gICAgICAgICAgICBTc2VQcm9wcy51cHNlcnQoe2tleTogXCJ0YWdzXCJ9LCB7a2V5OiBcInRhZ3NcIiwgdmFsdWU6IEFycmF5LmZyb20odGFncyl9KTtcbiAgICAgICAgfSxcbiAgICAqL1xuICAgICdpbWFnZXMnKGZvbGRlciwgcGFnZUluZGV4LCBwYWdlTGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGlzRGlyZWN0b3J5ID0gc291cmNlID0+IGxzdGF0U3luYyhzb3VyY2UpLmlzRGlyZWN0b3J5KCk7XG4gICAgICAgIGNvbnN0IGlzSW1hZ2UgPSBzb3VyY2UgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3RhdCA9IGxzdGF0U3luYyhzb3VyY2UpO1xuICAgICAgICAgICAgcmV0dXJuIChzdGF0LmlzRmlsZSgpIHx8IHN0YXQuaXNTeW1ib2xpY0xpbmsoKSkgJiZcbiAgICAgICAgICAgICAgICAoXG4gICAgICAgICAgICAgICAgICAgIGV4dG5hbWUoc291cmNlKS50b0xvd2VyQ2FzZSgpID09IFwiLmJtcFwiIHx8XG4gICAgICAgICAgICAgICAgICAgIGV4dG5hbWUoc291cmNlKS50b0xvd2VyQ2FzZSgpID09IFwiLmpwZWdcIiB8fFxuICAgICAgICAgICAgICAgICAgICBleHRuYW1lKHNvdXJjZSkudG9Mb3dlckNhc2UoKSA9PSBcIi5qcGdcIiB8fFxuICAgICAgICAgICAgICAgICAgICBleHRuYW1lKHNvdXJjZSkudG9Mb3dlckNhc2UoKSA9PSBcIi5wY2RcIiB8fFxuICAgICAgICAgICAgICAgICAgICBleHRuYW1lKHNvdXJjZSkudG9Mb3dlckNhc2UoKSA9PSBcIi5wbmdcIlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZ2V0RGlyZWN0b3JpZXMgPSBzb3VyY2UgPT5cbiAgICAgICAgICAgIHJlYWRkaXJTeW5jKHNvdXJjZSkubWFwKG5hbWUgPT4gam9pbihzb3VyY2UsIG5hbWUpKS5maWx0ZXIoaXNEaXJlY3RvcnkpLm1hcChhID0+IGJhc2VuYW1lKGEpKTtcblxuICAgICAgICBjb25zdCBnZXRJbWFnZXMgPSBzb3VyY2UgPT5cbiAgICAgICAgICAgIHJlYWRkaXJTeW5jKHNvdXJjZSkubWFwKG5hbWUgPT4gam9pbihzb3VyY2UsIG5hbWUpKS5maWx0ZXIoaXNJbWFnZSk7XG5cbiAgICAgICAgY29uc3QgZ2V0SW1hZ2VEZXNjID0gcGF0aCA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGJhc2VuYW1lKHBhdGgpLFxuICAgICAgICAgICAgICAgIGVkaXRVcmw6IFwiL2VkaXQvXCIgKyBlbmNvZGVVUklDb21wb25lbnQoZm9sZGVyU2xhc2ggKyBiYXNlbmFtZShwYXRoKSksXG4gICAgICAgICAgICAgICAgdXJsOiAoZm9sZGVyU2xhc2ggPyBcIi9cIiArIGZvbGRlclNsYXNoIDogXCJcIikgKyBcIlwiICsgYmFzZW5hbWUocGF0aClcbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgZ2V0Rm9sZGVyRGVzYyA9IChwYXRoKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGJhc2VuYW1lKHBhdGgpLFxuICAgICAgICAgICAgICAgIHVybDogYC9icm93c2UvJHtwYWdlSW5kZXh9LyR7cGFnZUxlbmd0aH0vYCArIGVuY29kZVVSSUNvbXBvbmVudChmb2xkZXJTbGFzaCArIHBhdGgpXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgcGFnZUluZGV4ID0gcGFyc2VJbnQocGFnZUluZGV4KTtcbiAgICAgICAgcGFnZUxlbmd0aCA9IHBhcnNlSW50KHBhZ2VMZW5ndGgpO1xuICAgICAgICBjb25zdCBmb2xkZXJTbGFzaCA9IGZvbGRlciA/IGRlY29kZVVSSUNvbXBvbmVudChmb2xkZXIpICsgXCIvXCIgOiBcIi9cIjtcbiAgICAgICAgY29uc3QgbGVhZiA9IGpvaW4oY29uZmlnLmltYWdlc0ZvbGRlciwgKGZvbGRlclNsYXNoID8gZm9sZGVyU2xhc2ggOiBcIlwiKSk7XG5cbiAgICAgICAgY29uc3QgZXhpc3RpbmcgPSBleGlzdHNTeW5jKGxlYWYpO1xuXG4gICAgICAgIGlmIChleGlzdGluZyAmJiAhaXNEaXJlY3RvcnkobGVhZikpIHtcbiAgICAgICAgICAgIHJldHVybiB7ZXJyb3I6IGxlYWYgKyBcIiBpcyBhIGZpbGUgYnV0IHNob3VsZCBiZSBhIGZvbGRlci4gQ2hlY2sgdGhlIGRvY3VtZW50YXRpb24gYW5kIHlvdXIgc2V0dGluZ3MuanNvblwifTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWV4aXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm4ge2Vycm9yOiBsZWFmICsgXCIgZG9lcyBub3QgZXhpc3RzLiBDaGVjayB0aGUgZG9jdW1lbnRhdGlvbiBhbmQgeW91ciBzZXR0aW5ncy5qc29uXCJ9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZGlycyA9IGdldERpcmVjdG9yaWVzKGxlYWYpO1xuICAgICAgICBjb25zdCBpbWFnZXMgPSBnZXRJbWFnZXMobGVhZik7XG4gICAgICAgIGNvbnN0IHJlcyA9IHtcbiAgICAgICAgICAgIGZvbGRlcnM6IGRpcnMubWFwKGdldEZvbGRlckRlc2MpLFxuICAgICAgICAgICAgaW1hZ2VzOiBpbWFnZXMubWFwKGdldEltYWdlRGVzYykuc2xpY2UocGFnZUluZGV4ICogcGFnZUxlbmd0aCwgcGFnZUluZGV4ICogcGFnZUxlbmd0aCArIHBhZ2VMZW5ndGgpLFxuICAgICAgICAgICAgaW1hZ2VzQ291bnQ6IGltYWdlcy5sZW5ndGhcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAocGFnZUluZGV4ICogcGFnZUxlbmd0aCArIHBhZ2VMZW5ndGggPCBpbWFnZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXMubmV4dFBhZ2UgPSBgL2Jyb3dzZS8ke3BhZ2VJbmRleCArIDF9LyR7cGFnZUxlbmd0aH0vYCArIChmb2xkZXIgPyBlbmNvZGVVUklDb21wb25lbnQoZm9sZGVyKSA6IFwiXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwYWdlSW5kZXggPiAwKSB7XG4gICAgICAgICAgICByZXMucHJldmlvdXNQYWdlID0gYC9icm93c2UvJHtwYWdlSW5kZXggLSAxfS8ke3BhZ2VMZW5ndGh9L2AgKyAoZm9sZGVyID8gZW5jb2RlVVJJQ29tcG9uZW50KGZvbGRlcikgOiBcIlwiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXM7XG4gICAgfSxcblxuICAgICdzYXZlRGF0YScoc2FtcGxlKSB7XG4gICAgICAgIGlmIChkZW1vTW9kZSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBhdHRycyA9IHVybC5wYXJzZShzYW1wbGUudXJsKTtcbiAgICAgICAgbGV0IHBhdGggPSBkZWNvZGVVUklDb21wb25lbnQoYXR0cnMucGF0aG5hbWUpO1xuICAgICAgICBzYW1wbGUuZm9sZGVyID0gcGF0aC5zdWJzdHJpbmcoMSwgcGF0aC5sYXN0SW5kZXhPZihcIi9cIikpO1xuICAgICAgICBzYW1wbGUuZmlsZSA9IHBhdGguc3Vic3RyaW5nKHBhdGgubGFzdEluZGV4T2YoXCIvXCIpICsgMSk7XG4gICAgICAgIHNhbXBsZS5sYXN0RWRpdERhdGUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBpZiAoIXNhbXBsZS5maXJzdEVkaXREYXRlKVxuICAgICAgICAgICAgc2FtcGxlLmZpcnN0RWRpdERhdGUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBpZiAoc2FtcGxlLnRhZ3MpIHtcbiAgICAgICAgICAgIFNzZVByb3BzLnVwc2VydCh7a2V5OiBcInRhZ3NcIn0sIHskYWRkVG9TZXQ6IHt2YWx1ZTogeyRlYWNoOiBzYW1wbGUudGFnc319fSk7XG4gICAgICAgIH1cbiAgICAgICAgU3NlU2FtcGxlcy51cHNlcnQoe3VybDogc2FtcGxlLnVybH0sIHNhbXBsZSk7XG4gICAgfVxufSk7XG4iXX0=
